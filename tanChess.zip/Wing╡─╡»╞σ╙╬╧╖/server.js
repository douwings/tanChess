'use strict'

let app = require('express')();
let server = require('http').Server(app);
let io = require('socket.io')(server);

server.listen(8081, function() {
    console.log('listening on:8081');
});

let MAX = 30;//���֧�����ӷ�����
let hall = null;//����
let queue = null;//ƥ�����
let rooms = [];//��Ϸ����

function Hall() {
    this.people = 0;
    this.socket = null;
}

function Room(){
    this.people = 0;
    this.socket = null;
}

function Queue(){
    this.people = 0;
    this.socket = null;
}

hall = new Hall();

queue = new Queue();

for(let n = 0;n < MAX;n++){
    rooms[n] = new Room();
}

function getFreeRoom(){
    for(let n = 0;n < MAX;n++){
        if(rooms[n].people === 0){
            return n;
        }
    }
    return -1;
}

io.people = 0;
io.on('connection',function(socket){
    io.people++;
    console.log('someone connected');
    socket.on('disconnect',function(){
        io.people--;
        console.log('someone disconnected');
    });
})

hall.socket = io.of('/hall').on('connection', function(socket) {

    hall.people++;

    console.log('a player connected.There are '+hall.people+' people in hall');

    hall.socket.emit('people changed',hall.people);

    socket.on('disconnect',function(){
        hall.people--;
        console.log('a player disconnected.There are '+hall.people+' people in hall');
        hall.socket.emit('people changed',hall.people);
    });
});

queue.socket = io.of('/queue').on('connection',function(socket){

    queue.people++;

    console.log('someone connect queue socket.There are '+queue.people+' people in queue');

    if(queue.people === 1){
        socket.emit('set stand','BLUE');
	
    }else if(queue.people === 2){
	
	
        //socket.emit('set stand','RED');
	
        let roomId = getFreeRoom();
        console.log(roomId+"roomId");
        if(roomId >= 0){
            queue.socket.emit('match success',roomId);
            console.log('match success.There are '+queue.people+' people in queue');
        }else{
            console.log('no free room!');
        }
	
    };
    socket.on('findblue',function(stand){
	console.log('blue'+stand);
    });
    
    socket.on('cancel match',function(){
        queue.people--;
        console.log('someone cancel match.There are '+queue.people+' people in queue');
    });

    socket.on('disconnect',function(){
        queue.people--;
        console.log('someone disconnected match.There are '+queue.people+' people in queue');
    });

});

for(let i = 0;i < MAX;i++){
    rooms[i].socket = io.of('/rooms'+i).on('connection',function(socket){

        rooms[i].people++;
        console.log('some one connected room'+i+'.There are '+rooms[i].people+' people in the room');
	/*socket.on('forred',function(){
		socket.broadcast.emit('forred');
	});*/
	/*socket.on('haveblue',function(stand){
	console.log('haveblue'+stand);
    	});*/
	/*socket.on('havered',function(stand){
	console.log('havered'+stand);
    	});*/
        socket.on('upinfo',function(upinfo){
	    //console.log('upinfostart');
            socket.broadcast.emit('upinfo',upinfo);
	    //console.log(upinfo);
        });

	/*socket.on('Gstand',function(Gstand){
	    console.log(Gstand);
        });
	socket.on('gameturn',function(gameturn){
	    console.log(gameturn);
        });*/
	//����
        socket.on('upboard',function(upinfo){
	    //console.log(upinfo);
	    socket.broadcast.emit('upboard',upinfo);
	    //console.log(upinfo);
        });
	socket.on('dis',function(chenode){
	    console.log(chenode);
	    socket.broadcast.emit('dis',chenode);
        });
	

        socket.on('disconnect',function(){
            rooms[i].people--;
	    console.log('duankai');
	    if(rooms[i].people==1){
		socket.broadcast.emit('discon');
	    }
            console.log('someone disconnected room'+i+'.There are '+rooms[i].people+' people in the room');
        });

    });
}