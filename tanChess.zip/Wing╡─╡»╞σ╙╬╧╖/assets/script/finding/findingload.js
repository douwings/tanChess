const Constants = require('Constants');
const STAND = Constants.STAND;
cc.Class({
    extends: cc.Component,
    
    properties: {
        
        infoLabel: cc.Label,
    },

    onLoad: function () {
        
        G.queueSocket = io.connect('127.0.0.1:8081/queue', { 'force new connection': true });
        G.queueSocket.on('set stand', function (stand) {
            
            if (stand === 'BLUE') {
                G.stand = STAND.BLUE;
                
                G.queueSocket.emit('findblue',G.stand);
            } else if (stand === 'RED') {
                G.stand = STAND.RED;
                
                G.queueSocket.emit('findred',G.stand);
            }
        });
        G.queueSocket.on('match success', function (roomId) {
            cc.log('match success' + roomId);
            G.roomSocket = io.connect('127.0.0.1:8081/rooms' + roomId, { 'force new connection': true });
            
            G.queueSocket.disconnect();
            cc.director.loadScene('board');
        });
    },

   
});
