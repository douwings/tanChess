const Constants = require('Constants');

const STAND = Constants.STAND;
cc.Class({
    extends: cc.Component,

    properties: {
        
        chessNode: 0,
        
        chessType:0,
        
        speed: cc.v2(0, 0),
        
        quality: 0,
        
        
        
        radius: 250,
        
        flag: 0, //0 and 1 are chessman , 2 is baffle ,3 is border
        
        circle: {
            default : null,
            type : cc.Prefab
        },
        
        point_red: {
            default : null,
            type : cc.Prefab
        },
    },

    
    onLoad: function () {
        
        
        
        var manager = cc.director.getCollisionManager();
        manager.enabled = true;
        
        //var testnum =0;
        
        var circleTemp = cc.instantiate(this.circle);
        var pointRed = cc.instantiate(this.point_red);
        var disX = 0 ;
        var disY = 0 ;
        var maxInitialSpeed = 18000/Math.sqrt(this.quality);
        var moveable = 0;
        var upinfo = [0,0,0];
        
        
       
        this.node.on(cc.Node.EventType.TOUCH_START, function () {
            /*G.roomSocket.emit('Gstand',G.stand);    
            G.roomSocket.emit('gameturn',G.gameManager.turn); */
            if(G.stand===G.gameManager.turn){
            /*G.roomSocket.emit('Gstand',G.stand);    
            G.roomSocket.emit('gameturn',G.gameManager.turn);*/ 
            if(this.chessType===0&&G.gameManager.turn===STAND.BLUE){
                G.roomSocket.emit('dierblue');
                this.node.addChild(circleTemp);
                circleTemp.setPosition(0,0);
                this.node.addChild(pointRed);
                pointRed.setPosition(0,0);
            }
            if(this.chessType==1&&G.gameManager.turn==STAND.RED){
                G.roomSocket.emit('dierred');
                this.node.addChild(circleTemp);
                circleTemp.setPosition(0,0);
                this.node.addChild(pointRed);
                pointRed.setPosition(0,0);
            }
            }
        }, this);
        this.node.on(cc.Node.EventType.TOUCH_MOVE, function (event) {
            if(G.stand===G.gameManager.turn){
            var touches ;
            var touchLoc;
            if(this.chessType===0&&G.gameManager.turn===STAND.BLUE){
                moveable = 1;
            touches = event.getTouches();
            touchLoc = touches[0].getLocation();
            disX = touchLoc.x-540-this.node.x;
            disY = touchLoc.y-960-this.node.y;
            if(disX*disX + disY*disY < this.radius*this.radius){
                pointRed.setPosition(disX,disY);
            }else if(disX*disX + disY*disY < this.radius*this.radius*3){
                disX = disX / Math.sqrt(disX*disX+disY*disY) * this.radius;
                disY = disY / Math.sqrt(disX*disX+disY*disY) * this.radius;
                pointRed.setPosition(disX, disY);
            }else{
                moveable = 0;
                circleTemp.removeFromParent();
                pointRed.removeFromParent();
            }
            }
            
            if(this.chessType==1&&G.gameManager.turn==STAND.RED){
                moveable = 1;
            touches = event.getTouches();
            touchLoc = touches[0].getLocation();
            disX = touchLoc.x-540-this.node.x;
            disY = touchLoc.y-960-this.node.y;
            if(disX*disX + disY*disY < this.radius*this.radius){
                pointRed.setPosition(disX,disY);
            }else if(disX*disX + disY*disY < this.radius*this.radius*3){
                disX = disX / Math.sqrt(disX*disX+disY*disY) * this.radius;
                disY = disY / Math.sqrt(disX*disX+disY*disY) * this.radius;
                pointRed.setPosition(disX, disY);
            }else{
                moveable = 0;
                circleTemp.removeFromParent();
                pointRed.removeFromParent();
            }
            }
            
            //G.roomSocket.emit('change turn');
            
            }
        }, this);//脚本运行至此，传出disX,disY两个参数，代表触摸点相对于棋子的位置，用以计算弹力的大小与方向
        this.node.on(cc.Node.EventType.TOUCH_END, function () {
            if(G.stand===G.gameManager.turn){
            if (this.chessType === 0 && G.gameManager.turn== STAND.BLUE) {
                if(moveable == 1){
                this.speed.x = Math.round(-disX/this.radius*maxInitialSpeed);
                this.speed.y = Math.round(-disY/this.radius*maxInitialSpeed);
                circleTemp.removeFromParent();
                pointRed.removeFromParent();
                moveable = 0;
                upinfo[0]=this.chessNode;
                upinfo[1]=this.speed.x;
                upinfo[2]=this.speed.y;
                G.roomSocket.emit('upinfo',upinfo);
                G.gameManager.changeTurn();
            }else{
                circleTemp.removeFromParent();
                pointRed.removeFromParent();
            }
            }
            if (this.chessType === 1 && G.gameManager.turn== STAND.RED) {
                if(moveable == 1){
                this.speed.x = Math.round(-disX/this.radius*maxInitialSpeed);
                this.speed.y = Math.round(-disY/this.radius*maxInitialSpeed);
                circleTemp.removeFromParent();
                pointRed.removeFromParent();
                moveable = 0;
                upinfo[0]=this.chessNode;
                upinfo[1]=this.speed.x;
                upinfo[2]=this.speed.y;
                G.roomSocket.emit('upinfo',upinfo);
                G.gameManager.changeTurn();
            }else{
                circleTemp.removeFromParent();
                pointRed.removeFromParent();
            }
            }
            }
        }, this);
        this.node.on(cc.Node.EventType.TOUCH_CANCEL, function () {
            if(G.stand===G.gameManager.turn){
            if (this.chessType === 0 && G.gameManager.turn== STAND.BLUE) {
            if(moveable == 1){
                this.speed.x = Math.round(-disX/this.radius*maxInitialSpeed);
                this.speed.y = Math.round(-disY/this.radius*maxInitialSpeed);
                circleTemp.removeFromParent();
                pointRed.removeFromParent();
                moveable = 0;
                upinfo[0]=this.chessNode;
                upinfo[1]=this.speed.x;
                upinfo[2]=this.speed.y;
                G.roomSocket.emit('upinfo',upinfo);
                G.gameManager.changeTurn();
            }else{
                circleTemp.removeFromParent();
                pointRed.removeFromParent();
            }
            }
            if (this.chessType === 1 && G.gameManager.turn== STAND.RED) {
            if(moveable == 1){
                this.speed.x = Math.round(-disX/this.radius*maxInitialSpeed);
                this.speed.y = Math.round(-disY/this.radius*maxInitialSpeed);
                circleTemp.removeFromParent();
                pointRed.removeFromParent();
                moveable = 0;
                upinfo[0]=this.chessNode;
                upinfo[1]=this.speed.x;
                upinfo[2]=this.speed.y;
                G.roomSocket.emit('upinfo',upinfo);
                
                G.gameManager.changeTurn();
            }else{
                circleTemp.removeFromParent();
                pointRed.removeFromParent();
            }
            }
            }
        }, this);
    
        
        
    
    },


    
    onCollisionEnter: function (other, self) {
        if(this.flag === 0){
            if(other.getComponent("test").flag ===0){//棋子对撞
                other.getComponent("test").flag = 1;
                var mA = this.quality;
                var mB = other.getComponent("test").quality;
                var xA = self.world.position.x;
                var yA = self.world.position.y;
                var xB = other.world.position.x;
                var yB = other.world.position.y;
                var vxA = this.speed.x;
                var vyA = this.speed.y;
                var vxB = other.getComponent("test").speed.x;
                var vyB = other.getComponent("test").speed.y;
                var alpha = Math.atan((yB-yA)/(xB-xA));
                var v1 = Math.sin(alpha)*vyA + Math.cos(alpha)*vxA;
                var v2 = Math.sin(alpha)*vyB + Math.cos(alpha)*vxB;
                var v11 = (2*mB*v2+(mA-mB)*v1)/(mA+mB)*0.8;
                var v22 = (2*mA*v1+(mB-mA)*v2)/(mA+mB)*0.8;
        
                this.speed.x = Math.cos(alpha)*v11-Math.sin(alpha)*(Math.cos(alpha)*vyA-Math.sin(alpha)*vxA);
                this.speed.y = Math.cos(alpha)*(Math.cos(alpha)*vyA-Math.sin(alpha)*vxA)+Math.sin(alpha)*v11;
                other.getComponent("test").speed.x=Math.cos(alpha)*v22-Math.sin(alpha)*(Math.cos(alpha)*vyB-Math.sin(alpha)*vxB);
                other.getComponent("test").speed.y=Math.cos(alpha)*(Math.cos(alpha)*vyB-Math.sin(alpha)*vxB)+Math.sin(alpha)*v22;
            }else if(other.getComponent("test").flag === 2){//棋子撞板
                var radiusOfSelf = 0;
                
                if(this.quality == 500) {radiusOfSelf = 50;}
                else if(this.quality == 300) {radiusOfSelf = 35;}
                else{radiusOfSelf = 25;}
                if(Math.abs(this.node.x) > -radiusOfSelf+250){this.speed.y = -this.speed.y * 0.8}
                else{this.speed.x = -this.speed.x * 0.8;}
            }else if(other.getComponent("test").flag === 3){//棋子撞边界
                if(this.chessType===0){
                    G.gameManager.bluenum--;
                    G.gameManager.judge();
                }else{
                    G.gameManager.rednum--;
                    G.gameManager.judge();
                }
                G.roomSocket.emit('dis',this.node.chessNode);
                this.node.destroy();
            }
        }else if(this.flag === 1){
            this.flag = 0;
        }
        
    },
    
    update: function (dt) {
        var acce = 520;
        if(this.speed.x > 0 ) {
            this.speed.x -= acce*Math.abs(this.speed.x)/Math.sqrt(this.speed.x*this.speed.x+this.speed.y*this.speed.y) * dt;
        }else if(this.speed.x < 0) {
            this.speed.x += acce*Math.abs(this.speed.x)/Math.sqrt(this.speed.x*this.speed.x+this.speed.y*this.speed.y) * dt;
        }
        if(this.speed.y > 0 ) {
            this.speed.y -= acce*Math.abs(this.speed.y)/Math.sqrt(this.speed.x*this.speed.x+this.speed.y*this.speed.y) * dt;
        }else if(this.speed.y < 0) {
            this.speed.y += acce*Math.abs(this.speed.y)/Math.sqrt(this.speed.x*this.speed.x+this.speed.y*this.speed.y) * dt;
        }//随时间更新速度并确保单向运动
        
        this.node.x += this.speed.x * dt;
        this.node.y += this.speed.y * dt;
    }

    


});
