const STAND = cc.Enum({
    RED: 1,
    BLUE: 2,
});

const CHESS_TYPE = cc.Enum({
    NONE: -1,
    RED: 1,
    BLUE: -1,
});

const GAME_STATE = cc.Enum({
    PREPARE: -1,
    PLAYING: -1,
    OVER: -1,
});


module.exports = {
    STAND:STAND,
    CHESS_TYPE:CHESS_TYPE,
    GAME_STATE:GAME_STATE,

};