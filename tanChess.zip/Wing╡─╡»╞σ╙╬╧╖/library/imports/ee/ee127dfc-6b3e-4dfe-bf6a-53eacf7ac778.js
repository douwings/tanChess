cc.Class({
    'extends': cc.Component,

    onLoad: function onLoad() {

        G.globalSocket = io.connect('127.0.0.1:8081');
        //断开连接后再重新连接需要加上{'force new connection': true}
        G.hallSocket = io.connect('127.0.0.1:8081/hall', { 'force new connection': true });
    }

});