window.G = {
    globalSocket: null, //全局
    hallSocket: null, //大厅
    queueSocket: null, //队列
    roomSocket: null, //房间
    wintype: null,
    gameManager: null,
    stand: null
};