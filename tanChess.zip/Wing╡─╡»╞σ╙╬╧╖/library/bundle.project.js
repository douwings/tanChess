require=(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({"Constants":[function(require,module,exports){
"use strict";
cc._RFpush(module, 'e2756duo7BNRY7f8kHKLZWl', 'Constants');
// script\util\Constants.js

var STAND = cc.Enum({
    RED: 1,
    BLUE: 2
});

var CHESS_TYPE = cc.Enum({
    NONE: -1,
    RED: 1,
    BLUE: -1
});

var GAME_STATE = cc.Enum({
    PREPARE: -1,
    PLAYING: -1,
    OVER: -1
});

module.exports = {
    STAND: STAND,
    CHESS_TYPE: CHESS_TYPE,
    GAME_STATE: GAME_STATE

};

cc._RFpop();
},{}],"Global":[function(require,module,exports){
"use strict";
cc._RFpush(module, '04fd0MxwapHrYsfCAT2HRS8', 'Global');
// script\util\Global.js

window.G = {
    globalSocket: null, //全局
    hallSocket: null, //大厅
    queueSocket: null, //队列
    roomSocket: null, //房间
    wintype: null,
    gameManager: null,
    stand: null
};

cc._RFpop();
},{}],"backfind":[function(require,module,exports){
"use strict";
cc._RFpush(module, 'aa14eKuGkZFgKHGIfycwdY7', 'backfind');
// script\win\backfind.js

cc.Class({
    'extends': cc.Component,

    properties: {
        // foo: {
        //    default: null,      // The default value will be used only when the component attaching
        //                           to a node for the first time
        //    url: cc.Texture2D,  // optional, default is typeof default
        //    serializable: true, // optional, default is true
        //    visible: true,      // optional, default is true
        //    displayName: 'Foo', // optional
        //    readonly: false,    // optional, default is false
        // },
        // ...
    },

    // use this for initialization
    onLoad: function onLoad() {},

    backfindfun: function backfindfun() {
        //G.hallSocket.disconnect();
        cc.director.loadScene('finding');
    }

    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
});

cc._RFpop();
},{}],"backstart":[function(require,module,exports){
"use strict";
cc._RFpush(module, '85c5efXGmhJBqt9xif7aPTF', 'backstart');
// script\win\backstart.js

cc.Class({
    'extends': cc.Component,

    properties: {
        // foo: {
        //    default: null,      // The default value will be used only when the component attaching
        //                           to a node for the first time
        //    url: cc.Texture2D,  // optional, default is typeof default
        //    serializable: true, // optional, default is true
        //    visible: true,      // optional, default is true
        //    displayName: 'Foo', // optional
        //    readonly: false,    // optional, default is false
        // },
        // ...
    },

    // use this for initialization
    onLoad: function onLoad() {},

    backstartfun: function backstartfun() {
        //G.hallSocket.disconnect();
        cc.director.loadScene('start');
    }

    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
});

cc._RFpop();
},{}],"back":[function(require,module,exports){
"use strict";
cc._RFpush(module, 'cea9arhkQBHhYpV2Yg1i4Aa', 'back');
// script\finding\back.js

cc.Class({
    'extends': cc.Component,

    properties: {
        // foo: {
        //    default: null,      // The default value will be used only when the component attaching
        //                           to a node for the first time
        //    url: cc.Texture2D,  // optional, default is typeof default
        //    serializable: true, // optional, default is true
        //    visible: true,      // optional, default is true
        //    displayName: 'Foo', // optional
        //    readonly: false,    // optional, default is false
        // },
        // ...
    },

    // use this for initialization
    onLoad: function onLoad() {},

    backfun: function backfun() {
        G.queueSocket.disconnect();
        cc.director.loadScene('start');
    }

});
// called every frame, uncomment this function to activate update callback
// update: function (dt) {

// },

cc._RFpop();
},{}],"findingload":[function(require,module,exports){
"use strict";
cc._RFpush(module, '6c757UGdXtAS5Jv80AZWIOi', 'findingload');
// script\finding\findingload.js

var Constants = require('Constants');
var STAND = Constants.STAND;
cc.Class({
    'extends': cc.Component,

    properties: {

        infoLabel: cc.Label
    },

    onLoad: function onLoad() {

        G.queueSocket = io.connect('127.0.0.1:8081/queue', { 'force new connection': true });
        G.queueSocket.on('set stand', function (stand) {

            if (stand === 'BLUE') {
                G.stand = STAND.BLUE;

                G.queueSocket.emit('findblue', G.stand);
            } else if (stand === 'RED') {
                G.stand = STAND.RED;

                G.queueSocket.emit('findred', G.stand);
            }
        });
        G.queueSocket.on('match success', function (roomId) {
            cc.log('match success' + roomId);
            G.roomSocket = io.connect('127.0.0.1:8081/rooms' + roomId, { 'force new connection': true });

            G.queueSocket.disconnect();
            cc.director.loadScene('board');
        });
    }

});

cc._RFpop();
},{"Constants":"Constants"}],"gameManager":[function(require,module,exports){
"use strict";
cc._RFpush(module, '10ae3L6TM5N/pEf2hMu+Umf', 'gameManager');
// script\game\gameManager.js

var Constants = require('Constants');
//const GAME_STATE = Constants.GAME_STATE;
var STAND = Constants.STAND;

cc.Class({
    'extends': cc.Component,

    properties: {

        turn: {
            'default': STAND.BLUE,
            type: STAND
        },

        //type: null,

        bluenum: 8,
        rednum: 8

    },

    //turnNum:0,
    //infoPanel: cc.Node,

    // use this for initialization
    onLoad: function onLoad() {

        G.gameManager = this;
        if (G.stand === STAND.BLUE) {
            G.roomSocket.emit('haveblue', G.stand);
        } else {
            G.stand = STAND.RED;
            G.roomSocket.emit('havered', G.stand);
        }
        //cc.find("Canvas/chessboard/bigChess_blue").getComponent("test").speed.x = 500;
        G.roomSocket.on('upinfo', function (upinfo) {

            upinfo = upinfo;
            G.gameManager.gameupinfo(upinfo);

            G.gameManager.changeTurn();
        });

        G.roomSocket.on('discon', function () {
            ////console.log("dafdasfadfadsf");
            G.wintype = 'discon';
            console.log(G.wintype);
            ////console.log("dasf");
            cc.director.loadScene('win');
        });

        G.roomSocket.on('upboard', function (upinfo) {

            upinfo = upinfo;
            G.gameManager.gameupboard(upinfo);
        });

        G.roomSocket.on('dis', function (chenode) {

            G.gameManager.chedis(chenode);
        });

        this.schedule(function () {
            var upinfo = [0, 0, 0, 0, 0];
            var typeNode;
            if (cc.find("Canvas/chessboard/bigChess_blue")) {
                typeNode = cc.find("Canvas/chessboard/bigChess_blue");

                upinfo[0] = typeNode.getComponent("test").chessNode;
                upinfo[1] = typeNode.x;
                upinfo[2] = typeNode.y;
                upinfo[3] = typeNode.getComponent("test").speed.x;
                upinfo[4] = typeNode.getComponent("test").speed.y;
                G.roomSocket.emit('upboard', upinfo);
            }
            if (cc.find("Canvas/chessboard/bigChess_red")) {
                typeNode = cc.find("Canvas/chessboard/bigChess_red");

                upinfo[0] = typeNode.getComponent("test").chessNode;
                upinfo[1] = typeNode.x;
                upinfo[2] = typeNode.y;
                upinfo[3] = typeNode.getComponent("test").speed.x;
                upinfo[4] = typeNode.getComponent("test").speed.y;
                G.roomSocket.emit('upboard', upinfo);
            }
            if (cc.find("Canvas/chessboard/midChess_red_1")) {
                typeNode = cc.find("Canvas/chessboard/midChess_red_1");

                upinfo[0] = typeNode.getComponent("test").chessNode;
                upinfo[1] = typeNode.x;
                upinfo[2] = typeNode.y;
                upinfo[3] = typeNode.getComponent("test").speed.x;
                upinfo[4] = typeNode.getComponent("test").speed.y;
                G.roomSocket.emit('upboard', upinfo);
            }
            if (cc.find("Canvas/chessboard/midChess_red_2")) {
                typeNode = cc.find("Canvas/chessboard/midChess_red_2");

                upinfo[0] = typeNode.getComponent("test").chessNode;
                upinfo[1] = typeNode.x;
                upinfo[2] = typeNode.y;
                upinfo[3] = typeNode.getComponent("test").speed.x;
                upinfo[4] = typeNode.getComponent("test").speed.y;
                G.roomSocket.emit('upboard', upinfo);
            }
            if (cc.find("Canvas/chessboard/midChess_red_3")) {
                typeNode = cc.find("Canvas/chessboard/midChess_red_3");

                upinfo[0] = typeNode.getComponent("test").chessNode;
                upinfo[1] = typeNode.x;
                upinfo[2] = typeNode.y;
                upinfo[3] = typeNode.getComponent("test").speed.x;
                upinfo[4] = typeNode.getComponent("test").speed.y;
                G.roomSocket.emit('upboard', upinfo);
            }
            if (cc.find("Canvas/chessboard/midChess_red_4")) {
                typeNode = cc.find("Canvas/chessboard/midChess_red_4");

                upinfo[0] = typeNode.getComponent("test").chessNode;
                upinfo[1] = typeNode.x;
                upinfo[2] = typeNode.y;
                upinfo[3] = typeNode.getComponent("test").speed.x;
                upinfo[4] = typeNode.getComponent("test").speed.y;
                G.roomSocket.emit('upboard', upinfo);
            }
            if (cc.find("Canvas/chessboard/midChess_blue_1")) {
                typeNode = cc.find("Canvas/chessboard/midChess_blue_1");

                upinfo[0] = typeNode.getComponent("test").chessNode;
                upinfo[1] = typeNode.x;
                upinfo[2] = typeNode.y;
                upinfo[3] = typeNode.getComponent("test").speed.x;
                upinfo[4] = typeNode.getComponent("test").speed.y;
                G.roomSocket.emit('upboard', upinfo);
            }
            if (cc.find("Canvas/chessboard/midChess_blue_2")) {
                typeNode = cc.find("Canvas/chessboard/midChess_blue_2");

                upinfo[0] = typeNode.getComponent("test").chessNode;
                upinfo[1] = typeNode.x;
                upinfo[2] = typeNode.y;
                upinfo[3] = typeNode.getComponent("test").speed.x;
                upinfo[4] = typeNode.getComponent("test").speed.y;
                G.roomSocket.emit('upboard', upinfo);
            }
            if (cc.find("Canvas/chessboard/midChess_blue_3")) {
                typeNode = cc.find("Canvas/chessboard/midChess_blue_3");

                upinfo[0] = typeNode.getComponent("test").chessNode;
                upinfo[1] = typeNode.x;
                upinfo[2] = typeNode.y;
                upinfo[3] = typeNode.getComponent("test").speed.x;
                upinfo[4] = typeNode.getComponent("test").speed.y;
                G.roomSocket.emit('upboard', upinfo);
            }
            if (cc.find("Canvas/chessboard/midChess_blue_4")) {
                typeNode = cc.find("Canvas/chessboard/midChess_blue_4");

                upinfo[0] = typeNode.getComponent("test").chessNode;
                upinfo[1] = typeNode.x;
                upinfo[2] = typeNode.y;
                upinfo[3] = typeNode.getComponent("test").speed.x;
                upinfo[4] = typeNode.getComponent("test").speed.y;
                G.roomSocket.emit('upboard', upinfo);
            }
            if (cc.find("Canvas/chessboard/smallChess_red_1")) {
                typeNode = cc.find("Canvas/chessboard/smallChess_red_1");

                upinfo[0] = typeNode.getComponent("test").chessNode;
                upinfo[1] = typeNode.x;
                upinfo[2] = typeNode.y;
                upinfo[3] = typeNode.getComponent("test").speed.x;
                upinfo[4] = typeNode.getComponent("test").speed.y;
                G.roomSocket.emit('upboard', upinfo);
            }
            if (cc.find("Canvas/chessboard/smallChess_red_2")) {
                typeNode = cc.find("Canvas/chessboard/smallChess_red_2");

                upinfo[0] = typeNode.getComponent("test").chessNode;
                upinfo[1] = typeNode.x;
                upinfo[2] = typeNode.y;
                upinfo[3] = typeNode.getComponent("test").speed.x;
                upinfo[4] = typeNode.getComponent("test").speed.y;
                G.roomSocket.emit('upboard', upinfo);
            }
            if (cc.find("Canvas/chessboard/smallChess_red_3")) {
                typeNode = cc.find("Canvas/chessboard/smallChess_red_3");

                upinfo[0] = typeNode.getComponent("test").chessNode;
                upinfo[1] = typeNode.x;
                upinfo[2] = typeNode.y;
                upinfo[3] = typeNode.getComponent("test").speed.x;
                upinfo[4] = typeNode.getComponent("test").speed.y;
                G.roomSocket.emit('upboard', upinfo);
            }
            if (cc.find("Canvas/chessboard/smallChess_blue_1")) {
                typeNode = cc.find("Canvas/chessboard/smallChess_blue_1");

                upinfo[0] = typeNode.getComponent("test").chessNode;
                upinfo[1] = typeNode.x;
                upinfo[2] = typeNode.y;
                upinfo[3] = typeNode.getComponent("test").speed.x;
                upinfo[4] = typeNode.getComponent("test").speed.y;
                G.roomSocket.emit('upboard', upinfo);
            }
            if (cc.find("Canvas/chessboard/smallChess_blue_2")) {
                typeNode = cc.find("Canvas/chessboard/smallChess_blue_2");

                upinfo[0] = typeNode.getComponent("test").chessNode;
                upinfo[1] = typeNode.x;
                upinfo[2] = typeNode.y;
                upinfo[3] = typeNode.getComponent("test").speed.x;
                upinfo[4] = typeNode.getComponent("test").speed.y;
                G.roomSocket.emit('upboard', upinfo);
            }
            if (cc.find("Canvas/chessboard/smallChess_blue_3")) {
                typeNode = cc.find("Canvas/chessboard/smallChess_blue_3");

                upinfo[0] = typeNode.getComponent("test").chessNode;
                upinfo[1] = typeNode.x;
                upinfo[2] = typeNode.y;
                upinfo[3] = typeNode.getComponent("test").speed.x;
                upinfo[4] = typeNode.getComponent("test").speed.y;
                G.roomSocket.emit('upboard', upinfo);
            }
        }, 2);
    },

    chedis: function chedis(chenode) {

        var typeNode;

        if (chenode == 2) {

            typeNode = cc.find("Canvas/chessboard/bigChess_blue");
            //console.log("zhaodao");
            typeNode.destroy();
            //console.log("xiaochu");
        }

        if (chenode == 1) {

            //console.log("zhaodao");typeNode = cc.find("Canvas/chessboard/bigChess_red");
            typeNode.destroy();
            //console.log("xiaochu");
        }

        if (chenode == 3) {

            typeNode = cc.find("Canvas/chessboard/midChess_red_1");
            //console.log("zhaodao");
            typeNode.destroy();
            //console.log("xiaochu");
        }
        if (chenode == 4) {
            //console.log("zhaodao");typeNode = cc.find("Canvas/chessboard/midChess_red_2");
            typeNode.destroy();
            //console.log("xiaochu");
        }
        if (chenode == 5) {
            //console.log("zhaodao");typeNode = cc.find("Canvas/chessboard/midChess_red_3");
            typeNode.destroy();
            //console.log("xiaochu");
        }
        if (chenode == 6) {
            //console.log("zhaodao");typeNode = cc.find("Canvas/chessboard/midChess_red_4");
            typeNode.destroy();
            //console.log("xiaochu");
        }

        if (chenode == 7) {
            //console.log("zhaodao");typeNode = cc.find("Canvas/chessboard/midChess_blue_1");
            typeNode.destroy();
            //console.log("xiaochu");
        }
        if (chenode == 8) {
            //console.log("zhaodao");typeNode = cc.find("Canvas/chessboard/midChess_blue_2");
            typeNode.destroy();
            //console.log("xiaochu");
        }
        if (chenode == 9) {
            //console.log("zhaodao");typeNode = cc.find("Canvas/chessboard/midChess_blue_3");
            typeNode.destroy();
            //console.log("xiaochu");
        }
        if (chenode == 10) {
            //console.log("zhaodao");typeNode = cc.find("Canvas/chessboard/midChess_blue_4");
            typeNode.destroy();
            //console.log("xiaochu");
        }

        if (chenode == 11) {
            //console.log("zhaodao");typeNode = cc.find("Canvas/chessboard/smallChess_red_1");
            typeNode.destroy();
            //console.log("xiaochu");
        }
        if (chenode == 12) {
            //console.log("zhaodao");typeNode = cc.find("Canvas/chessboard/smallChess_red_2");
            typeNode.destroy();
            //console.log("xiaochu");
        }
        if (chenode == 13) {
            //console.log("zhaodao");typeNode = cc.find("Canvas/chessboard/smallChess_red_3");
            typeNode.destroy();
            //console.log("xiaochu");
        }

        if (chenode == 14) {
            //console.log("zhaodao");typeNode = cc.find("Canvas/chessboard/smallChess_blue_1");
            typeNode.destroy();
            //console.log("xiaochu");
        }
        if (chenode == 15) {
            //console.log("zhaodao");typeNode = cc.find("Canvas/chessboard/smallChess_blue_2");
            typeNode.destroy();
            //console.log("xiaochu");
        }
        if (chenode == 16) {
            //console.log("zhaodao");typeNode = cc.find("Canvas/chessboard/smallChess_blue_3");
            typeNode.destroy();
            //console.log("xiaochu");
        }
    },

    gameupboard: function gameupboard(upinfo) {

        var typeNode;

        if (upinfo[0] == 2) {

            typeNode = cc.find("Canvas/chessboard/bigChess_blue");

            typeNode.x = upinfo[1];
            typeNode.y = upinfo[2];
            typeNode.getComponent("test").speed.x = upinfo[3];
            typeNode.getComponent("test").speed.y = upinfo[4];
        }

        if (upinfo[0] == 1) {

            typeNode = cc.find("Canvas/chessboard/bigChess_red");
            typeNode.x = upinfo[1];
            typeNode.y = upinfo[2];
            typeNode.getComponent("test").speed.x = upinfo[3];
            typeNode.getComponent("test").speed.y = upinfo[4];
        }

        if (upinfo[0] == 3) {

            typeNode = cc.find("Canvas/chessboard/midChess_red_1");

            typeNode.x = upinfo[1];
            typeNode.y = upinfo[2];
            typeNode.getComponent("test").speed.x = upinfo[3];
            typeNode.getComponent("test").speed.y = upinfo[4];
        }
        if (upinfo[0] == 4) {
            typeNode = cc.find("Canvas/chessboard/midChess_red_2");
            typeNode.x = upinfo[1];
            typeNode.y = upinfo[2];
            typeNode.getComponent("test").speed.x = upinfo[3];
            typeNode.getComponent("test").speed.y = upinfo[4];
        }
        if (upinfo[0] == 5) {
            typeNode = cc.find("Canvas/chessboard/midChess_red_3");
            typeNode.x = upinfo[1];
            typeNode.y = upinfo[2];
            typeNode.getComponent("test").speed.x = upinfo[3];
            typeNode.getComponent("test").speed.y = upinfo[4];
        }
        if (upinfo[0] == 6) {
            typeNode = cc.find("Canvas/chessboard/midChess_red_4");
            typeNode.x = upinfo[1];
            typeNode.y = upinfo[2];
            typeNode.getComponent("test").speed.x = upinfo[3];
            typeNode.getComponent("test").speed.y = upinfo[4];
        }

        if (upinfo[0] == 7) {
            typeNode = cc.find("Canvas/chessboard/midChess_blue_1");
            typeNode.x = upinfo[1];
            typeNode.y = upinfo[2];
            typeNode.getComponent("test").speed.x = upinfo[3];
            typeNode.getComponent("test").speed.y = upinfo[4];
        }
        if (upinfo[0] == 8) {
            typeNode = cc.find("Canvas/chessboard/midChess_blue_2");
            typeNode.x = upinfo[1];
            typeNode.y = upinfo[2];
            typeNode.getComponent("test").speed.x = upinfo[3];
            typeNode.getComponent("test").speed.y = upinfo[4];
        }
        if (upinfo[0] == 9) {
            typeNode = cc.find("Canvas/chessboard/midChess_blue_3");
            typeNode.x = upinfo[1];
            typeNode.y = upinfo[2];
            typeNode.getComponent("test").speed.x = upinfo[3];
            typeNode.getComponent("test").speed.y = upinfo[4];
        }
        if (upinfo[0] == 10) {
            typeNode = cc.find("Canvas/chessboard/midChess_blue_4");
            typeNode.x = upinfo[1];
            typeNode.y = upinfo[2];
            typeNode.getComponent("test").speed.x = upinfo[3];
            typeNode.getComponent("test").speed.y = upinfo[4];
        }

        if (upinfo[0] == 11) {
            typeNode = cc.find("Canvas/chessboard/smallChess_red_1");
            typeNode.x = upinfo[1];
            typeNode.y = upinfo[2];
            typeNode.getComponent("test").speed.x = upinfo[3];
            typeNode.getComponent("test").speed.y = upinfo[4];
        }
        if (upinfo[0] == 12) {
            typeNode = cc.find("Canvas/chessboard/smallChess_red_2");
            typeNode.x = upinfo[1];
            typeNode.y = upinfo[2];
            typeNode.getComponent("test").speed.x = upinfo[3];
            typeNode.getComponent("test").speed.y = upinfo[4];
        }
        if (upinfo[0] == 13) {
            typeNode = cc.find("Canvas/chessboard/smallChess_red_3");
            typeNode.x = upinfo[1];
            typeNode.y = upinfo[2];
            typeNode.getComponent("test").speed.x = upinfo[3];
            typeNode.getComponent("test").speed.y = upinfo[4];
        }

        if (upinfo[0] == 14) {
            typeNode = cc.find("Canvas/chessboard/smallChess_blue_1");
            typeNode.x = upinfo[1];
            typeNode.y = upinfo[2];
            typeNode.getComponent("test").speed.x = upinfo[3];
            typeNode.getComponent("test").speed.y = upinfo[4];
        }
        if (upinfo[0] == 15) {
            typeNode = cc.find("Canvas/chessboard/smallChess_blue_2");
            typeNode.x = upinfo[1];
            typeNode.y = upinfo[2];
            typeNode.getComponent("test").speed.x = upinfo[3];
            typeNode.getComponent("test").speed.y = upinfo[4];
        }
        if (upinfo[0] == 16) {
            typeNode = cc.find("Canvas/chessboard/smallChess_blue_3");
            typeNode.x = upinfo[1];
            typeNode.y = upinfo[2];
            typeNode.getComponent("test").speed.x = upinfo[3];
            typeNode.getComponent("test").speed.y = upinfo[4];
        }
    },

    gameupinfo: function gameupinfo(upinfo) {

        var typeNode;
        var num;
        if (upinfo[0] == 2) {

            typeNode = cc.find("Canvas/chessboard/bigChess_blue");

            typeNode.getComponent("test").speed.x = upinfo[1];
            typeNode.getComponent("test").speed.y = upinfo[2];
        }

        if (upinfo[0] == 1) {

            typeNode = cc.find("Canvas/chessboard/bigChess_red");
            typeNode.getComponent("test").speed.x = upinfo[1];
            typeNode.getComponent("test").speed.y = upinfo[2];
        }

        if (upinfo[0] == 3) {

            typeNode = cc.find("Canvas/chessboard/midChess_red_1");

            typeNode.getComponent("test").speed.x = upinfo[1];
            typeNode.getComponent("test").speed.y = upinfo[2];
        }
        if (upinfo[0] == 4) {
            typeNode = cc.find("Canvas/chessboard/midChess_red_2");
            typeNode.getComponent("test").speed.x = upinfo[1];
            typeNode.getComponent("test").speed.y = upinfo[2];
        }
        if (upinfo[0] == 5) {
            typeNode = cc.find("Canvas/chessboard/midChess_red_3");
            typeNode.getComponent("test").speed.x = upinfo[1];
            typeNode.getComponent("test").speed.y = upinfo[2];
        }
        if (upinfo[0] == 6) {
            typeNode = cc.find("Canvas/chessboard/midChess_red_4");
            typeNode.getComponent("test").speed.x = upinfo[1];
            typeNode.getComponent("test").speed.y = upinfo[2];
        }

        if (upinfo[0] == 7) {
            typeNode = cc.find("Canvas/chessboard/midChess_blue_1");
            typeNode.getComponent("test").speed.x = upinfo[1];
            typeNode.getComponent("test").speed.y = upinfo[2];
        }
        if (upinfo[0] == 8) {
            typeNode = cc.find("Canvas/chessboard/midChess_blue_2");
            typeNode.getComponent("test").speed.x = upinfo[1];
            typeNode.getComponent("test").speed.y = upinfo[2];
        }
        if (upinfo[0] == 9) {
            typeNode = cc.find("Canvas/chessboard/midChess_blue_3");
            typeNode.getComponent("test").speed.x = upinfo[1];
            typeNode.getComponent("test").speed.y = upinfo[2];
        }
        if (upinfo[0] == 10) {
            typeNode = cc.find("Canvas/chessboard/midChess_blue_4");
            typeNode.getComponent("test").speed.x = upinfo[1];
            typeNode.getComponent("test").speed.y = upinfo[2];
        }

        if (upinfo[0] == 11) {
            typeNode = cc.find("Canvas/chessboard/smallChess_red_1");
            typeNode.getComponent("test").speed.x = upinfo[1];
            typeNode.getComponent("test").speed.y = upinfo[2];
        }
        if (upinfo[0] == 12) {
            typeNode = cc.find("Canvas/chessboard/smallChess_red_2");
            typeNode.getComponent("test").speed.x = upinfo[1];
            typeNode.getComponent("test").speed.y = upinfo[2];
        }
        if (upinfo[0] == 13) {
            typeNode = cc.find("Canvas/chessboard/smallChess_red_3");
            typeNode.getComponent("test").speed.x = upinfo[1];
            typeNode.getComponent("test").speed.y = upinfo[2];
        }

        if (upinfo[0] == 14) {
            typeNode = cc.find("Canvas/chessboard/smallChess_blue_1");
            typeNode.getComponent("test").speed.x = upinfo[1];
            typeNode.getComponent("test").speed.y = upinfo[2];
        }
        if (upinfo[0] == 15) {
            typeNode = cc.find("Canvas/chessboard/smallChess_blue_2");
            typeNode.getComponent("test").speed.x = upinfo[1];
            typeNode.getComponent("test").speed.y = upinfo[2];
        }
        if (upinfo[0] == 16) {
            typeNode = cc.find("Canvas/chessboard/smallChess_blue_3");
            typeNode.getComponent("test").speed.x = upinfo[1];
            typeNode.getComponent("test").speed.y = upinfo[2];
        }
    },

    changeTurn: function changeTurn() {
        if (this.turn === STAND.BLUE) {
            this.turn = STAND.RED;
            cc.find("Canvas/progressBar").getComponent(cc.ProgressBar).progress = 1;
            cc.find("Canvas/progressBar").getComponent("progressBarControl").remainingTime = 45;
        } else if (this.turn === STAND.RED) {
            this.turn = STAND.BLUE;
            cc.find("Canvas/progressBar").getComponent(cc.ProgressBar).progress = 1;
            cc.find("Canvas/progressBar").getComponent("progressBarControl").remainingTime = 45;
        }
    },

    judge: function judge() {
        if (this.bluenum === 0) {
            G.wintype = 'redwin';
            cc.director.loadScene('win');
        }
        if (this.rednum === 0) {
            G.wintype = 'bluewin';
            cc.director.loadScene('win');
        }
    }

});

cc._RFpop();
},{"Constants":"Constants"}],"help_back":[function(require,module,exports){
"use strict";
cc._RFpush(module, 'ad714U65PBJN6ktTRoXG+7v', 'help_back');
// script\start\help_back.js

cc.Class({
    "extends": cc.Component,

    properties: {
        // foo: {
        //    default: null,      // The default value will be used only when the component attaching
        //                           to a node for the first time
        //    url: cc.Texture2D,  // optional, default is typeof default
        //    serializable: true, // optional, default is true
        //    visible: true,      // optional, default is true
        //    displayName: 'Foo', // optional
        //    readonly: false,    // optional, default is false
        // },
        // ...
    },

    // use this for initialization
    onLoad: function onLoad() {},

    helpBack: function helpBack() {
        this.node.active = false;
    }

    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
});

cc._RFpop();
},{}],"help":[function(require,module,exports){
"use strict";
cc._RFpush(module, '8ac6861i4RAIZTpiPVOB0lJ', 'help');
// script\start\help.js

cc.Class({
    "extends": cc.Component,

    properties: {
        // foo: {
        //    default: null,      // The default value will be used only when the component attaching
        //                           to a node for the first time
        //    url: cc.Texture2D,  // optional, default is typeof default
        //    serializable: true, // optional, default is true
        //    visible: true,      // optional, default is true
        //    displayName: 'Foo', // optional
        //    readonly: false,    // optional, default is false
        // },
        // ...
    },

    // use this for initialization
    onLoad: function onLoad() {},

    help: function help() {
        this.node.active = true;
    }

    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
});

cc._RFpop();
},{}],"progressBarControl":[function(require,module,exports){
"use strict";
cc._RFpush(module, 'be9eeP/McZOp7aNzN1Lb6Y2', 'progressBarControl');
// script\game\progressBarControl.js

var Constants = require('Constants');
//const GAME_STATE = Constants.GAME_STATE;
var STAND = Constants.STAND;

cc.Class({
    "extends": cc.Component,

    properties: {
        // foo: {
        //    default: null,      // The default value will be used only when the component attaching
        //                           to a node for the first time
        //    url: cc.Texture2D,  // optional, default is typeof default
        //    serializable: true, // optional, default is true
        //    visible: true,      // optional, default is true
        //    displayName: 'Foo', // optional
        //    readonly: false,    // optional, default is false
        // },
        // ...
        remainingTime: 45
    },

    // use this for initialization
    onLoad: function onLoad() {},

    // called every frame, uncomment this function to activate update callback
    update: function update(dt) {
        if (this.getComponent(cc.ProgressBar).progress >= 0) {
            this.remainingTime -= dt;
            this.getComponent(cc.ProgressBar).progress = this.remainingTime / 45;
        } else {
            if (cc.find("Canvas").getComponent("gameManager").turn === STAND.BLUE) {
                cc.find("Canvas").getComponent("gameManager").turn = STAND.RED;
            } else if (cc.find("Canvas").getComponent("gameManager").turn === STAND.RED) {
                cc.find("Canvas").getComponent("gameManager").turn = STAND.BLUE;
            }
            this.getComponent(cc.ProgressBar).progress = 1;
            this.remainingTime = 45;
        }
    }
});

cc._RFpop();
},{"Constants":"Constants"}],"s_logout":[function(require,module,exports){
"use strict";
cc._RFpush(module, '27720vsgLVPoaHh7GYw0MbB', 's_logout');
// script\start\s_logout.js

cc.Class({
    "extends": cc.Component,

    properties: {
        // foo: {
        //    default: null,      // The default value will be used only when the component attaching
        //                           to a node for the first time
        //    url: cc.Texture2D,  // optional, default is typeof default
        //    serializable: true, // optional, default is true
        //    visible: true,      // optional, default is true
        //    displayName: 'Foo', // optional
        //    readonly: false,    // optional, default is false
        // },
        // ...
    },

    // use this for initialization
    onLoad: function onLoad() {},

    //logout
    ExitScene: function ExitScene() {
        cc.director.end();
    }

    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
});

cc._RFpop();
},{}],"startload":[function(require,module,exports){
"use strict";
cc._RFpush(module, 'ee12738az5N/r9qU+rPesd4', 'startload');
// script\start\startload.js

cc.Class({
    'extends': cc.Component,

    onLoad: function onLoad() {

        G.globalSocket = io.connect('127.0.0.1:8081');
        //断开连接后再重新连接需要加上{'force new connection': true}
        G.hallSocket = io.connect('127.0.0.1:8081/hall', { 'force new connection': true });
    }

});

cc._RFpop();
},{}],"start":[function(require,module,exports){
"use strict";
cc._RFpush(module, 'e235bdGgKpJPbyFlEuPKj8Z', 'start');
// script\start\start.js

cc.Class({
    'extends': cc.Component,

    properties: {
        // foo: {
        //    default: null,      // The default value will be used only when the component attaching
        //                           to a node for the first time
        //    url: cc.Texture2D,  // optional, default is typeof default
        //    serializable: true, // optional, default is true
        //    visible: true,      // optional, default is true
        //    displayName: 'Foo', // optional
        //    readonly: false,    // optional, default is false
        // },
        // ...
    },

    // use this for initialization
    onLoad: function onLoad() {},

    startfun: function startfun() {
        G.hallSocket.disconnect();
        cc.director.loadScene('finding');
    }

    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
});

cc._RFpop();
},{}],"test":[function(require,module,exports){
"use strict";
cc._RFpush(module, 'e56c9MuSi9A5ITKc94Pbb0J', 'test');
// script\game\test.js

var Constants = require('Constants');

var STAND = Constants.STAND;
cc.Class({
    'extends': cc.Component,

    properties: {

        chessNode: 0,

        chessType: 0,

        speed: cc.v2(0, 0),

        quality: 0,

        radius: 250,

        flag: 0, //0 and 1 are chessman , 2 is baffle ,3 is border

        circle: {
            'default': null,
            type: cc.Prefab
        },

        point_red: {
            'default': null,
            type: cc.Prefab
        }
    },

    onLoad: function onLoad() {

        var manager = cc.director.getCollisionManager();
        manager.enabled = true;

        //var testnum =0;

        var circleTemp = cc.instantiate(this.circle);
        var pointRed = cc.instantiate(this.point_red);
        var disX = 0;
        var disY = 0;
        var maxInitialSpeed = 18000 / Math.sqrt(this.quality);
        var moveable = 0;
        var upinfo = [0, 0, 0];

        this.node.on(cc.Node.EventType.TOUCH_START, function () {
            /*G.roomSocket.emit('Gstand',G.stand);    
            G.roomSocket.emit('gameturn',G.gameManager.turn); */
            if (G.stand === G.gameManager.turn) {
                /*G.roomSocket.emit('Gstand',G.stand);    
                G.roomSocket.emit('gameturn',G.gameManager.turn);*/
                if (this.chessType === 0 && G.gameManager.turn === STAND.BLUE) {
                    G.roomSocket.emit('dierblue');
                    this.node.addChild(circleTemp);
                    circleTemp.setPosition(0, 0);
                    this.node.addChild(pointRed);
                    pointRed.setPosition(0, 0);
                }
                if (this.chessType == 1 && G.gameManager.turn == STAND.RED) {
                    G.roomSocket.emit('dierred');
                    this.node.addChild(circleTemp);
                    circleTemp.setPosition(0, 0);
                    this.node.addChild(pointRed);
                    pointRed.setPosition(0, 0);
                }
            }
        }, this);
        this.node.on(cc.Node.EventType.TOUCH_MOVE, function (event) {
            if (G.stand === G.gameManager.turn) {
                var touches;
                var touchLoc;
                if (this.chessType === 0 && G.gameManager.turn === STAND.BLUE) {
                    moveable = 1;
                    touches = event.getTouches();
                    touchLoc = touches[0].getLocation();
                    disX = touchLoc.x - 540 - this.node.x;
                    disY = touchLoc.y - 960 - this.node.y;
                    if (disX * disX + disY * disY < this.radius * this.radius) {
                        pointRed.setPosition(disX, disY);
                    } else if (disX * disX + disY * disY < this.radius * this.radius * 3) {
                        disX = disX / Math.sqrt(disX * disX + disY * disY) * this.radius;
                        disY = disY / Math.sqrt(disX * disX + disY * disY) * this.radius;
                        pointRed.setPosition(disX, disY);
                    } else {
                        moveable = 0;
                        circleTemp.removeFromParent();
                        pointRed.removeFromParent();
                    }
                }

                if (this.chessType == 1 && G.gameManager.turn == STAND.RED) {
                    moveable = 1;
                    touches = event.getTouches();
                    touchLoc = touches[0].getLocation();
                    disX = touchLoc.x - 540 - this.node.x;
                    disY = touchLoc.y - 960 - this.node.y;
                    if (disX * disX + disY * disY < this.radius * this.radius) {
                        pointRed.setPosition(disX, disY);
                    } else if (disX * disX + disY * disY < this.radius * this.radius * 3) {
                        disX = disX / Math.sqrt(disX * disX + disY * disY) * this.radius;
                        disY = disY / Math.sqrt(disX * disX + disY * disY) * this.radius;
                        pointRed.setPosition(disX, disY);
                    } else {
                        moveable = 0;
                        circleTemp.removeFromParent();
                        pointRed.removeFromParent();
                    }
                }

                //G.roomSocket.emit('change turn');
            }
        }, this); //脚本运行至此，传出disX,disY两个参数，代表触摸点相对于棋子的位置，用以计算弹力的大小与方向
        this.node.on(cc.Node.EventType.TOUCH_END, function () {
            if (G.stand === G.gameManager.turn) {
                if (this.chessType === 0 && G.gameManager.turn == STAND.BLUE) {
                    if (moveable == 1) {
                        this.speed.x = Math.round(-disX / this.radius * maxInitialSpeed);
                        this.speed.y = Math.round(-disY / this.radius * maxInitialSpeed);
                        circleTemp.removeFromParent();
                        pointRed.removeFromParent();
                        moveable = 0;
                        upinfo[0] = this.chessNode;
                        upinfo[1] = this.speed.x;
                        upinfo[2] = this.speed.y;
                        G.roomSocket.emit('upinfo', upinfo);
                        G.gameManager.changeTurn();
                    } else {
                        circleTemp.removeFromParent();
                        pointRed.removeFromParent();
                    }
                }
                if (this.chessType === 1 && G.gameManager.turn == STAND.RED) {
                    if (moveable == 1) {
                        this.speed.x = Math.round(-disX / this.radius * maxInitialSpeed);
                        this.speed.y = Math.round(-disY / this.radius * maxInitialSpeed);
                        circleTemp.removeFromParent();
                        pointRed.removeFromParent();
                        moveable = 0;
                        upinfo[0] = this.chessNode;
                        upinfo[1] = this.speed.x;
                        upinfo[2] = this.speed.y;
                        G.roomSocket.emit('upinfo', upinfo);
                        G.gameManager.changeTurn();
                    } else {
                        circleTemp.removeFromParent();
                        pointRed.removeFromParent();
                    }
                }
            }
        }, this);
        this.node.on(cc.Node.EventType.TOUCH_CANCEL, function () {
            if (G.stand === G.gameManager.turn) {
                if (this.chessType === 0 && G.gameManager.turn == STAND.BLUE) {
                    if (moveable == 1) {
                        this.speed.x = Math.round(-disX / this.radius * maxInitialSpeed);
                        this.speed.y = Math.round(-disY / this.radius * maxInitialSpeed);
                        circleTemp.removeFromParent();
                        pointRed.removeFromParent();
                        moveable = 0;
                        upinfo[0] = this.chessNode;
                        upinfo[1] = this.speed.x;
                        upinfo[2] = this.speed.y;
                        G.roomSocket.emit('upinfo', upinfo);
                        G.gameManager.changeTurn();
                    } else {
                        circleTemp.removeFromParent();
                        pointRed.removeFromParent();
                    }
                }
                if (this.chessType === 1 && G.gameManager.turn == STAND.RED) {
                    if (moveable == 1) {
                        this.speed.x = Math.round(-disX / this.radius * maxInitialSpeed);
                        this.speed.y = Math.round(-disY / this.radius * maxInitialSpeed);
                        circleTemp.removeFromParent();
                        pointRed.removeFromParent();
                        moveable = 0;
                        upinfo[0] = this.chessNode;
                        upinfo[1] = this.speed.x;
                        upinfo[2] = this.speed.y;
                        G.roomSocket.emit('upinfo', upinfo);

                        G.gameManager.changeTurn();
                    } else {
                        circleTemp.removeFromParent();
                        pointRed.removeFromParent();
                    }
                }
            }
        }, this);
    },

    onCollisionEnter: function onCollisionEnter(other, self) {
        if (this.flag === 0) {
            if (other.getComponent("test").flag === 0) {
                //棋子对撞
                other.getComponent("test").flag = 1;
                var mA = this.quality;
                var mB = other.getComponent("test").quality;
                var xA = self.world.position.x;
                var yA = self.world.position.y;
                var xB = other.world.position.x;
                var yB = other.world.position.y;
                var vxA = this.speed.x;
                var vyA = this.speed.y;
                var vxB = other.getComponent("test").speed.x;
                var vyB = other.getComponent("test").speed.y;
                var alpha = Math.atan((yB - yA) / (xB - xA));
                var v1 = Math.sin(alpha) * vyA + Math.cos(alpha) * vxA;
                var v2 = Math.sin(alpha) * vyB + Math.cos(alpha) * vxB;
                var v11 = (2 * mB * v2 + (mA - mB) * v1) / (mA + mB) * 0.8;
                var v22 = (2 * mA * v1 + (mB - mA) * v2) / (mA + mB) * 0.8;

                this.speed.x = Math.cos(alpha) * v11 - Math.sin(alpha) * (Math.cos(alpha) * vyA - Math.sin(alpha) * vxA);
                this.speed.y = Math.cos(alpha) * (Math.cos(alpha) * vyA - Math.sin(alpha) * vxA) + Math.sin(alpha) * v11;
                other.getComponent("test").speed.x = Math.cos(alpha) * v22 - Math.sin(alpha) * (Math.cos(alpha) * vyB - Math.sin(alpha) * vxB);
                other.getComponent("test").speed.y = Math.cos(alpha) * (Math.cos(alpha) * vyB - Math.sin(alpha) * vxB) + Math.sin(alpha) * v22;
            } else if (other.getComponent("test").flag === 2) {
                //棋子撞板
                var radiusOfSelf = 0;

                if (this.quality == 500) {
                    radiusOfSelf = 50;
                } else if (this.quality == 300) {
                    radiusOfSelf = 35;
                } else {
                    radiusOfSelf = 25;
                }
                if (Math.abs(this.node.x) > -radiusOfSelf + 250) {
                    this.speed.y = -this.speed.y * 0.8;
                } else {
                    this.speed.x = -this.speed.x * 0.8;
                }
            } else if (other.getComponent("test").flag === 3) {
                //棋子撞边界
                if (this.chessType === 0) {
                    G.gameManager.bluenum--;
                    G.gameManager.judge();
                } else {
                    G.gameManager.rednum--;
                    G.gameManager.judge();
                }
                G.roomSocket.emit('dis', this.node.chessNode);
                this.node.destroy();
            }
        } else if (this.flag === 1) {
            this.flag = 0;
        }
    },

    update: function update(dt) {
        var acce = 520;
        if (this.speed.x > 0) {
            this.speed.x -= acce * Math.abs(this.speed.x) / Math.sqrt(this.speed.x * this.speed.x + this.speed.y * this.speed.y) * dt;
        } else if (this.speed.x < 0) {
            this.speed.x += acce * Math.abs(this.speed.x) / Math.sqrt(this.speed.x * this.speed.x + this.speed.y * this.speed.y) * dt;
        }
        if (this.speed.y > 0) {
            this.speed.y -= acce * Math.abs(this.speed.y) / Math.sqrt(this.speed.x * this.speed.x + this.speed.y * this.speed.y) * dt;
        } else if (this.speed.y < 0) {
            this.speed.y += acce * Math.abs(this.speed.y) / Math.sqrt(this.speed.x * this.speed.x + this.speed.y * this.speed.y) * dt;
        } //随时间更新速度并确保单向运动

        this.node.x += this.speed.x * dt;
        this.node.y += this.speed.y * dt;
    }

});

cc._RFpop();
},{"Constants":"Constants"}],"winload":[function(require,module,exports){
"use strict";
cc._RFpush(module, 'f63fdYIPrZDlrFtuMWp3rNq', 'winload');
// script\win\winload.js

var Constants = require('Constants');

cc.Class({
    'extends': cc.Component,

    properties: {
        infoLabel: cc.Label
    },

    // use this for initialization
    onLoad: function onLoad() {
        console.log(G.wintype);
        //this.infoLabel.string = ' 蓝色方 获胜！ ';
        if (G.wintype == 'redwin') {
            this.infoLabel.string = ' 黄色方 获胜！ ';
        }
        if (G.wintype == 'bluewin') {
            this.infoLabel.string = ' 紫色方 获胜！ ';
        }
        if (G.wintype == 'discon') {
            this.infoLabel.string = ' 你的对手已离开 ';
        }
        if (G.wintype === null) {
            this.infoLabel.string = '';
        }
    }

});
// called every frame, uncomment this function to activate update callback
// update: function (dt) {

// },

cc._RFpop();
},{"Constants":"Constants"}]},{},["back","findingload","gameManager","progressBarControl","test","help","help_back","s_logout","start","startload","Constants","Global","backfind","backstart","winload"])

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIkM6L0NvY29zQ3JlYXRvci9yZXNvdXJjZXMvYXBwLmFzYXIvbm9kZV9tb2R1bGVzL2Jyb3dzZXItcGFjay9fcHJlbHVkZS5qcyIsImFzc2V0cy9zY3JpcHQvdXRpbC9Db25zdGFudHMuanMiLCJhc3NldHMvc2NyaXB0L3V0aWwvR2xvYmFsLmpzIiwiYXNzZXRzL3NjcmlwdC93aW4vYmFja2ZpbmQuanMiLCJhc3NldHMvc2NyaXB0L3dpbi9iYWNrc3RhcnQuanMiLCJhc3NldHMvc2NyaXB0L2ZpbmRpbmcvYmFjay5qcyIsImFzc2V0cy9zY3JpcHQvZmluZGluZy9maW5kaW5nbG9hZC5qcyIsImFzc2V0cy9zY3JpcHQvZ2FtZS9nYW1lTWFuYWdlci5qcyIsImFzc2V0cy9zY3JpcHQvc3RhcnQvaGVscF9iYWNrLmpzIiwiYXNzZXRzL3NjcmlwdC9zdGFydC9oZWxwLmpzIiwiYXNzZXRzL3NjcmlwdC9nYW1lL3Byb2dyZXNzQmFyQ29udHJvbC5qcyIsImFzc2V0cy9zY3JpcHQvc3RhcnQvc19sb2dvdXQuanMiLCJhc3NldHMvc2NyaXB0L3N0YXJ0L3N0YXJ0bG9hZC5qcyIsImFzc2V0cy9zY3JpcHQvc3RhcnQvc3RhcnQuanMiLCJhc3NldHMvc2NyaXB0L2dhbWUvdGVzdC5qcyIsImFzc2V0cy9zY3JpcHQvd2luL3dpbmxvYWQuanMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7Ozs7O0FDQUE7QUFDSTtBQUNBO0FBQ0o7QUFDQTtBQUNBO0FBQ0k7QUFDQTtBQUNBO0FBQ0o7QUFDQTtBQUNBO0FBQ0k7QUFDQTtBQUNBO0FBQ0o7QUFDQTtBQUVBO0FBQ0k7QUFDQTtBQUNBO0FBQUo7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUM1QkE7QUFDSTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNKO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ2RBO0FBQ0k7QUFDSjtBQUNJO0FBQ0o7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDSTtBQUNKO0FBR0k7QUFESjtBQUdRO0FBRFI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDbENBO0FBQ0k7QUFDSjtBQUNJO0FBQ0o7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDSTtBQUNKO0FBR0k7QUFESjtBQUdRO0FBRFI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDbENBO0FBQ0k7QUFDSjtBQUNJO0FBQ0o7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDSTtBQUNKO0FBR0k7QUFDSTtBQUNBO0FBRFI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDbENBO0FBQ0E7QUFDQTtBQUNJO0FBQ0o7QUFDSTtBQUNKO0FBQ1E7QUFDUjtBQUNBO0FBQ0k7QUFDSjtBQUNRO0FBQ0E7QUFDUjtBQUNZO0FBQ0k7QUFDaEI7QUFDZ0I7QUFDaEI7QUFDZ0I7QUFDaEI7QUFDZ0I7QUFDaEI7QUFDQTtBQUNRO0FBQ0k7QUFDQTtBQUNaO0FBQ1k7QUFDQTtBQUNaO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ3hDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0k7QUFDSjtBQUNJO0FBQ0o7QUFDUTtBQUNJO0FBQ0E7QUFDWjtBQUNBO0FBQ0E7QUFDQTtBQUNRO0FBQ0E7QUFDUjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNJO0FBQ0o7QUFDUTtBQUNBO0FBQ0k7QUFDWjtBQUNZO0FBQ0E7QUFDWjtBQUNBO0FBQ1E7QUFDUjtBQUNZO0FBQ0E7QUFDWjtBQUNZO0FBQ1o7QUFDQTtBQUdRO0FBRFI7QUFHWTtBQUNBO0FBRFo7QUFHWTtBQURaO0FBQ0E7QUFJUTtBQUZSO0FBSVk7QUFDQTtBQUZaO0FBQ0E7QUFNUTtBQUpSO0FBT1k7QUFMWjtBQUNBO0FBT1E7QUFDSTtBQUNBO0FBQ0E7QUFDQTtBQUxaO0FBT1k7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBTFo7QUFPWTtBQUNBO0FBTFo7QUFPWTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFMWjtBQU9ZO0FBQ0E7QUFMWjtBQU9ZO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUxaO0FBT1k7QUFDQTtBQUxaO0FBT1k7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBTFo7QUFPWTtBQUNBO0FBTFo7QUFPWTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFMWjtBQU9ZO0FBQ0E7QUFMWjtBQU9ZO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUxaO0FBT1k7QUFDQTtBQUxaO0FBT1k7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBTFo7QUFPWTtBQUNBO0FBTFo7QUFPWTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFMWjtBQU9ZO0FBQ0E7QUFMWjtBQU9ZO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUxaO0FBT1k7QUFDQTtBQUxaO0FBT1k7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBTFo7QUFPWTtBQUNBO0FBTFo7QUFPWTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFMWjtBQU9ZO0FBQ0E7QUFMWjtBQU9ZO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUxaO0FBT1k7QUFDQTtBQUxaO0FBT1k7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBTFo7QUFPWTtBQUNBO0FBTFo7QUFPWTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFMWjtBQU9ZO0FBQ0E7QUFMWjtBQU9ZO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUxaO0FBT1k7QUFDQTtBQUxaO0FBT1k7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBTFo7QUFDQTtBQUNBO0FBQ0E7QUFTSTtBQVBKO0FBV1E7QUFUUjtBQVdRO0FBVFI7QUFXWTtBQVRaO0FBV1k7QUFUWjtBQUNBO0FBQ0E7QUFZUTtBQVZSO0FBQ0E7QUFZWTtBQVZaO0FBQ0E7QUFDQTtBQVlRO0FBVlI7QUFZWTtBQVZaO0FBWVk7QUFWWjtBQUNBO0FBWVE7QUFWUjtBQVlZO0FBVlo7QUFDQTtBQVlRO0FBVlI7QUFZWTtBQVZaO0FBQ0E7QUFZUTtBQVZSO0FBWVk7QUFWWjtBQUNBO0FBQ0E7QUFZUTtBQVZSO0FBWVk7QUFWWjtBQUNBO0FBWVE7QUFWUjtBQVlZO0FBVlo7QUFDQTtBQVlRO0FBVlI7QUFZWTtBQVZaO0FBQ0E7QUFZUTtBQVZSO0FBWVk7QUFWWjtBQUNBO0FBQ0E7QUFZUTtBQVZSO0FBWVk7QUFWWjtBQUNBO0FBWVE7QUFWUjtBQVlZO0FBVlo7QUFDQTtBQVlRO0FBVlI7QUFZWTtBQVZaO0FBQ0E7QUFDQTtBQVlRO0FBVlI7QUFZWTtBQVZaO0FBQ0E7QUFZUTtBQVZSO0FBWVk7QUFWWjtBQUNBO0FBWVE7QUFWUjtBQVlZO0FBVlo7QUFDQTtBQUNBO0FBQ0E7QUFlSTtBQWJKO0FBZ0JRO0FBZFI7QUFnQlE7QUFkUjtBQWdCWTtBQWRaO0FBZ0JZO0FBQ0E7QUFDQTtBQUNBO0FBZFo7QUFDQTtBQWlCUTtBQWZSO0FBaUJZO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFmWjtBQUNBO0FBaUJRO0FBZlI7QUFpQlk7QUFmWjtBQWlCWTtBQUNBO0FBQ0E7QUFDQTtBQWZaO0FBaUJRO0FBQ0k7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQWZaO0FBaUJRO0FBQ0k7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQWZaO0FBaUJRO0FBQ0k7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQWZaO0FBQ0E7QUFpQlE7QUFDSTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBZlo7QUFpQlE7QUFDSTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBZlo7QUFpQlE7QUFDSTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBZlo7QUFpQlE7QUFDSTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBZlo7QUFDQTtBQWlCUTtBQUNJO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFmWjtBQWlCUTtBQUNJO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFmWjtBQWlCUTtBQUNJO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFmWjtBQUNBO0FBaUJRO0FBQ0k7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQWZaO0FBaUJRO0FBQ0k7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQWZaO0FBaUJRO0FBQ0k7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQWZaO0FBQ0E7QUFDQTtBQW1CSTtBQWpCSjtBQW1CUTtBQUNBO0FBQ0E7QUFqQlI7QUFtQlk7QUFqQlo7QUFtQlk7QUFDQTtBQWpCWjtBQUNBO0FBbUJRO0FBakJSO0FBbUJZO0FBQ0E7QUFDQTtBQWpCWjtBQUNBO0FBbUJRO0FBakJSO0FBbUJZO0FBakJaO0FBbUJZO0FBQ0E7QUFqQlo7QUFtQlE7QUFDSTtBQUNBO0FBQ0E7QUFqQlo7QUFtQlE7QUFDSTtBQUNBO0FBQ0E7QUFqQlo7QUFtQlE7QUFDSTtBQUNBO0FBQ0E7QUFqQlo7QUFDQTtBQW1CUTtBQUNJO0FBQ0E7QUFDQTtBQWpCWjtBQW1CUTtBQUNJO0FBQ0E7QUFDQTtBQWpCWjtBQW1CUTtBQUNJO0FBQ0E7QUFDQTtBQWpCWjtBQW1CUTtBQUNJO0FBQ0E7QUFDQTtBQWpCWjtBQUNBO0FBbUJRO0FBQ0k7QUFDQTtBQUNBO0FBakJaO0FBbUJRO0FBQ0k7QUFDQTtBQUNBO0FBakJaO0FBbUJRO0FBQ0k7QUFDQTtBQUNBO0FBakJaO0FBQ0E7QUFtQlE7QUFDSTtBQUNBO0FBQ0E7QUFqQlo7QUFtQlE7QUFDSTtBQUNBO0FBQ0E7QUFqQlo7QUFtQlE7QUFDSTtBQUNBO0FBQ0E7QUFqQlo7QUFDQTtBQUNBO0FBb0JJO0FBQ0k7QUFDSTtBQUNBO0FBQ0E7QUFsQlo7QUFvQlk7QUFDQTtBQUNBO0FBbEJaO0FBQ0E7QUFDQTtBQXFCSTtBQUNJO0FBQ0k7QUFDQTtBQW5CWjtBQXFCUTtBQUNJO0FBQ0E7QUFuQlo7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDamtCQTtBQUNJO0FBQ0o7QUFDSTtBQUNKO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0k7QUFDSjtBQUdJO0FBQ0k7QUFEUjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUNqQ0E7QUFDSTtBQUNKO0FBQ0k7QUFDSjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNJO0FBQ0o7QUFHSTtBQUNRO0FBRFo7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDakNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDSTtBQUNKO0FBR0k7QUFESjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUdRO0FBRFI7QUFDQTtBQUNBO0FBR0k7QUFESjtBQUNBO0FBS0k7QUFDSTtBQUNJO0FBQ0E7QUFIWjtBQUtZO0FBQ0k7QUFIaEI7QUFLZ0I7QUFIaEI7QUFLWTtBQUNBO0FBSFo7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQzdDQTtBQUNJO0FBQ0o7QUFDSTtBQUNKO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0k7QUFDSjtBQUNBO0FBR0k7QUFDSTtBQURSO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ2xDQTtBQUNJO0FBQ0o7QUFDSTtBQUNKO0FBQ1E7QUFDUjtBQUNRO0FBQ1I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ2hCQTtBQUNJO0FBQ0o7QUFDSTtBQUNKO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0k7QUFDSjtBQUdJO0FBQ0k7QUFDQTtBQURSO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ2xDQTtBQUNBO0FBQ0E7QUFDQTtBQUNJO0FBQ0o7QUFDSTtBQUNKO0FBQ1E7QUFDUjtBQUNRO0FBQ1I7QUFDUTtBQUNSO0FBQ1E7QUFDUjtBQUdRO0FBRFI7QUFHUTtBQURSO0FBR1E7QUFDSTtBQUNBO0FBRFo7QUFDQTtBQUdRO0FBQ0k7QUFDQTtBQURaO0FBQ0E7QUFDQTtBQUlJO0FBRko7QUFNUTtBQUNBO0FBSlI7QUFDQTtBQUNBO0FBTVE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFKUjtBQVFRO0FBTlI7QUFDQTtBQVFZO0FBTlo7QUFDQTtBQVFZO0FBQ0k7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQU5oQjtBQVFZO0FBQ0k7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQU5oQjtBQUNBO0FBQ0E7QUFRUTtBQUNJO0FBQ0E7QUFDQTtBQUNBO0FBQ0k7QUFDSjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0k7QUFOaEI7QUFRZ0I7QUFDQTtBQUNBO0FBTmhCO0FBUWdCO0FBQ0E7QUFDQTtBQU5oQjtBQUNBO0FBQ0E7QUFRWTtBQUNJO0FBQ0o7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNJO0FBTmhCO0FBUWdCO0FBQ0E7QUFDQTtBQU5oQjtBQVFnQjtBQUNBO0FBQ0E7QUFOaEI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBU1E7QUFDSTtBQUNBO0FBQ0k7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQVBoQjtBQVNnQjtBQUNBO0FBUGhCO0FBQ0E7QUFTWTtBQUNJO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFQaEI7QUFTZ0I7QUFDQTtBQVBoQjtBQUNBO0FBQ0E7QUFDQTtBQVNRO0FBQ0k7QUFDQTtBQUNBO0FBQ0k7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFQaEI7QUFTZ0I7QUFDQTtBQVBoQjtBQUNBO0FBU1k7QUFDQTtBQUNJO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQVBoQjtBQVNnQjtBQVBoQjtBQVNnQjtBQUNBO0FBUGhCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQWVJO0FBQ0k7QUFDSTtBQWJaO0FBY2dCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBWmhCO0FBY2dCO0FBQ0E7QUFDQTtBQUNBO0FBWmhCO0FBQ0E7QUFhZ0I7QUFYaEI7QUFhZ0I7QUFBeUI7QUFWekM7QUFXOEM7QUFUOUM7QUFVcUI7QUFSckI7QUFTZ0I7QUFBOEM7QUFOOUQ7QUFPcUI7QUFMckI7QUFDQTtBQUNBO0FBS2dCO0FBQ0k7QUFDQTtBQUhwQjtBQUtvQjtBQUNBO0FBSHBCO0FBS2dCO0FBQ0E7QUFIaEI7QUFDQTtBQUtZO0FBSFo7QUFDQTtBQUNBO0FBTUk7QUFDSTtBQUNBO0FBQ0k7QUFKWjtBQU1ZO0FBSlo7QUFNUTtBQUNJO0FBSlo7QUFNWTtBQUpaO0FBQ0E7QUFNUTtBQUNBO0FBSlI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ2pSQTtBQUNBO0FBQ0E7QUFDSTtBQUNKO0FBQ0k7QUFDSTtBQUNSO0FBQ0E7QUFDQTtBQUNJO0FBQ0k7QUFDUjtBQUNRO0FBQ0k7QUFDWjtBQUNRO0FBQ0k7QUFDWjtBQUNRO0FBQ0k7QUFDWjtBQUNRO0FBQ0k7QUFDWjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXNDb250ZW50IjpbIihmdW5jdGlvbiBlKHQsbixyKXtmdW5jdGlvbiBzKG8sdSl7aWYoIW5bb10pe2lmKCF0W29dKXt2YXIgYT10eXBlb2YgcmVxdWlyZT09XCJmdW5jdGlvblwiJiZyZXF1aXJlO2lmKCF1JiZhKXJldHVybiBhKG8sITApO2lmKGkpcmV0dXJuIGkobywhMCk7dmFyIGY9bmV3IEVycm9yKFwiQ2Fubm90IGZpbmQgbW9kdWxlICdcIitvK1wiJ1wiKTt0aHJvdyBmLmNvZGU9XCJNT0RVTEVfTk9UX0ZPVU5EXCIsZn12YXIgbD1uW29dPXtleHBvcnRzOnt9fTt0W29dWzBdLmNhbGwobC5leHBvcnRzLGZ1bmN0aW9uKGUpe3ZhciBuPXRbb11bMV1bZV07cmV0dXJuIHMobj9uOmUpfSxsLGwuZXhwb3J0cyxlLHQsbixyKX1yZXR1cm4gbltvXS5leHBvcnRzfXZhciBpPXR5cGVvZiByZXF1aXJlPT1cImZ1bmN0aW9uXCImJnJlcXVpcmU7Zm9yKHZhciBvPTA7bzxyLmxlbmd0aDtvKyspcyhyW29dKTtyZXR1cm4gc30pIiwiY29uc3QgU1RBTkQgPSBjYy5FbnVtKHtcbiAgICBSRUQ6IDEsXG4gICAgQkxVRTogMixcbn0pO1xuXG5jb25zdCBDSEVTU19UWVBFID0gY2MuRW51bSh7XG4gICAgTk9ORTogLTEsXG4gICAgUkVEOiAxLFxuICAgIEJMVUU6IC0xLFxufSk7XG5cbmNvbnN0IEdBTUVfU1RBVEUgPSBjYy5FbnVtKHtcbiAgICBQUkVQQVJFOiAtMSxcbiAgICBQTEFZSU5HOiAtMSxcbiAgICBPVkVSOiAtMSxcbn0pO1xuXG5cbm1vZHVsZS5leHBvcnRzID0ge1xuICAgIFNUQU5EOlNUQU5ELFxuICAgIENIRVNTX1RZUEU6Q0hFU1NfVFlQRSxcbiAgICBHQU1FX1NUQVRFOkdBTUVfU1RBVEUsXG5cbn07Iiwid2luZG93LkcgPSB7XG4gICAgZ2xvYmFsU29ja2V0Om51bGwsLy/lhajlsYBcbiAgICBoYWxsU29ja2V0Om51bGwsLy/lpKfljoVcbiAgICBxdWV1ZVNvY2tldDpudWxsLC8v6Zif5YiXXG4gICAgcm9vbVNvY2tldDpudWxsLC8v5oi/6Ze0XG4gICAgd2ludHlwZSA6IG51bGwsXG4gICAgZ2FtZU1hbmFnZXI6bnVsbCxcbiAgICBzdGFuZDpudWxsLFxufSIsImNjLkNsYXNzKHtcclxuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcclxuXHJcbiAgICBwcm9wZXJ0aWVzOiB7XHJcbiAgICAgICAgLy8gZm9vOiB7XHJcbiAgICAgICAgLy8gICAgZGVmYXVsdDogbnVsbCwgICAgICAvLyBUaGUgZGVmYXVsdCB2YWx1ZSB3aWxsIGJlIHVzZWQgb25seSB3aGVuIHRoZSBjb21wb25lbnQgYXR0YWNoaW5nXHJcbiAgICAgICAgLy8gICAgICAgICAgICAgICAgICAgICAgICAgICB0byBhIG5vZGUgZm9yIHRoZSBmaXJzdCB0aW1lXHJcbiAgICAgICAgLy8gICAgdXJsOiBjYy5UZXh0dXJlMkQsICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0eXBlb2YgZGVmYXVsdFxyXG4gICAgICAgIC8vICAgIHNlcmlhbGl6YWJsZTogdHJ1ZSwgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgdHJ1ZVxyXG4gICAgICAgIC8vICAgIHZpc2libGU6IHRydWUsICAgICAgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgdHJ1ZVxyXG4gICAgICAgIC8vICAgIGRpc3BsYXlOYW1lOiAnRm9vJywgLy8gb3B0aW9uYWxcclxuICAgICAgICAvLyAgICByZWFkb25seTogZmFsc2UsICAgIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIGZhbHNlXHJcbiAgICAgICAgLy8gfSxcclxuICAgICAgICAvLyAuLi5cclxuICAgIH0sXHJcblxyXG4gICAgLy8gdXNlIHRoaXMgZm9yIGluaXRpYWxpemF0aW9uXHJcbiAgICBvbkxvYWQ6IGZ1bmN0aW9uICgpIHtcclxuICAgICAgICBcclxuICAgIH0sXHJcbiAgICBcclxuICAgIGJhY2tmaW5kZnVuOiBmdW5jdGlvbigpIHtcclxuICAgICAgICAvL0cuaGFsbFNvY2tldC5kaXNjb25uZWN0KCk7XHJcbiAgICAgICAgY2MuZGlyZWN0b3IubG9hZFNjZW5lKCdmaW5kaW5nJyk7XHJcbiAgICB9XHJcblxyXG4gICAgLy8gY2FsbGVkIGV2ZXJ5IGZyYW1lLCB1bmNvbW1lbnQgdGhpcyBmdW5jdGlvbiB0byBhY3RpdmF0ZSB1cGRhdGUgY2FsbGJhY2tcclxuICAgIC8vIHVwZGF0ZTogZnVuY3Rpb24gKGR0KSB7XHJcblxyXG4gICAgLy8gfSxcclxufSk7XHJcbiIsImNjLkNsYXNzKHtcclxuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcclxuXHJcbiAgICBwcm9wZXJ0aWVzOiB7XHJcbiAgICAgICAgLy8gZm9vOiB7XHJcbiAgICAgICAgLy8gICAgZGVmYXVsdDogbnVsbCwgICAgICAvLyBUaGUgZGVmYXVsdCB2YWx1ZSB3aWxsIGJlIHVzZWQgb25seSB3aGVuIHRoZSBjb21wb25lbnQgYXR0YWNoaW5nXHJcbiAgICAgICAgLy8gICAgICAgICAgICAgICAgICAgICAgICAgICB0byBhIG5vZGUgZm9yIHRoZSBmaXJzdCB0aW1lXHJcbiAgICAgICAgLy8gICAgdXJsOiBjYy5UZXh0dXJlMkQsICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0eXBlb2YgZGVmYXVsdFxyXG4gICAgICAgIC8vICAgIHNlcmlhbGl6YWJsZTogdHJ1ZSwgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgdHJ1ZVxyXG4gICAgICAgIC8vICAgIHZpc2libGU6IHRydWUsICAgICAgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgdHJ1ZVxyXG4gICAgICAgIC8vICAgIGRpc3BsYXlOYW1lOiAnRm9vJywgLy8gb3B0aW9uYWxcclxuICAgICAgICAvLyAgICByZWFkb25seTogZmFsc2UsICAgIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIGZhbHNlXHJcbiAgICAgICAgLy8gfSxcclxuICAgICAgICAvLyAuLi5cclxuICAgIH0sXHJcblxyXG4gICAgLy8gdXNlIHRoaXMgZm9yIGluaXRpYWxpemF0aW9uXHJcbiAgICBvbkxvYWQ6IGZ1bmN0aW9uICgpIHtcclxuICAgICAgICBcclxuICAgIH0sXHJcbiAgICBcclxuICAgIGJhY2tzdGFydGZ1bjogZnVuY3Rpb24oKSB7XHJcbiAgICAgICAgLy9HLmhhbGxTb2NrZXQuZGlzY29ubmVjdCgpO1xyXG4gICAgICAgIGNjLmRpcmVjdG9yLmxvYWRTY2VuZSgnc3RhcnQnKTtcclxuICAgIH1cclxuXHJcbiAgICAvLyBjYWxsZWQgZXZlcnkgZnJhbWUsIHVuY29tbWVudCB0aGlzIGZ1bmN0aW9uIHRvIGFjdGl2YXRlIHVwZGF0ZSBjYWxsYmFja1xyXG4gICAgLy8gdXBkYXRlOiBmdW5jdGlvbiAoZHQpIHtcclxuXHJcbiAgICAvLyB9LFxyXG59KTtcclxuIiwiY2MuQ2xhc3Moe1xyXG4gICAgZXh0ZW5kczogY2MuQ29tcG9uZW50LFxyXG5cclxuICAgIHByb3BlcnRpZXM6IHtcclxuICAgICAgICAvLyBmb286IHtcclxuICAgICAgICAvLyAgICBkZWZhdWx0OiBudWxsLCAgICAgIC8vIFRoZSBkZWZhdWx0IHZhbHVlIHdpbGwgYmUgdXNlZCBvbmx5IHdoZW4gdGhlIGNvbXBvbmVudCBhdHRhY2hpbmdcclxuICAgICAgICAvLyAgICAgICAgICAgICAgICAgICAgICAgICAgIHRvIGEgbm9kZSBmb3IgdGhlIGZpcnN0IHRpbWVcclxuICAgICAgICAvLyAgICB1cmw6IGNjLlRleHR1cmUyRCwgIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHR5cGVvZiBkZWZhdWx0XHJcbiAgICAgICAgLy8gICAgc2VyaWFsaXphYmxlOiB0cnVlLCAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0cnVlXHJcbiAgICAgICAgLy8gICAgdmlzaWJsZTogdHJ1ZSwgICAgICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0cnVlXHJcbiAgICAgICAgLy8gICAgZGlzcGxheU5hbWU6ICdGb28nLCAvLyBvcHRpb25hbFxyXG4gICAgICAgIC8vICAgIHJlYWRvbmx5OiBmYWxzZSwgICAgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgZmFsc2VcclxuICAgICAgICAvLyB9LFxyXG4gICAgICAgIC8vIC4uLlxyXG4gICAgfSxcclxuXHJcbiAgICAvLyB1c2UgdGhpcyBmb3IgaW5pdGlhbGl6YXRpb25cclxuICAgIG9uTG9hZDogZnVuY3Rpb24gKCkge1xyXG5cclxuICAgIH0sXHJcbiAgICBcclxuICAgIGJhY2tmdW46IGZ1bmN0aW9uKCl7XHJcbiAgICAgICAgRy5xdWV1ZVNvY2tldC5kaXNjb25uZWN0KCk7XHJcbiAgICAgICAgY2MuZGlyZWN0b3IubG9hZFNjZW5lKCdzdGFydCcpOyAgXHJcbiAgICB9LFxyXG5cclxuICAgIC8vIGNhbGxlZCBldmVyeSBmcmFtZSwgdW5jb21tZW50IHRoaXMgZnVuY3Rpb24gdG8gYWN0aXZhdGUgdXBkYXRlIGNhbGxiYWNrXHJcbiAgICAvLyB1cGRhdGU6IGZ1bmN0aW9uIChkdCkge1xyXG5cclxuICAgIC8vIH0sXHJcbn0pO1xyXG4iLCJjb25zdCBDb25zdGFudHMgPSByZXF1aXJlKCdDb25zdGFudHMnKTtcbmNvbnN0IFNUQU5EID0gQ29uc3RhbnRzLlNUQU5EO1xuY2MuQ2xhc3Moe1xuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcbiAgICBcbiAgICBwcm9wZXJ0aWVzOiB7XG4gICAgICAgIFxuICAgICAgICBpbmZvTGFiZWw6IGNjLkxhYmVsLFxuICAgIH0sXG5cbiAgICBvbkxvYWQ6IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgXG4gICAgICAgIEcucXVldWVTb2NrZXQgPSBpby5jb25uZWN0KCcxMjcuMC4wLjE6ODA4MS9xdWV1ZScsIHsgJ2ZvcmNlIG5ldyBjb25uZWN0aW9uJzogdHJ1ZSB9KTtcbiAgICAgICAgRy5xdWV1ZVNvY2tldC5vbignc2V0IHN0YW5kJywgZnVuY3Rpb24gKHN0YW5kKSB7XG4gICAgICAgICAgICBcbiAgICAgICAgICAgIGlmIChzdGFuZCA9PT0gJ0JMVUUnKSB7XG4gICAgICAgICAgICAgICAgRy5zdGFuZCA9IFNUQU5ELkJMVUU7XG4gICAgICAgICAgICAgICAgXG4gICAgICAgICAgICAgICAgRy5xdWV1ZVNvY2tldC5lbWl0KCdmaW5kYmx1ZScsRy5zdGFuZCk7XG4gICAgICAgICAgICB9IGVsc2UgaWYgKHN0YW5kID09PSAnUkVEJykge1xuICAgICAgICAgICAgICAgIEcuc3RhbmQgPSBTVEFORC5SRUQ7XG4gICAgICAgICAgICAgICAgXG4gICAgICAgICAgICAgICAgRy5xdWV1ZVNvY2tldC5lbWl0KCdmaW5kcmVkJyxHLnN0YW5kKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgICAgIEcucXVldWVTb2NrZXQub24oJ21hdGNoIHN1Y2Nlc3MnLCBmdW5jdGlvbiAocm9vbUlkKSB7XG4gICAgICAgICAgICBjYy5sb2coJ21hdGNoIHN1Y2Nlc3MnICsgcm9vbUlkKTtcbiAgICAgICAgICAgIEcucm9vbVNvY2tldCA9IGlvLmNvbm5lY3QoJzEyNy4wLjAuMTo4MDgxL3Jvb21zJyArIHJvb21JZCwgeyAnZm9yY2UgbmV3IGNvbm5lY3Rpb24nOiB0cnVlIH0pO1xuICAgICAgICAgICAgXG4gICAgICAgICAgICBHLnF1ZXVlU29ja2V0LmRpc2Nvbm5lY3QoKTtcbiAgICAgICAgICAgIGNjLmRpcmVjdG9yLmxvYWRTY2VuZSgnYm9hcmQnKTtcbiAgICAgICAgfSk7XG4gICAgfSxcblxuICAgXG59KTtcbiIsImNvbnN0IENvbnN0YW50cyA9IHJlcXVpcmUoJ0NvbnN0YW50cycpO1xuLy9jb25zdCBHQU1FX1NUQVRFID0gQ29uc3RhbnRzLkdBTUVfU1RBVEU7XG5jb25zdCBTVEFORCA9IENvbnN0YW50cy5TVEFORDtcblxuY2MuQ2xhc3Moe1xuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcblxuICAgIHByb3BlcnRpZXM6IHtcbiAgICAgICAgXG4gICAgICAgIHR1cm46IHtcbiAgICAgICAgICAgIGRlZmF1bHQ6IFNUQU5ELkJMVUUsXG4gICAgICAgICAgICB0eXBlOiBTVEFORFxuICAgICAgICB9LFxuICAgICAgICBcbiAgICAgICAgLy90eXBlOiBudWxsLFxuICAgICAgICBcbiAgICAgICAgYmx1ZW51bTo4LFxuICAgICAgICByZWRudW06OCxcbiAgICAgICAgXG4gICAgICAgIC8vdHVybk51bTowLFxuICAgICAgICAvL2luZm9QYW5lbDogY2MuTm9kZSxcbiAgICAgICAgXG4gICAgfSxcblxuICAgIC8vIHVzZSB0aGlzIGZvciBpbml0aWFsaXphdGlvblxuICAgIG9uTG9hZDogZnVuY3Rpb24gKCkge1xuICAgICAgICBcbiAgICAgICAgRy5nYW1lTWFuYWdlciA9IHRoaXM7XG4gICAgICAgIGlmKEcuc3RhbmQ9PT1TVEFORC5CTFVFKXtcbiAgICAgICAgICAgIEcucm9vbVNvY2tldC5lbWl0KCdoYXZlYmx1ZScsRy5zdGFuZCk7IFxuICAgICAgICB9ZWxzZXtcbiAgICAgICAgICAgIEcuc3RhbmQ9U1RBTkQuUkVEO1xuICAgICAgICAgICAgRy5yb29tU29ja2V0LmVtaXQoJ2hhdmVyZWQnLEcuc3RhbmQpOyBcbiAgICAgICAgfVxuICAgICAgICAvL2NjLmZpbmQoXCJDYW52YXMvY2hlc3Nib2FyZC9iaWdDaGVzc19ibHVlXCIpLmdldENvbXBvbmVudChcInRlc3RcIikuc3BlZWQueCA9IDUwMDtcbiAgICAgICAgRy5yb29tU29ja2V0Lm9uKCd1cGluZm8nLGZ1bmN0aW9uKHVwaW5mbyl7XG4gICAgICAgICAgICBcbiAgICAgICAgICAgIHVwaW5mbyA9IHVwaW5mbztcbiAgICAgICAgICAgIEcuZ2FtZU1hbmFnZXIuZ2FtZXVwaW5mbyh1cGluZm8pO1xuICAgICAgICAgICAgXG4gICAgICAgICAgICBHLmdhbWVNYW5hZ2VyLmNoYW5nZVR1cm4oKTtcblxuICAgICAgICAgICAgXG4gICAgICAgIH0pO1xuICAgICAgICBcbiAgICAgICAgRy5yb29tU29ja2V0Lm9uKCdkaXNjb24nLGZ1bmN0aW9uKCl7XG4gICAgICAgICAgICAvLy8vY29uc29sZS5sb2coXCJkYWZkYXNmYWRmYWRzZlwiKTtcbiAgICAgICAgICAgIEcud2ludHlwZSA9ICdkaXNjb24nO1xuICAgICAgICAgICAgY29uc29sZS5sb2coRy53aW50eXBlKTtcbiAgICAgICAgICAgIC8vLy9jb25zb2xlLmxvZyhcImRhc2ZcIik7XG4gICAgICAgICAgICBjYy5kaXJlY3Rvci5sb2FkU2NlbmUoJ3dpbicpO1xuICAgICAgICAgICAgXG4gICAgICAgIH0pO1xuICAgICAgICBcbiAgICAgICAgRy5yb29tU29ja2V0Lm9uKCd1cGJvYXJkJyxmdW5jdGlvbih1cGluZm8pe1xuICAgICAgICAgICAgXG4gICAgICAgICAgICB1cGluZm8gPSB1cGluZm87XG4gICAgICAgICAgICBHLmdhbWVNYW5hZ2VyLmdhbWV1cGJvYXJkKHVwaW5mbyk7XG4gICAgICAgIH0pO1xuICAgICAgICBcbiAgICAgXG4gICAgICAgIFxuICAgICAgICBHLnJvb21Tb2NrZXQub24oJ2RpcycsZnVuY3Rpb24oY2hlbm9kZSl7XG4gICAgICAgICAgICBcbiAgICAgICAgICAgIFxuICAgICAgICAgICAgRy5nYW1lTWFuYWdlci5jaGVkaXMoY2hlbm9kZSk7XG4gICAgICAgIH0pO1xuICAgICAgICBcbiAgICAgICAgdGhpcy5zY2hlZHVsZShmdW5jdGlvbigpe1xuICAgICAgICAgICAgdmFyIHVwaW5mbyA9WzAsMCwwLDAsMF07XG4gICAgICAgICAgICB2YXIgdHlwZU5vZGUgO1xuICAgICAgICAgICAgaWYoY2MuZmluZChcIkNhbnZhcy9jaGVzc2JvYXJkL2JpZ0NoZXNzX2JsdWVcIikpe1xuICAgICAgICAgICAgdHlwZU5vZGUgPSBjYy5maW5kKFwiQ2FudmFzL2NoZXNzYm9hcmQvYmlnQ2hlc3NfYmx1ZVwiKTtcbiAgICAgICAgICAgIFxuICAgICAgICAgICAgdXBpbmZvWzBdPXR5cGVOb2RlLmdldENvbXBvbmVudChcInRlc3RcIikuY2hlc3NOb2RlO1xuICAgICAgICAgICAgdXBpbmZvWzFdPXR5cGVOb2RlLng7XG4gICAgICAgICAgICB1cGluZm9bMl09dHlwZU5vZGUueTtcbiAgICAgICAgICAgIHVwaW5mb1szXT10eXBlTm9kZS5nZXRDb21wb25lbnQoXCJ0ZXN0XCIpLnNwZWVkLng7XG4gICAgICAgICAgICB1cGluZm9bNF09dHlwZU5vZGUuZ2V0Q29tcG9uZW50KFwidGVzdFwiKS5zcGVlZC55O1xuICAgICAgICAgICAgRy5yb29tU29ja2V0LmVtaXQoJ3VwYm9hcmQnLHVwaW5mbyk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZihjYy5maW5kKFwiQ2FudmFzL2NoZXNzYm9hcmQvYmlnQ2hlc3NfcmVkXCIpKXtcbiAgICAgICAgICAgIHR5cGVOb2RlID0gY2MuZmluZChcIkNhbnZhcy9jaGVzc2JvYXJkL2JpZ0NoZXNzX3JlZFwiKTtcbiAgICAgICAgICAgIFxuICAgICAgICAgICAgdXBpbmZvWzBdPXR5cGVOb2RlLmdldENvbXBvbmVudChcInRlc3RcIikuY2hlc3NOb2RlO1xuICAgICAgICAgICAgdXBpbmZvWzFdPXR5cGVOb2RlLng7XG4gICAgICAgICAgICB1cGluZm9bMl09dHlwZU5vZGUueTtcbiAgICAgICAgICAgIHVwaW5mb1szXT10eXBlTm9kZS5nZXRDb21wb25lbnQoXCJ0ZXN0XCIpLnNwZWVkLng7XG4gICAgICAgICAgICB1cGluZm9bNF09dHlwZU5vZGUuZ2V0Q29tcG9uZW50KFwidGVzdFwiKS5zcGVlZC55O1xuICAgICAgICAgICAgRy5yb29tU29ja2V0LmVtaXQoJ3VwYm9hcmQnLHVwaW5mbyk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZihjYy5maW5kKFwiQ2FudmFzL2NoZXNzYm9hcmQvbWlkQ2hlc3NfcmVkXzFcIikpe1xuICAgICAgICAgICAgdHlwZU5vZGUgPSBjYy5maW5kKFwiQ2FudmFzL2NoZXNzYm9hcmQvbWlkQ2hlc3NfcmVkXzFcIik7XG4gICAgICAgICAgICBcbiAgICAgICAgICAgIHVwaW5mb1swXT10eXBlTm9kZS5nZXRDb21wb25lbnQoXCJ0ZXN0XCIpLmNoZXNzTm9kZTtcbiAgICAgICAgICAgIHVwaW5mb1sxXT10eXBlTm9kZS54O1xuICAgICAgICAgICAgdXBpbmZvWzJdPXR5cGVOb2RlLnk7XG4gICAgICAgICAgICB1cGluZm9bM109dHlwZU5vZGUuZ2V0Q29tcG9uZW50KFwidGVzdFwiKS5zcGVlZC54O1xuICAgICAgICAgICAgdXBpbmZvWzRdPXR5cGVOb2RlLmdldENvbXBvbmVudChcInRlc3RcIikuc3BlZWQueTtcbiAgICAgICAgICAgIEcucm9vbVNvY2tldC5lbWl0KCd1cGJvYXJkJyx1cGluZm8pO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYoY2MuZmluZChcIkNhbnZhcy9jaGVzc2JvYXJkL21pZENoZXNzX3JlZF8yXCIpKXtcbiAgICAgICAgICAgIHR5cGVOb2RlID0gY2MuZmluZChcIkNhbnZhcy9jaGVzc2JvYXJkL21pZENoZXNzX3JlZF8yXCIpO1xuICAgICAgICAgICAgXG4gICAgICAgICAgICB1cGluZm9bMF09dHlwZU5vZGUuZ2V0Q29tcG9uZW50KFwidGVzdFwiKS5jaGVzc05vZGU7XG4gICAgICAgICAgICB1cGluZm9bMV09dHlwZU5vZGUueDtcbiAgICAgICAgICAgIHVwaW5mb1syXT10eXBlTm9kZS55O1xuICAgICAgICAgICAgdXBpbmZvWzNdPXR5cGVOb2RlLmdldENvbXBvbmVudChcInRlc3RcIikuc3BlZWQueDtcbiAgICAgICAgICAgIHVwaW5mb1s0XT10eXBlTm9kZS5nZXRDb21wb25lbnQoXCJ0ZXN0XCIpLnNwZWVkLnk7XG4gICAgICAgICAgICBHLnJvb21Tb2NrZXQuZW1pdCgndXBib2FyZCcsdXBpbmZvKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmKGNjLmZpbmQoXCJDYW52YXMvY2hlc3Nib2FyZC9taWRDaGVzc19yZWRfM1wiKSl7XG4gICAgICAgICAgICB0eXBlTm9kZSA9IGNjLmZpbmQoXCJDYW52YXMvY2hlc3Nib2FyZC9taWRDaGVzc19yZWRfM1wiKTtcbiAgICAgICAgICAgIFxuICAgICAgICAgICAgdXBpbmZvWzBdPXR5cGVOb2RlLmdldENvbXBvbmVudChcInRlc3RcIikuY2hlc3NOb2RlO1xuICAgICAgICAgICAgdXBpbmZvWzFdPXR5cGVOb2RlLng7XG4gICAgICAgICAgICB1cGluZm9bMl09dHlwZU5vZGUueTtcbiAgICAgICAgICAgIHVwaW5mb1szXT10eXBlTm9kZS5nZXRDb21wb25lbnQoXCJ0ZXN0XCIpLnNwZWVkLng7XG4gICAgICAgICAgICB1cGluZm9bNF09dHlwZU5vZGUuZ2V0Q29tcG9uZW50KFwidGVzdFwiKS5zcGVlZC55O1xuICAgICAgICAgICAgRy5yb29tU29ja2V0LmVtaXQoJ3VwYm9hcmQnLHVwaW5mbyk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZihjYy5maW5kKFwiQ2FudmFzL2NoZXNzYm9hcmQvbWlkQ2hlc3NfcmVkXzRcIikpe1xuICAgICAgICAgICAgdHlwZU5vZGUgPSBjYy5maW5kKFwiQ2FudmFzL2NoZXNzYm9hcmQvbWlkQ2hlc3NfcmVkXzRcIik7XG4gICAgICAgICAgICBcbiAgICAgICAgICAgIHVwaW5mb1swXT10eXBlTm9kZS5nZXRDb21wb25lbnQoXCJ0ZXN0XCIpLmNoZXNzTm9kZTtcbiAgICAgICAgICAgIHVwaW5mb1sxXT10eXBlTm9kZS54O1xuICAgICAgICAgICAgdXBpbmZvWzJdPXR5cGVOb2RlLnk7XG4gICAgICAgICAgICB1cGluZm9bM109dHlwZU5vZGUuZ2V0Q29tcG9uZW50KFwidGVzdFwiKS5zcGVlZC54O1xuICAgICAgICAgICAgdXBpbmZvWzRdPXR5cGVOb2RlLmdldENvbXBvbmVudChcInRlc3RcIikuc3BlZWQueTtcbiAgICAgICAgICAgIEcucm9vbVNvY2tldC5lbWl0KCd1cGJvYXJkJyx1cGluZm8pO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYoY2MuZmluZChcIkNhbnZhcy9jaGVzc2JvYXJkL21pZENoZXNzX2JsdWVfMVwiKSl7XG4gICAgICAgICAgICB0eXBlTm9kZSA9IGNjLmZpbmQoXCJDYW52YXMvY2hlc3Nib2FyZC9taWRDaGVzc19ibHVlXzFcIik7XG4gICAgICAgICAgICBcbiAgICAgICAgICAgIHVwaW5mb1swXT10eXBlTm9kZS5nZXRDb21wb25lbnQoXCJ0ZXN0XCIpLmNoZXNzTm9kZTtcbiAgICAgICAgICAgIHVwaW5mb1sxXT10eXBlTm9kZS54O1xuICAgICAgICAgICAgdXBpbmZvWzJdPXR5cGVOb2RlLnk7XG4gICAgICAgICAgICB1cGluZm9bM109dHlwZU5vZGUuZ2V0Q29tcG9uZW50KFwidGVzdFwiKS5zcGVlZC54O1xuICAgICAgICAgICAgdXBpbmZvWzRdPXR5cGVOb2RlLmdldENvbXBvbmVudChcInRlc3RcIikuc3BlZWQueTtcbiAgICAgICAgICAgIEcucm9vbVNvY2tldC5lbWl0KCd1cGJvYXJkJyx1cGluZm8pO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYoY2MuZmluZChcIkNhbnZhcy9jaGVzc2JvYXJkL21pZENoZXNzX2JsdWVfMlwiKSl7XG4gICAgICAgICAgICB0eXBlTm9kZSA9IGNjLmZpbmQoXCJDYW52YXMvY2hlc3Nib2FyZC9taWRDaGVzc19ibHVlXzJcIik7XG4gICAgICAgICAgICBcbiAgICAgICAgICAgIHVwaW5mb1swXT10eXBlTm9kZS5nZXRDb21wb25lbnQoXCJ0ZXN0XCIpLmNoZXNzTm9kZTtcbiAgICAgICAgICAgIHVwaW5mb1sxXT10eXBlTm9kZS54O1xuICAgICAgICAgICAgdXBpbmZvWzJdPXR5cGVOb2RlLnk7XG4gICAgICAgICAgICB1cGluZm9bM109dHlwZU5vZGUuZ2V0Q29tcG9uZW50KFwidGVzdFwiKS5zcGVlZC54O1xuICAgICAgICAgICAgdXBpbmZvWzRdPXR5cGVOb2RlLmdldENvbXBvbmVudChcInRlc3RcIikuc3BlZWQueTtcbiAgICAgICAgICAgIEcucm9vbVNvY2tldC5lbWl0KCd1cGJvYXJkJyx1cGluZm8pO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYoY2MuZmluZChcIkNhbnZhcy9jaGVzc2JvYXJkL21pZENoZXNzX2JsdWVfM1wiKSl7XG4gICAgICAgICAgICB0eXBlTm9kZSA9IGNjLmZpbmQoXCJDYW52YXMvY2hlc3Nib2FyZC9taWRDaGVzc19ibHVlXzNcIik7XG4gICAgICAgICAgICBcbiAgICAgICAgICAgIHVwaW5mb1swXT10eXBlTm9kZS5nZXRDb21wb25lbnQoXCJ0ZXN0XCIpLmNoZXNzTm9kZTtcbiAgICAgICAgICAgIHVwaW5mb1sxXT10eXBlTm9kZS54O1xuICAgICAgICAgICAgdXBpbmZvWzJdPXR5cGVOb2RlLnk7XG4gICAgICAgICAgICB1cGluZm9bM109dHlwZU5vZGUuZ2V0Q29tcG9uZW50KFwidGVzdFwiKS5zcGVlZC54O1xuICAgICAgICAgICAgdXBpbmZvWzRdPXR5cGVOb2RlLmdldENvbXBvbmVudChcInRlc3RcIikuc3BlZWQueTtcbiAgICAgICAgICAgIEcucm9vbVNvY2tldC5lbWl0KCd1cGJvYXJkJyx1cGluZm8pO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYoY2MuZmluZChcIkNhbnZhcy9jaGVzc2JvYXJkL21pZENoZXNzX2JsdWVfNFwiKSl7XG4gICAgICAgICAgICB0eXBlTm9kZSA9IGNjLmZpbmQoXCJDYW52YXMvY2hlc3Nib2FyZC9taWRDaGVzc19ibHVlXzRcIik7XG4gICAgICAgICAgICBcbiAgICAgICAgICAgIHVwaW5mb1swXT10eXBlTm9kZS5nZXRDb21wb25lbnQoXCJ0ZXN0XCIpLmNoZXNzTm9kZTtcbiAgICAgICAgICAgIHVwaW5mb1sxXT10eXBlTm9kZS54O1xuICAgICAgICAgICAgdXBpbmZvWzJdPXR5cGVOb2RlLnk7XG4gICAgICAgICAgICB1cGluZm9bM109dHlwZU5vZGUuZ2V0Q29tcG9uZW50KFwidGVzdFwiKS5zcGVlZC54O1xuICAgICAgICAgICAgdXBpbmZvWzRdPXR5cGVOb2RlLmdldENvbXBvbmVudChcInRlc3RcIikuc3BlZWQueTtcbiAgICAgICAgICAgIEcucm9vbVNvY2tldC5lbWl0KCd1cGJvYXJkJyx1cGluZm8pO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYoY2MuZmluZChcIkNhbnZhcy9jaGVzc2JvYXJkL3NtYWxsQ2hlc3NfcmVkXzFcIikpe1xuICAgICAgICAgICAgdHlwZU5vZGUgPSBjYy5maW5kKFwiQ2FudmFzL2NoZXNzYm9hcmQvc21hbGxDaGVzc19yZWRfMVwiKTtcbiAgICAgICAgICAgIFxuICAgICAgICAgICAgdXBpbmZvWzBdPXR5cGVOb2RlLmdldENvbXBvbmVudChcInRlc3RcIikuY2hlc3NOb2RlO1xuICAgICAgICAgICAgdXBpbmZvWzFdPXR5cGVOb2RlLng7XG4gICAgICAgICAgICB1cGluZm9bMl09dHlwZU5vZGUueTtcbiAgICAgICAgICAgIHVwaW5mb1szXT10eXBlTm9kZS5nZXRDb21wb25lbnQoXCJ0ZXN0XCIpLnNwZWVkLng7XG4gICAgICAgICAgICB1cGluZm9bNF09dHlwZU5vZGUuZ2V0Q29tcG9uZW50KFwidGVzdFwiKS5zcGVlZC55O1xuICAgICAgICAgICAgRy5yb29tU29ja2V0LmVtaXQoJ3VwYm9hcmQnLHVwaW5mbyk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZihjYy5maW5kKFwiQ2FudmFzL2NoZXNzYm9hcmQvc21hbGxDaGVzc19yZWRfMlwiKSl7XG4gICAgICAgICAgICB0eXBlTm9kZSA9IGNjLmZpbmQoXCJDYW52YXMvY2hlc3Nib2FyZC9zbWFsbENoZXNzX3JlZF8yXCIpO1xuICAgICAgICAgICAgXG4gICAgICAgICAgICB1cGluZm9bMF09dHlwZU5vZGUuZ2V0Q29tcG9uZW50KFwidGVzdFwiKS5jaGVzc05vZGU7XG4gICAgICAgICAgICB1cGluZm9bMV09dHlwZU5vZGUueDtcbiAgICAgICAgICAgIHVwaW5mb1syXT10eXBlTm9kZS55O1xuICAgICAgICAgICAgdXBpbmZvWzNdPXR5cGVOb2RlLmdldENvbXBvbmVudChcInRlc3RcIikuc3BlZWQueDtcbiAgICAgICAgICAgIHVwaW5mb1s0XT10eXBlTm9kZS5nZXRDb21wb25lbnQoXCJ0ZXN0XCIpLnNwZWVkLnk7XG4gICAgICAgICAgICBHLnJvb21Tb2NrZXQuZW1pdCgndXBib2FyZCcsdXBpbmZvKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmKGNjLmZpbmQoXCJDYW52YXMvY2hlc3Nib2FyZC9zbWFsbENoZXNzX3JlZF8zXCIpKXtcbiAgICAgICAgICAgIHR5cGVOb2RlID0gY2MuZmluZChcIkNhbnZhcy9jaGVzc2JvYXJkL3NtYWxsQ2hlc3NfcmVkXzNcIik7XG4gICAgICAgICAgICBcbiAgICAgICAgICAgIHVwaW5mb1swXT10eXBlTm9kZS5nZXRDb21wb25lbnQoXCJ0ZXN0XCIpLmNoZXNzTm9kZTtcbiAgICAgICAgICAgIHVwaW5mb1sxXT10eXBlTm9kZS54O1xuICAgICAgICAgICAgdXBpbmZvWzJdPXR5cGVOb2RlLnk7XG4gICAgICAgICAgICB1cGluZm9bM109dHlwZU5vZGUuZ2V0Q29tcG9uZW50KFwidGVzdFwiKS5zcGVlZC54O1xuICAgICAgICAgICAgdXBpbmZvWzRdPXR5cGVOb2RlLmdldENvbXBvbmVudChcInRlc3RcIikuc3BlZWQueTtcbiAgICAgICAgICAgIEcucm9vbVNvY2tldC5lbWl0KCd1cGJvYXJkJyx1cGluZm8pO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYoY2MuZmluZChcIkNhbnZhcy9jaGVzc2JvYXJkL3NtYWxsQ2hlc3NfYmx1ZV8xXCIpKXtcbiAgICAgICAgICAgIHR5cGVOb2RlID0gY2MuZmluZChcIkNhbnZhcy9jaGVzc2JvYXJkL3NtYWxsQ2hlc3NfYmx1ZV8xXCIpO1xuICAgICAgICAgICAgXG4gICAgICAgICAgICB1cGluZm9bMF09dHlwZU5vZGUuZ2V0Q29tcG9uZW50KFwidGVzdFwiKS5jaGVzc05vZGU7XG4gICAgICAgICAgICB1cGluZm9bMV09dHlwZU5vZGUueDtcbiAgICAgICAgICAgIHVwaW5mb1syXT10eXBlTm9kZS55O1xuICAgICAgICAgICAgdXBpbmZvWzNdPXR5cGVOb2RlLmdldENvbXBvbmVudChcInRlc3RcIikuc3BlZWQueDtcbiAgICAgICAgICAgIHVwaW5mb1s0XT10eXBlTm9kZS5nZXRDb21wb25lbnQoXCJ0ZXN0XCIpLnNwZWVkLnk7XG4gICAgICAgICAgICBHLnJvb21Tb2NrZXQuZW1pdCgndXBib2FyZCcsdXBpbmZvKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmKGNjLmZpbmQoXCJDYW52YXMvY2hlc3Nib2FyZC9zbWFsbENoZXNzX2JsdWVfMlwiKSl7XG4gICAgICAgICAgICB0eXBlTm9kZSA9IGNjLmZpbmQoXCJDYW52YXMvY2hlc3Nib2FyZC9zbWFsbENoZXNzX2JsdWVfMlwiKTtcbiAgICAgICAgICAgIFxuICAgICAgICAgICAgdXBpbmZvWzBdPXR5cGVOb2RlLmdldENvbXBvbmVudChcInRlc3RcIikuY2hlc3NOb2RlO1xuICAgICAgICAgICAgdXBpbmZvWzFdPXR5cGVOb2RlLng7XG4gICAgICAgICAgICB1cGluZm9bMl09dHlwZU5vZGUueTtcbiAgICAgICAgICAgIHVwaW5mb1szXT10eXBlTm9kZS5nZXRDb21wb25lbnQoXCJ0ZXN0XCIpLnNwZWVkLng7XG4gICAgICAgICAgICB1cGluZm9bNF09dHlwZU5vZGUuZ2V0Q29tcG9uZW50KFwidGVzdFwiKS5zcGVlZC55O1xuICAgICAgICAgICAgRy5yb29tU29ja2V0LmVtaXQoJ3VwYm9hcmQnLHVwaW5mbyk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZihjYy5maW5kKFwiQ2FudmFzL2NoZXNzYm9hcmQvc21hbGxDaGVzc19ibHVlXzNcIikpe1xuICAgICAgICAgICAgdHlwZU5vZGUgPSBjYy5maW5kKFwiQ2FudmFzL2NoZXNzYm9hcmQvc21hbGxDaGVzc19ibHVlXzNcIik7XG4gICAgICAgICAgICBcbiAgICAgICAgICAgIHVwaW5mb1swXT10eXBlTm9kZS5nZXRDb21wb25lbnQoXCJ0ZXN0XCIpLmNoZXNzTm9kZTtcbiAgICAgICAgICAgIHVwaW5mb1sxXT10eXBlTm9kZS54O1xuICAgICAgICAgICAgdXBpbmZvWzJdPXR5cGVOb2RlLnk7XG4gICAgICAgICAgICB1cGluZm9bM109dHlwZU5vZGUuZ2V0Q29tcG9uZW50KFwidGVzdFwiKS5zcGVlZC54O1xuICAgICAgICAgICAgdXBpbmZvWzRdPXR5cGVOb2RlLmdldENvbXBvbmVudChcInRlc3RcIikuc3BlZWQueTtcbiAgICAgICAgICAgIEcucm9vbVNvY2tldC5lbWl0KCd1cGJvYXJkJyx1cGluZm8pO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgXG4gICAgICAgIH0sMik7XG4gICAgICAgIFxuICAgIH0sXG4gICAgXG4gICAgY2hlZGlzOiBmdW5jdGlvbihjaGVub2RlKXtcbiAgICAgICAgXG4gICAgICAgIFxuICAgICAgICBcbiAgICAgICAgdmFyIHR5cGVOb2RlIDtcbiAgICAgICAgXG4gICAgICAgIGlmKGNoZW5vZGU9PTIpe1xuICAgICAgICAgICAgXG4gICAgICAgICAgICB0eXBlTm9kZSA9IGNjLmZpbmQoXCJDYW52YXMvY2hlc3Nib2FyZC9iaWdDaGVzc19ibHVlXCIpO1xuICAgICAgICAgICAgLy9jb25zb2xlLmxvZyhcInpoYW9kYW9cIik7XG4gICAgICAgICAgICB0eXBlTm9kZS5kZXN0cm95KCk7XG4gICAgICAgICAgICAvL2NvbnNvbGUubG9nKFwieGlhb2NodVwiKTtcbiAgICAgICAgICAgIFxuICAgICAgICB9XG4gICAgICAgIFxuICAgICAgICBpZihjaGVub2RlPT0xKXtcbiAgICAgICAgICAgIFxuICAgICAgICAgICAgLy9jb25zb2xlLmxvZyhcInpoYW9kYW9cIik7dHlwZU5vZGUgPSBjYy5maW5kKFwiQ2FudmFzL2NoZXNzYm9hcmQvYmlnQ2hlc3NfcmVkXCIpO1xuICAgICAgICAgICAgdHlwZU5vZGUuZGVzdHJveSgpO1xuICAgICAgICAgICAgLy9jb25zb2xlLmxvZyhcInhpYW9jaHVcIik7XG4gICAgICAgIH1cbiAgICAgICAgXG4gICAgICAgIGlmKGNoZW5vZGU9PTMpe1xuICAgICAgICAgICAgXG4gICAgICAgICAgICB0eXBlTm9kZSA9IGNjLmZpbmQoXCJDYW52YXMvY2hlc3Nib2FyZC9taWRDaGVzc19yZWRfMVwiKTtcbiAgICAgICAgICAgIC8vY29uc29sZS5sb2coXCJ6aGFvZGFvXCIpO1xuICAgICAgICAgICAgdHlwZU5vZGUuZGVzdHJveSgpO1xuICAgICAgICAgICAgLy9jb25zb2xlLmxvZyhcInhpYW9jaHVcIik7XG4gICAgICAgIH1cbiAgICAgICAgaWYoY2hlbm9kZT09NCl7XG4gICAgICAgICAgICAvL2NvbnNvbGUubG9nKFwiemhhb2Rhb1wiKTt0eXBlTm9kZSA9IGNjLmZpbmQoXCJDYW52YXMvY2hlc3Nib2FyZC9taWRDaGVzc19yZWRfMlwiKTtcbiAgICAgICAgICAgIHR5cGVOb2RlLmRlc3Ryb3koKTtcbiAgICAgICAgICAgIC8vY29uc29sZS5sb2coXCJ4aWFvY2h1XCIpO1xuICAgICAgICB9XG4gICAgICAgIGlmKGNoZW5vZGU9PTUpe1xuICAgICAgICAgICAgLy9jb25zb2xlLmxvZyhcInpoYW9kYW9cIik7dHlwZU5vZGUgPSBjYy5maW5kKFwiQ2FudmFzL2NoZXNzYm9hcmQvbWlkQ2hlc3NfcmVkXzNcIik7XG4gICAgICAgICAgICB0eXBlTm9kZS5kZXN0cm95KCk7XG4gICAgICAgICAgICAvL2NvbnNvbGUubG9nKFwieGlhb2NodVwiKTtcbiAgICAgICAgfVxuICAgICAgICBpZihjaGVub2RlPT02KXtcbiAgICAgICAgICAgIC8vY29uc29sZS5sb2coXCJ6aGFvZGFvXCIpO3R5cGVOb2RlID0gY2MuZmluZChcIkNhbnZhcy9jaGVzc2JvYXJkL21pZENoZXNzX3JlZF80XCIpO1xuICAgICAgICAgICAgdHlwZU5vZGUuZGVzdHJveSgpO1xuICAgICAgICAgICAgLy9jb25zb2xlLmxvZyhcInhpYW9jaHVcIik7XG4gICAgICAgIH1cbiAgICAgICAgXG4gICAgICAgIGlmKGNoZW5vZGU9PTcpe1xuICAgICAgICAgICAgLy9jb25zb2xlLmxvZyhcInpoYW9kYW9cIik7dHlwZU5vZGUgPSBjYy5maW5kKFwiQ2FudmFzL2NoZXNzYm9hcmQvbWlkQ2hlc3NfYmx1ZV8xXCIpO1xuICAgICAgICAgICAgdHlwZU5vZGUuZGVzdHJveSgpO1xuICAgICAgICAgICAgLy9jb25zb2xlLmxvZyhcInhpYW9jaHVcIik7XG4gICAgICAgIH1cbiAgICAgICAgaWYoY2hlbm9kZT09OCl7XG4gICAgICAgICAgICAvL2NvbnNvbGUubG9nKFwiemhhb2Rhb1wiKTt0eXBlTm9kZSA9IGNjLmZpbmQoXCJDYW52YXMvY2hlc3Nib2FyZC9taWRDaGVzc19ibHVlXzJcIik7XG4gICAgICAgICAgICB0eXBlTm9kZS5kZXN0cm95KCk7XG4gICAgICAgICAgICAvL2NvbnNvbGUubG9nKFwieGlhb2NodVwiKTtcbiAgICAgICAgfVxuICAgICAgICBpZihjaGVub2RlPT05KXtcbiAgICAgICAgICAgIC8vY29uc29sZS5sb2coXCJ6aGFvZGFvXCIpO3R5cGVOb2RlID0gY2MuZmluZChcIkNhbnZhcy9jaGVzc2JvYXJkL21pZENoZXNzX2JsdWVfM1wiKTtcbiAgICAgICAgICAgIHR5cGVOb2RlLmRlc3Ryb3koKTtcbiAgICAgICAgICAgIC8vY29uc29sZS5sb2coXCJ4aWFvY2h1XCIpO1xuICAgICAgICB9XG4gICAgICAgIGlmKGNoZW5vZGU9PTEwKXtcbiAgICAgICAgICAgIC8vY29uc29sZS5sb2coXCJ6aGFvZGFvXCIpO3R5cGVOb2RlID0gY2MuZmluZChcIkNhbnZhcy9jaGVzc2JvYXJkL21pZENoZXNzX2JsdWVfNFwiKTtcbiAgICAgICAgICAgIHR5cGVOb2RlLmRlc3Ryb3koKTtcbiAgICAgICAgICAgIC8vY29uc29sZS5sb2coXCJ4aWFvY2h1XCIpO1xuICAgICAgICB9XG4gICAgICAgIFxuICAgICAgICBpZihjaGVub2RlPT0xMSl7XG4gICAgICAgICAgICAvL2NvbnNvbGUubG9nKFwiemhhb2Rhb1wiKTt0eXBlTm9kZSA9IGNjLmZpbmQoXCJDYW52YXMvY2hlc3Nib2FyZC9zbWFsbENoZXNzX3JlZF8xXCIpO1xuICAgICAgICAgICAgdHlwZU5vZGUuZGVzdHJveSgpO1xuICAgICAgICAgICAgLy9jb25zb2xlLmxvZyhcInhpYW9jaHVcIik7XG4gICAgICAgIH1cbiAgICAgICAgaWYoY2hlbm9kZT09MTIpe1xuICAgICAgICAgICAgLy9jb25zb2xlLmxvZyhcInpoYW9kYW9cIik7dHlwZU5vZGUgPSBjYy5maW5kKFwiQ2FudmFzL2NoZXNzYm9hcmQvc21hbGxDaGVzc19yZWRfMlwiKTtcbiAgICAgICAgICAgIHR5cGVOb2RlLmRlc3Ryb3koKTtcbiAgICAgICAgICAgIC8vY29uc29sZS5sb2coXCJ4aWFvY2h1XCIpO1xuICAgICAgICB9XG4gICAgICAgIGlmKGNoZW5vZGU9PTEzKXtcbiAgICAgICAgICAgIC8vY29uc29sZS5sb2coXCJ6aGFvZGFvXCIpO3R5cGVOb2RlID0gY2MuZmluZChcIkNhbnZhcy9jaGVzc2JvYXJkL3NtYWxsQ2hlc3NfcmVkXzNcIik7XG4gICAgICAgICAgICB0eXBlTm9kZS5kZXN0cm95KCk7XG4gICAgICAgICAgICAvL2NvbnNvbGUubG9nKFwieGlhb2NodVwiKTtcbiAgICAgICAgfVxuICAgICAgICBcbiAgICAgICAgaWYoY2hlbm9kZT09MTQpe1xuICAgICAgICAgICAgLy9jb25zb2xlLmxvZyhcInpoYW9kYW9cIik7dHlwZU5vZGUgPSBjYy5maW5kKFwiQ2FudmFzL2NoZXNzYm9hcmQvc21hbGxDaGVzc19ibHVlXzFcIik7XG4gICAgICAgICAgICB0eXBlTm9kZS5kZXN0cm95KCk7XG4gICAgICAgICAgICAvL2NvbnNvbGUubG9nKFwieGlhb2NodVwiKTtcbiAgICAgICAgfVxuICAgICAgICBpZihjaGVub2RlPT0xNSl7XG4gICAgICAgICAgICAvL2NvbnNvbGUubG9nKFwiemhhb2Rhb1wiKTt0eXBlTm9kZSA9IGNjLmZpbmQoXCJDYW52YXMvY2hlc3Nib2FyZC9zbWFsbENoZXNzX2JsdWVfMlwiKTtcbiAgICAgICAgICAgIHR5cGVOb2RlLmRlc3Ryb3koKTtcbiAgICAgICAgICAgIC8vY29uc29sZS5sb2coXCJ4aWFvY2h1XCIpO1xuICAgICAgICB9XG4gICAgICAgIGlmKGNoZW5vZGU9PTE2KXtcbiAgICAgICAgICAgIC8vY29uc29sZS5sb2coXCJ6aGFvZGFvXCIpO3R5cGVOb2RlID0gY2MuZmluZChcIkNhbnZhcy9jaGVzc2JvYXJkL3NtYWxsQ2hlc3NfYmx1ZV8zXCIpO1xuICAgICAgICAgICAgdHlwZU5vZGUuZGVzdHJveSgpO1xuICAgICAgICAgICAgLy9jb25zb2xlLmxvZyhcInhpYW9jaHVcIik7XG4gICAgICAgIH1cbiAgICAgICAgXG4gICAgXG4gICAgXG4gICAgfSxcbiAgICBcbiAgICBnYW1ldXBib2FyZDogZnVuY3Rpb24odXBpbmZvKXtcbiAgICAgICAgXG4gICAgICAgIFxuICAgICAgICB2YXIgdHlwZU5vZGUgO1xuICAgICAgICBcbiAgICAgICAgaWYodXBpbmZvWzBdPT0yKXtcbiAgICAgICAgICAgIFxuICAgICAgICAgICAgdHlwZU5vZGUgPSBjYy5maW5kKFwiQ2FudmFzL2NoZXNzYm9hcmQvYmlnQ2hlc3NfYmx1ZVwiKTtcbiAgICAgICAgICAgXG4gICAgICAgICAgICB0eXBlTm9kZS54ID0gdXBpbmZvWzFdO1xuICAgICAgICAgICAgdHlwZU5vZGUueSA9IHVwaW5mb1syXTtcbiAgICAgICAgICAgIHR5cGVOb2RlLmdldENvbXBvbmVudChcInRlc3RcIikuc3BlZWQueCA9IHVwaW5mb1szXTtcbiAgICAgICAgICAgIHR5cGVOb2RlLmdldENvbXBvbmVudChcInRlc3RcIikuc3BlZWQueSA9IHVwaW5mb1s0XTtcbiAgICAgICAgICAgIFxuICAgICAgICB9XG4gICAgICAgIFxuICAgICAgICBpZih1cGluZm9bMF09PTEpe1xuICAgICAgICAgICAgXG4gICAgICAgICAgICB0eXBlTm9kZSA9IGNjLmZpbmQoXCJDYW52YXMvY2hlc3Nib2FyZC9iaWdDaGVzc19yZWRcIik7XG4gICAgICAgICAgICB0eXBlTm9kZS54ID0gdXBpbmZvWzFdO1xuICAgICAgICAgICAgdHlwZU5vZGUueSA9IHVwaW5mb1syXTtcbiAgICAgICAgICAgIHR5cGVOb2RlLmdldENvbXBvbmVudChcInRlc3RcIikuc3BlZWQueCA9IHVwaW5mb1szXTtcbiAgICAgICAgICAgIHR5cGVOb2RlLmdldENvbXBvbmVudChcInRlc3RcIikuc3BlZWQueSA9IHVwaW5mb1s0XTtcbiAgICAgICAgfVxuICAgICAgICBcbiAgICAgICAgaWYodXBpbmZvWzBdPT0zKXtcbiAgICAgICAgICAgIFxuICAgICAgICAgICAgdHlwZU5vZGUgPSBjYy5maW5kKFwiQ2FudmFzL2NoZXNzYm9hcmQvbWlkQ2hlc3NfcmVkXzFcIik7XG4gICAgICAgICAgICBcbiAgICAgICAgICAgIHR5cGVOb2RlLnggPSB1cGluZm9bMV07XG4gICAgICAgICAgICB0eXBlTm9kZS55ID0gdXBpbmZvWzJdO1xuICAgICAgICAgICAgdHlwZU5vZGUuZ2V0Q29tcG9uZW50KFwidGVzdFwiKS5zcGVlZC54ID0gdXBpbmZvWzNdO1xuICAgICAgICAgICAgdHlwZU5vZGUuZ2V0Q29tcG9uZW50KFwidGVzdFwiKS5zcGVlZC55ID0gdXBpbmZvWzRdO1xuICAgICAgICB9XG4gICAgICAgIGlmKHVwaW5mb1swXT09NCl7XG4gICAgICAgICAgICB0eXBlTm9kZSA9IGNjLmZpbmQoXCJDYW52YXMvY2hlc3Nib2FyZC9taWRDaGVzc19yZWRfMlwiKTtcbiAgICAgICAgICAgIHR5cGVOb2RlLnggPSB1cGluZm9bMV07XG4gICAgICAgICAgICB0eXBlTm9kZS55ID0gdXBpbmZvWzJdO1xuICAgICAgICAgICAgdHlwZU5vZGUuZ2V0Q29tcG9uZW50KFwidGVzdFwiKS5zcGVlZC54ID0gdXBpbmZvWzNdO1xuICAgICAgICAgICAgdHlwZU5vZGUuZ2V0Q29tcG9uZW50KFwidGVzdFwiKS5zcGVlZC55ID0gdXBpbmZvWzRdO1xuICAgICAgICB9XG4gICAgICAgIGlmKHVwaW5mb1swXT09NSl7XG4gICAgICAgICAgICB0eXBlTm9kZSA9IGNjLmZpbmQoXCJDYW52YXMvY2hlc3Nib2FyZC9taWRDaGVzc19yZWRfM1wiKTtcbiAgICAgICAgICAgIHR5cGVOb2RlLnggPSB1cGluZm9bMV07XG4gICAgICAgICAgICB0eXBlTm9kZS55ID0gdXBpbmZvWzJdO1xuICAgICAgICAgICAgdHlwZU5vZGUuZ2V0Q29tcG9uZW50KFwidGVzdFwiKS5zcGVlZC54ID0gdXBpbmZvWzNdO1xuICAgICAgICAgICAgdHlwZU5vZGUuZ2V0Q29tcG9uZW50KFwidGVzdFwiKS5zcGVlZC55ID0gdXBpbmZvWzRdO1xuICAgICAgICB9XG4gICAgICAgIGlmKHVwaW5mb1swXT09Nil7XG4gICAgICAgICAgICB0eXBlTm9kZSA9IGNjLmZpbmQoXCJDYW52YXMvY2hlc3Nib2FyZC9taWRDaGVzc19yZWRfNFwiKTtcbiAgICAgICAgICAgIHR5cGVOb2RlLnggPSB1cGluZm9bMV07XG4gICAgICAgICAgICB0eXBlTm9kZS55ID0gdXBpbmZvWzJdO1xuICAgICAgICAgICAgdHlwZU5vZGUuZ2V0Q29tcG9uZW50KFwidGVzdFwiKS5zcGVlZC54ID0gdXBpbmZvWzNdO1xuICAgICAgICAgICAgdHlwZU5vZGUuZ2V0Q29tcG9uZW50KFwidGVzdFwiKS5zcGVlZC55ID0gdXBpbmZvWzRdO1xuICAgICAgICB9XG4gICAgICAgIFxuICAgICAgICBpZih1cGluZm9bMF09PTcpe1xuICAgICAgICAgICAgdHlwZU5vZGUgPSBjYy5maW5kKFwiQ2FudmFzL2NoZXNzYm9hcmQvbWlkQ2hlc3NfYmx1ZV8xXCIpO1xuICAgICAgICAgICAgdHlwZU5vZGUueCA9IHVwaW5mb1sxXTtcbiAgICAgICAgICAgIHR5cGVOb2RlLnkgPSB1cGluZm9bMl07XG4gICAgICAgICAgICB0eXBlTm9kZS5nZXRDb21wb25lbnQoXCJ0ZXN0XCIpLnNwZWVkLnggPSB1cGluZm9bM107XG4gICAgICAgICAgICB0eXBlTm9kZS5nZXRDb21wb25lbnQoXCJ0ZXN0XCIpLnNwZWVkLnkgPSB1cGluZm9bNF07XG4gICAgICAgIH1cbiAgICAgICAgaWYodXBpbmZvWzBdPT04KXtcbiAgICAgICAgICAgIHR5cGVOb2RlID0gY2MuZmluZChcIkNhbnZhcy9jaGVzc2JvYXJkL21pZENoZXNzX2JsdWVfMlwiKTtcbiAgICAgICAgICAgIHR5cGVOb2RlLnggPSB1cGluZm9bMV07XG4gICAgICAgICAgICB0eXBlTm9kZS55ID0gdXBpbmZvWzJdO1xuICAgICAgICAgICAgdHlwZU5vZGUuZ2V0Q29tcG9uZW50KFwidGVzdFwiKS5zcGVlZC54ID0gdXBpbmZvWzNdO1xuICAgICAgICAgICAgdHlwZU5vZGUuZ2V0Q29tcG9uZW50KFwidGVzdFwiKS5zcGVlZC55ID0gdXBpbmZvWzRdO1xuICAgICAgICB9XG4gICAgICAgIGlmKHVwaW5mb1swXT09OSl7XG4gICAgICAgICAgICB0eXBlTm9kZSA9IGNjLmZpbmQoXCJDYW52YXMvY2hlc3Nib2FyZC9taWRDaGVzc19ibHVlXzNcIik7XG4gICAgICAgICAgICB0eXBlTm9kZS54ID0gdXBpbmZvWzFdO1xuICAgICAgICAgICAgdHlwZU5vZGUueSA9IHVwaW5mb1syXTtcbiAgICAgICAgICAgIHR5cGVOb2RlLmdldENvbXBvbmVudChcInRlc3RcIikuc3BlZWQueCA9IHVwaW5mb1szXTtcbiAgICAgICAgICAgIHR5cGVOb2RlLmdldENvbXBvbmVudChcInRlc3RcIikuc3BlZWQueSA9IHVwaW5mb1s0XTtcbiAgICAgICAgfVxuICAgICAgICBpZih1cGluZm9bMF09PTEwKXtcbiAgICAgICAgICAgIHR5cGVOb2RlID0gY2MuZmluZChcIkNhbnZhcy9jaGVzc2JvYXJkL21pZENoZXNzX2JsdWVfNFwiKTtcbiAgICAgICAgICAgIHR5cGVOb2RlLnggPSB1cGluZm9bMV07XG4gICAgICAgICAgICB0eXBlTm9kZS55ID0gdXBpbmZvWzJdO1xuICAgICAgICAgICAgdHlwZU5vZGUuZ2V0Q29tcG9uZW50KFwidGVzdFwiKS5zcGVlZC54ID0gdXBpbmZvWzNdO1xuICAgICAgICAgICAgdHlwZU5vZGUuZ2V0Q29tcG9uZW50KFwidGVzdFwiKS5zcGVlZC55ID0gdXBpbmZvWzRdO1xuICAgICAgICB9XG4gICAgICAgIFxuICAgICAgICBpZih1cGluZm9bMF09PTExKXtcbiAgICAgICAgICAgIHR5cGVOb2RlID0gY2MuZmluZChcIkNhbnZhcy9jaGVzc2JvYXJkL3NtYWxsQ2hlc3NfcmVkXzFcIik7XG4gICAgICAgICAgICB0eXBlTm9kZS54ID0gdXBpbmZvWzFdO1xuICAgICAgICAgICAgdHlwZU5vZGUueSA9IHVwaW5mb1syXTtcbiAgICAgICAgICAgIHR5cGVOb2RlLmdldENvbXBvbmVudChcInRlc3RcIikuc3BlZWQueCA9IHVwaW5mb1szXTtcbiAgICAgICAgICAgIHR5cGVOb2RlLmdldENvbXBvbmVudChcInRlc3RcIikuc3BlZWQueSA9IHVwaW5mb1s0XTtcbiAgICAgICAgfVxuICAgICAgICBpZih1cGluZm9bMF09PTEyKXtcbiAgICAgICAgICAgIHR5cGVOb2RlID0gY2MuZmluZChcIkNhbnZhcy9jaGVzc2JvYXJkL3NtYWxsQ2hlc3NfcmVkXzJcIik7XG4gICAgICAgICAgICB0eXBlTm9kZS54ID0gdXBpbmZvWzFdO1xuICAgICAgICAgICAgdHlwZU5vZGUueSA9IHVwaW5mb1syXTtcbiAgICAgICAgICAgIHR5cGVOb2RlLmdldENvbXBvbmVudChcInRlc3RcIikuc3BlZWQueCA9IHVwaW5mb1szXTtcbiAgICAgICAgICAgIHR5cGVOb2RlLmdldENvbXBvbmVudChcInRlc3RcIikuc3BlZWQueSA9IHVwaW5mb1s0XTtcbiAgICAgICAgfVxuICAgICAgICBpZih1cGluZm9bMF09PTEzKXtcbiAgICAgICAgICAgIHR5cGVOb2RlID0gY2MuZmluZChcIkNhbnZhcy9jaGVzc2JvYXJkL3NtYWxsQ2hlc3NfcmVkXzNcIik7XG4gICAgICAgICAgICB0eXBlTm9kZS54ID0gdXBpbmZvWzFdO1xuICAgICAgICAgICAgdHlwZU5vZGUueSA9IHVwaW5mb1syXTtcbiAgICAgICAgICAgIHR5cGVOb2RlLmdldENvbXBvbmVudChcInRlc3RcIikuc3BlZWQueCA9IHVwaW5mb1szXTtcbiAgICAgICAgICAgIHR5cGVOb2RlLmdldENvbXBvbmVudChcInRlc3RcIikuc3BlZWQueSA9IHVwaW5mb1s0XTtcbiAgICAgICAgfVxuICAgICAgICBcbiAgICAgICAgaWYodXBpbmZvWzBdPT0xNCl7XG4gICAgICAgICAgICB0eXBlTm9kZSA9IGNjLmZpbmQoXCJDYW52YXMvY2hlc3Nib2FyZC9zbWFsbENoZXNzX2JsdWVfMVwiKTtcbiAgICAgICAgICAgIHR5cGVOb2RlLnggPSB1cGluZm9bMV07XG4gICAgICAgICAgICB0eXBlTm9kZS55ID0gdXBpbmZvWzJdO1xuICAgICAgICAgICAgdHlwZU5vZGUuZ2V0Q29tcG9uZW50KFwidGVzdFwiKS5zcGVlZC54ID0gdXBpbmZvWzNdO1xuICAgICAgICAgICAgdHlwZU5vZGUuZ2V0Q29tcG9uZW50KFwidGVzdFwiKS5zcGVlZC55ID0gdXBpbmZvWzRdO1xuICAgICAgICB9XG4gICAgICAgIGlmKHVwaW5mb1swXT09MTUpe1xuICAgICAgICAgICAgdHlwZU5vZGUgPSBjYy5maW5kKFwiQ2FudmFzL2NoZXNzYm9hcmQvc21hbGxDaGVzc19ibHVlXzJcIik7XG4gICAgICAgICAgICB0eXBlTm9kZS54ID0gdXBpbmZvWzFdO1xuICAgICAgICAgICAgdHlwZU5vZGUueSA9IHVwaW5mb1syXTtcbiAgICAgICAgICAgIHR5cGVOb2RlLmdldENvbXBvbmVudChcInRlc3RcIikuc3BlZWQueCA9IHVwaW5mb1szXTtcbiAgICAgICAgICAgIHR5cGVOb2RlLmdldENvbXBvbmVudChcInRlc3RcIikuc3BlZWQueSA9IHVwaW5mb1s0XTtcbiAgICAgICAgfVxuICAgICAgICBpZih1cGluZm9bMF09PTE2KXtcbiAgICAgICAgICAgIHR5cGVOb2RlID0gY2MuZmluZChcIkNhbnZhcy9jaGVzc2JvYXJkL3NtYWxsQ2hlc3NfYmx1ZV8zXCIpO1xuICAgICAgICAgICAgdHlwZU5vZGUueCA9IHVwaW5mb1sxXTtcbiAgICAgICAgICAgIHR5cGVOb2RlLnkgPSB1cGluZm9bMl07XG4gICAgICAgICAgICB0eXBlTm9kZS5nZXRDb21wb25lbnQoXCJ0ZXN0XCIpLnNwZWVkLnggPSB1cGluZm9bM107XG4gICAgICAgICAgICB0eXBlTm9kZS5nZXRDb21wb25lbnQoXCJ0ZXN0XCIpLnNwZWVkLnkgPSB1cGluZm9bNF07XG4gICAgICAgIH1cbiAgICAgICAgXG4gICAgXG4gICAgfSxcbiAgICBcbiAgICBnYW1ldXBpbmZvOiBmdW5jdGlvbih1cGluZm8pe1xuICAgICAgICBcbiAgICAgICAgdmFyIHR5cGVOb2RlIDtcbiAgICAgICAgdmFyIG51bTtcbiAgICAgICAgaWYodXBpbmZvWzBdPT0yKXtcbiAgICAgICAgICAgIFxuICAgICAgICAgICAgdHlwZU5vZGUgPSBjYy5maW5kKFwiQ2FudmFzL2NoZXNzYm9hcmQvYmlnQ2hlc3NfYmx1ZVwiKTtcbiAgICAgICAgICAgIFxuICAgICAgICAgICAgdHlwZU5vZGUuZ2V0Q29tcG9uZW50KFwidGVzdFwiKS5zcGVlZC54ID0gdXBpbmZvWzFdO1xuICAgICAgICAgICAgdHlwZU5vZGUuZ2V0Q29tcG9uZW50KFwidGVzdFwiKS5zcGVlZC55ID0gdXBpbmZvWzJdO1xuICAgICAgICB9XG4gICAgICAgIFxuICAgICAgICBpZih1cGluZm9bMF09PTEpe1xuICAgICAgICAgICAgXG4gICAgICAgICAgICB0eXBlTm9kZSA9IGNjLmZpbmQoXCJDYW52YXMvY2hlc3Nib2FyZC9iaWdDaGVzc19yZWRcIik7XG4gICAgICAgICAgICB0eXBlTm9kZS5nZXRDb21wb25lbnQoXCJ0ZXN0XCIpLnNwZWVkLnggPSB1cGluZm9bMV07XG4gICAgICAgICAgICB0eXBlTm9kZS5nZXRDb21wb25lbnQoXCJ0ZXN0XCIpLnNwZWVkLnkgPSB1cGluZm9bMl07XG4gICAgICAgIH1cbiAgICAgICAgXG4gICAgICAgIGlmKHVwaW5mb1swXT09Myl7XG4gICAgICAgICAgICBcbiAgICAgICAgICAgIHR5cGVOb2RlID0gY2MuZmluZChcIkNhbnZhcy9jaGVzc2JvYXJkL21pZENoZXNzX3JlZF8xXCIpO1xuICAgICAgICAgICAgXG4gICAgICAgICAgICB0eXBlTm9kZS5nZXRDb21wb25lbnQoXCJ0ZXN0XCIpLnNwZWVkLnggPSB1cGluZm9bMV07XG4gICAgICAgICAgICB0eXBlTm9kZS5nZXRDb21wb25lbnQoXCJ0ZXN0XCIpLnNwZWVkLnkgPSB1cGluZm9bMl07XG4gICAgICAgIH1cbiAgICAgICAgaWYodXBpbmZvWzBdPT00KXtcbiAgICAgICAgICAgIHR5cGVOb2RlID0gY2MuZmluZChcIkNhbnZhcy9jaGVzc2JvYXJkL21pZENoZXNzX3JlZF8yXCIpO1xuICAgICAgICAgICAgdHlwZU5vZGUuZ2V0Q29tcG9uZW50KFwidGVzdFwiKS5zcGVlZC54ID0gdXBpbmZvWzFdO1xuICAgICAgICAgICAgdHlwZU5vZGUuZ2V0Q29tcG9uZW50KFwidGVzdFwiKS5zcGVlZC55ID0gdXBpbmZvWzJdO1xuICAgICAgICB9XG4gICAgICAgIGlmKHVwaW5mb1swXT09NSl7XG4gICAgICAgICAgICB0eXBlTm9kZSA9IGNjLmZpbmQoXCJDYW52YXMvY2hlc3Nib2FyZC9taWRDaGVzc19yZWRfM1wiKTtcbiAgICAgICAgICAgIHR5cGVOb2RlLmdldENvbXBvbmVudChcInRlc3RcIikuc3BlZWQueCA9IHVwaW5mb1sxXTtcbiAgICAgICAgICAgIHR5cGVOb2RlLmdldENvbXBvbmVudChcInRlc3RcIikuc3BlZWQueSA9IHVwaW5mb1syXTtcbiAgICAgICAgfVxuICAgICAgICBpZih1cGluZm9bMF09PTYpe1xuICAgICAgICAgICAgdHlwZU5vZGUgPSBjYy5maW5kKFwiQ2FudmFzL2NoZXNzYm9hcmQvbWlkQ2hlc3NfcmVkXzRcIik7XG4gICAgICAgICAgICB0eXBlTm9kZS5nZXRDb21wb25lbnQoXCJ0ZXN0XCIpLnNwZWVkLnggPSB1cGluZm9bMV07XG4gICAgICAgICAgICB0eXBlTm9kZS5nZXRDb21wb25lbnQoXCJ0ZXN0XCIpLnNwZWVkLnkgPSB1cGluZm9bMl07XG4gICAgICAgIH1cbiAgICAgICAgXG4gICAgICAgIGlmKHVwaW5mb1swXT09Nyl7XG4gICAgICAgICAgICB0eXBlTm9kZSA9IGNjLmZpbmQoXCJDYW52YXMvY2hlc3Nib2FyZC9taWRDaGVzc19ibHVlXzFcIik7XG4gICAgICAgICAgICB0eXBlTm9kZS5nZXRDb21wb25lbnQoXCJ0ZXN0XCIpLnNwZWVkLnggPSB1cGluZm9bMV07XG4gICAgICAgICAgICB0eXBlTm9kZS5nZXRDb21wb25lbnQoXCJ0ZXN0XCIpLnNwZWVkLnkgPSB1cGluZm9bMl07XG4gICAgICAgIH1cbiAgICAgICAgaWYodXBpbmZvWzBdPT04KXtcbiAgICAgICAgICAgIHR5cGVOb2RlID0gY2MuZmluZChcIkNhbnZhcy9jaGVzc2JvYXJkL21pZENoZXNzX2JsdWVfMlwiKTtcbiAgICAgICAgICAgIHR5cGVOb2RlLmdldENvbXBvbmVudChcInRlc3RcIikuc3BlZWQueCA9IHVwaW5mb1sxXTtcbiAgICAgICAgICAgIHR5cGVOb2RlLmdldENvbXBvbmVudChcInRlc3RcIikuc3BlZWQueSA9IHVwaW5mb1syXTtcbiAgICAgICAgfVxuICAgICAgICBpZih1cGluZm9bMF09PTkpe1xuICAgICAgICAgICAgdHlwZU5vZGUgPSBjYy5maW5kKFwiQ2FudmFzL2NoZXNzYm9hcmQvbWlkQ2hlc3NfYmx1ZV8zXCIpO1xuICAgICAgICAgICAgdHlwZU5vZGUuZ2V0Q29tcG9uZW50KFwidGVzdFwiKS5zcGVlZC54ID0gdXBpbmZvWzFdO1xuICAgICAgICAgICAgdHlwZU5vZGUuZ2V0Q29tcG9uZW50KFwidGVzdFwiKS5zcGVlZC55ID0gdXBpbmZvWzJdO1xuICAgICAgICB9XG4gICAgICAgIGlmKHVwaW5mb1swXT09MTApe1xuICAgICAgICAgICAgdHlwZU5vZGUgPSBjYy5maW5kKFwiQ2FudmFzL2NoZXNzYm9hcmQvbWlkQ2hlc3NfYmx1ZV80XCIpO1xuICAgICAgICAgICAgdHlwZU5vZGUuZ2V0Q29tcG9uZW50KFwidGVzdFwiKS5zcGVlZC54ID0gdXBpbmZvWzFdO1xuICAgICAgICAgICAgdHlwZU5vZGUuZ2V0Q29tcG9uZW50KFwidGVzdFwiKS5zcGVlZC55ID0gdXBpbmZvWzJdO1xuICAgICAgICB9XG4gICAgICAgIFxuICAgICAgICBpZih1cGluZm9bMF09PTExKXtcbiAgICAgICAgICAgIHR5cGVOb2RlID0gY2MuZmluZChcIkNhbnZhcy9jaGVzc2JvYXJkL3NtYWxsQ2hlc3NfcmVkXzFcIik7XG4gICAgICAgICAgICB0eXBlTm9kZS5nZXRDb21wb25lbnQoXCJ0ZXN0XCIpLnNwZWVkLnggPSB1cGluZm9bMV07XG4gICAgICAgICAgICB0eXBlTm9kZS5nZXRDb21wb25lbnQoXCJ0ZXN0XCIpLnNwZWVkLnkgPSB1cGluZm9bMl07XG4gICAgICAgIH1cbiAgICAgICAgaWYodXBpbmZvWzBdPT0xMil7XG4gICAgICAgICAgICB0eXBlTm9kZSA9IGNjLmZpbmQoXCJDYW52YXMvY2hlc3Nib2FyZC9zbWFsbENoZXNzX3JlZF8yXCIpO1xuICAgICAgICAgICAgdHlwZU5vZGUuZ2V0Q29tcG9uZW50KFwidGVzdFwiKS5zcGVlZC54ID0gdXBpbmZvWzFdO1xuICAgICAgICAgICAgdHlwZU5vZGUuZ2V0Q29tcG9uZW50KFwidGVzdFwiKS5zcGVlZC55ID0gdXBpbmZvWzJdO1xuICAgICAgICB9XG4gICAgICAgIGlmKHVwaW5mb1swXT09MTMpe1xuICAgICAgICAgICAgdHlwZU5vZGUgPSBjYy5maW5kKFwiQ2FudmFzL2NoZXNzYm9hcmQvc21hbGxDaGVzc19yZWRfM1wiKTtcbiAgICAgICAgICAgIHR5cGVOb2RlLmdldENvbXBvbmVudChcInRlc3RcIikuc3BlZWQueCA9IHVwaW5mb1sxXTtcbiAgICAgICAgICAgIHR5cGVOb2RlLmdldENvbXBvbmVudChcInRlc3RcIikuc3BlZWQueSA9IHVwaW5mb1syXTtcbiAgICAgICAgfVxuICAgICAgICBcbiAgICAgICAgaWYodXBpbmZvWzBdPT0xNCl7XG4gICAgICAgICAgICB0eXBlTm9kZSA9IGNjLmZpbmQoXCJDYW52YXMvY2hlc3Nib2FyZC9zbWFsbENoZXNzX2JsdWVfMVwiKTtcbiAgICAgICAgICAgIHR5cGVOb2RlLmdldENvbXBvbmVudChcInRlc3RcIikuc3BlZWQueCA9IHVwaW5mb1sxXTtcbiAgICAgICAgICAgIHR5cGVOb2RlLmdldENvbXBvbmVudChcInRlc3RcIikuc3BlZWQueSA9IHVwaW5mb1syXTtcbiAgICAgICAgfVxuICAgICAgICBpZih1cGluZm9bMF09PTE1KXtcbiAgICAgICAgICAgIHR5cGVOb2RlID0gY2MuZmluZChcIkNhbnZhcy9jaGVzc2JvYXJkL3NtYWxsQ2hlc3NfYmx1ZV8yXCIpO1xuICAgICAgICAgICAgdHlwZU5vZGUuZ2V0Q29tcG9uZW50KFwidGVzdFwiKS5zcGVlZC54ID0gdXBpbmZvWzFdO1xuICAgICAgICAgICAgdHlwZU5vZGUuZ2V0Q29tcG9uZW50KFwidGVzdFwiKS5zcGVlZC55ID0gdXBpbmZvWzJdO1xuICAgICAgICB9XG4gICAgICAgIGlmKHVwaW5mb1swXT09MTYpe1xuICAgICAgICAgICAgdHlwZU5vZGUgPSBjYy5maW5kKFwiQ2FudmFzL2NoZXNzYm9hcmQvc21hbGxDaGVzc19ibHVlXzNcIik7XG4gICAgICAgICAgICB0eXBlTm9kZS5nZXRDb21wb25lbnQoXCJ0ZXN0XCIpLnNwZWVkLnggPSB1cGluZm9bMV07XG4gICAgICAgICAgICB0eXBlTm9kZS5nZXRDb21wb25lbnQoXCJ0ZXN0XCIpLnNwZWVkLnkgPSB1cGluZm9bMl07XG4gICAgICAgIH1cbiAgICAgICAgXG4gICAgfSxcbiAgICBcbiAgICBjaGFuZ2VUdXJuKCkge1xuICAgICAgICBpZiAodGhpcy50dXJuID09PSBTVEFORC5CTFVFKSB7XG4gICAgICAgICAgICB0aGlzLnR1cm4gPSBTVEFORC5SRUQ7XG4gICAgICAgICAgICBjYy5maW5kKFwiQ2FudmFzL3Byb2dyZXNzQmFyXCIpLmdldENvbXBvbmVudChjYy5Qcm9ncmVzc0JhcikucHJvZ3Jlc3MgPSAxIDtcbiAgICAgICAgICAgIGNjLmZpbmQoXCJDYW52YXMvcHJvZ3Jlc3NCYXJcIikuZ2V0Q29tcG9uZW50KFwicHJvZ3Jlc3NCYXJDb250cm9sXCIpLnJlbWFpbmluZ1RpbWUgPSA0NSA7XG4gICAgICAgIH0gZWxzZSBpZiAodGhpcy50dXJuID09PSBTVEFORC5SRUQpIHtcbiAgICAgICAgICAgIHRoaXMudHVybiA9IFNUQU5ELkJMVUU7XG4gICAgICAgICAgICBjYy5maW5kKFwiQ2FudmFzL3Byb2dyZXNzQmFyXCIpLmdldENvbXBvbmVudChjYy5Qcm9ncmVzc0JhcikucHJvZ3Jlc3MgPSAxIDtcbiAgICAgICAgICAgIGNjLmZpbmQoXCJDYW52YXMvcHJvZ3Jlc3NCYXJcIikuZ2V0Q29tcG9uZW50KFwicHJvZ3Jlc3NCYXJDb250cm9sXCIpLnJlbWFpbmluZ1RpbWUgPSA0NSA7XG4gICAgICAgIH1cbiAgICAgICAgXG4gICAgfSxcbiAgICBcbiAgICBqdWRnZSgpe1xuICAgICAgICBpZih0aGlzLmJsdWVudW09PT0wKXtcbiAgICAgICAgICAgIEcud2ludHlwZSA9ICdyZWR3aW4nO1xuICAgICAgICAgICAgY2MuZGlyZWN0b3IubG9hZFNjZW5lKCd3aW4nKTtcbiAgICAgICAgfVxuICAgICAgICBpZih0aGlzLnJlZG51bT09PTApe1xuICAgICAgICAgICAgRy53aW50eXBlID0gJ2JsdWV3aW4nO1xuICAgICAgICAgICAgY2MuZGlyZWN0b3IubG9hZFNjZW5lKCd3aW4nKTtcbiAgICAgICAgfVxuICAgIH0sXG4gICAgXG5cbn0pO1xuIiwiY2MuQ2xhc3Moe1xyXG4gICAgZXh0ZW5kczogY2MuQ29tcG9uZW50LFxyXG5cclxuICAgIHByb3BlcnRpZXM6IHtcclxuICAgICAgICAvLyBmb286IHtcclxuICAgICAgICAvLyAgICBkZWZhdWx0OiBudWxsLCAgICAgIC8vIFRoZSBkZWZhdWx0IHZhbHVlIHdpbGwgYmUgdXNlZCBvbmx5IHdoZW4gdGhlIGNvbXBvbmVudCBhdHRhY2hpbmdcclxuICAgICAgICAvLyAgICAgICAgICAgICAgICAgICAgICAgICAgIHRvIGEgbm9kZSBmb3IgdGhlIGZpcnN0IHRpbWVcclxuICAgICAgICAvLyAgICB1cmw6IGNjLlRleHR1cmUyRCwgIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHR5cGVvZiBkZWZhdWx0XHJcbiAgICAgICAgLy8gICAgc2VyaWFsaXphYmxlOiB0cnVlLCAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0cnVlXHJcbiAgICAgICAgLy8gICAgdmlzaWJsZTogdHJ1ZSwgICAgICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0cnVlXHJcbiAgICAgICAgLy8gICAgZGlzcGxheU5hbWU6ICdGb28nLCAvLyBvcHRpb25hbFxyXG4gICAgICAgIC8vICAgIHJlYWRvbmx5OiBmYWxzZSwgICAgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgZmFsc2VcclxuICAgICAgICAvLyB9LFxyXG4gICAgICAgIC8vIC4uLlxyXG4gICAgfSxcclxuXHJcbiAgICAvLyB1c2UgdGhpcyBmb3IgaW5pdGlhbGl6YXRpb25cclxuICAgIG9uTG9hZDogZnVuY3Rpb24gKCkge1xyXG5cclxuICAgIH0sXHJcbiAgICBcclxuICAgIGhlbHBCYWNrOiBmdW5jdGlvbigpIHtcclxuICAgICAgICB0aGlzLm5vZGUuYWN0aXZlID0gZmFsc2U7XHJcbiAgICB9XHJcblxyXG4gICAgLy8gY2FsbGVkIGV2ZXJ5IGZyYW1lLCB1bmNvbW1lbnQgdGhpcyBmdW5jdGlvbiB0byBhY3RpdmF0ZSB1cGRhdGUgY2FsbGJhY2tcclxuICAgIC8vIHVwZGF0ZTogZnVuY3Rpb24gKGR0KSB7XHJcblxyXG4gICAgLy8gfSxcclxufSk7XHJcbiIsImNjLkNsYXNzKHtcclxuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcclxuXHJcbiAgICBwcm9wZXJ0aWVzOiB7XHJcbiAgICAgICAgLy8gZm9vOiB7XHJcbiAgICAgICAgLy8gICAgZGVmYXVsdDogbnVsbCwgICAgICAvLyBUaGUgZGVmYXVsdCB2YWx1ZSB3aWxsIGJlIHVzZWQgb25seSB3aGVuIHRoZSBjb21wb25lbnQgYXR0YWNoaW5nXHJcbiAgICAgICAgLy8gICAgICAgICAgICAgICAgICAgICAgICAgICB0byBhIG5vZGUgZm9yIHRoZSBmaXJzdCB0aW1lXHJcbiAgICAgICAgLy8gICAgdXJsOiBjYy5UZXh0dXJlMkQsICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0eXBlb2YgZGVmYXVsdFxyXG4gICAgICAgIC8vICAgIHNlcmlhbGl6YWJsZTogdHJ1ZSwgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgdHJ1ZVxyXG4gICAgICAgIC8vICAgIHZpc2libGU6IHRydWUsICAgICAgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgdHJ1ZVxyXG4gICAgICAgIC8vICAgIGRpc3BsYXlOYW1lOiAnRm9vJywgLy8gb3B0aW9uYWxcclxuICAgICAgICAvLyAgICByZWFkb25seTogZmFsc2UsICAgIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIGZhbHNlXHJcbiAgICAgICAgLy8gfSxcclxuICAgICAgICAvLyAuLi5cclxuICAgIH0sXHJcblxyXG4gICAgLy8gdXNlIHRoaXMgZm9yIGluaXRpYWxpemF0aW9uXHJcbiAgICBvbkxvYWQ6IGZ1bmN0aW9uICgpIHtcclxuICAgICAgICBcclxuICAgIH0sXHJcbiAgICBcclxuICAgIGhlbHA6IGZ1bmN0aW9uKCkge1xyXG4gICAgICAgICAgICB0aGlzLm5vZGUuYWN0aXZlID0gdHJ1ZTtcclxuICAgIH1cclxuXHJcbiAgICAvLyBjYWxsZWQgZXZlcnkgZnJhbWUsIHVuY29tbWVudCB0aGlzIGZ1bmN0aW9uIHRvIGFjdGl2YXRlIHVwZGF0ZSBjYWxsYmFja1xyXG4gICAgLy8gdXBkYXRlOiBmdW5jdGlvbiAoZHQpIHtcclxuXHJcbiAgICAvLyB9LFxyXG59KTtcclxuIiwiY29uc3QgQ29uc3RhbnRzID0gcmVxdWlyZSgnQ29uc3RhbnRzJyk7XHJcbi8vY29uc3QgR0FNRV9TVEFURSA9IENvbnN0YW50cy5HQU1FX1NUQVRFO1xyXG5jb25zdCBTVEFORCA9IENvbnN0YW50cy5TVEFORDtcclxuXHJcbmNjLkNsYXNzKHtcclxuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcclxuXHJcbiAgICBcclxuXHJcbiAgICBwcm9wZXJ0aWVzOiB7XHJcbiAgICAgICAgLy8gZm9vOiB7XHJcbiAgICAgICAgLy8gICAgZGVmYXVsdDogbnVsbCwgICAgICAvLyBUaGUgZGVmYXVsdCB2YWx1ZSB3aWxsIGJlIHVzZWQgb25seSB3aGVuIHRoZSBjb21wb25lbnQgYXR0YWNoaW5nXHJcbiAgICAgICAgLy8gICAgICAgICAgICAgICAgICAgICAgICAgICB0byBhIG5vZGUgZm9yIHRoZSBmaXJzdCB0aW1lXHJcbiAgICAgICAgLy8gICAgdXJsOiBjYy5UZXh0dXJlMkQsICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0eXBlb2YgZGVmYXVsdFxyXG4gICAgICAgIC8vICAgIHNlcmlhbGl6YWJsZTogdHJ1ZSwgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgdHJ1ZVxyXG4gICAgICAgIC8vICAgIHZpc2libGU6IHRydWUsICAgICAgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgdHJ1ZVxyXG4gICAgICAgIC8vICAgIGRpc3BsYXlOYW1lOiAnRm9vJywgLy8gb3B0aW9uYWxcclxuICAgICAgICAvLyAgICByZWFkb25seTogZmFsc2UsICAgIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIGZhbHNlXHJcbiAgICAgICAgLy8gfSxcclxuICAgICAgICAvLyAuLi5cclxuICAgICAgICByZW1haW5pbmdUaW1lIDogNDUsXHJcbiAgICB9LFxyXG5cclxuICAgIC8vIHVzZSB0aGlzIGZvciBpbml0aWFsaXphdGlvblxyXG4gICAgb25Mb2FkOiBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgXHJcbiAgICB9LFxyXG5cclxuICAgIC8vIGNhbGxlZCBldmVyeSBmcmFtZSwgdW5jb21tZW50IHRoaXMgZnVuY3Rpb24gdG8gYWN0aXZhdGUgdXBkYXRlIGNhbGxiYWNrXHJcbiAgICB1cGRhdGU6IGZ1bmN0aW9uIChkdCkge1xyXG4gICAgICAgIGlmKHRoaXMuZ2V0Q29tcG9uZW50KGNjLlByb2dyZXNzQmFyKS5wcm9ncmVzcyA+PSAwICl7XHJcbiAgICAgICAgICAgIHRoaXMucmVtYWluaW5nVGltZSAtPSBkdCA7XHJcbiAgICAgICAgICAgIHRoaXMuZ2V0Q29tcG9uZW50KGNjLlByb2dyZXNzQmFyKS5wcm9ncmVzcyA9IHRoaXMucmVtYWluaW5nVGltZSAvIDQ1IDtcclxuICAgICAgICB9ZWxzZXtcclxuICAgICAgICAgICAgaWYoY2MuZmluZChcIkNhbnZhc1wiKS5nZXRDb21wb25lbnQoXCJnYW1lTWFuYWdlclwiKS50dXJuID09PSBTVEFORC5CTFVFICl7XHJcbiAgICAgICAgICAgICAgICBjYy5maW5kKFwiQ2FudmFzXCIpLmdldENvbXBvbmVudChcImdhbWVNYW5hZ2VyXCIpLnR1cm4gPSBTVEFORC5SRUQ7XHJcbiAgICAgICAgICAgIH1lbHNlIGlmKGNjLmZpbmQoXCJDYW52YXNcIikuZ2V0Q29tcG9uZW50KFwiZ2FtZU1hbmFnZXJcIikudHVybiA9PT0gU1RBTkQuUkVEICl7XHJcbiAgICAgICAgICAgICAgICBjYy5maW5kKFwiQ2FudmFzXCIpLmdldENvbXBvbmVudChcImdhbWVNYW5hZ2VyXCIpLnR1cm4gPSBTVEFORC5CTFVFO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHRoaXMuZ2V0Q29tcG9uZW50KGNjLlByb2dyZXNzQmFyKS5wcm9ncmVzcyA9IDEgO1xyXG4gICAgICAgICAgICB0aGlzLnJlbWFpbmluZ1RpbWUgPSA0NSA7XHJcbiAgICAgICAgfVxyXG5cclxuICAgIH0sXHJcbn0pO1xyXG4iLCJjYy5DbGFzcyh7XHJcbiAgICBleHRlbmRzOiBjYy5Db21wb25lbnQsXHJcblxyXG4gICAgcHJvcGVydGllczoge1xyXG4gICAgICAgIC8vIGZvbzoge1xyXG4gICAgICAgIC8vICAgIGRlZmF1bHQ6IG51bGwsICAgICAgLy8gVGhlIGRlZmF1bHQgdmFsdWUgd2lsbCBiZSB1c2VkIG9ubHkgd2hlbiB0aGUgY29tcG9uZW50IGF0dGFjaGluZ1xyXG4gICAgICAgIC8vICAgICAgICAgICAgICAgICAgICAgICAgICAgdG8gYSBub2RlIGZvciB0aGUgZmlyc3QgdGltZVxyXG4gICAgICAgIC8vICAgIHVybDogY2MuVGV4dHVyZTJELCAgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgdHlwZW9mIGRlZmF1bHRcclxuICAgICAgICAvLyAgICBzZXJpYWxpemFibGU6IHRydWUsIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHRydWVcclxuICAgICAgICAvLyAgICB2aXNpYmxlOiB0cnVlLCAgICAgIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHRydWVcclxuICAgICAgICAvLyAgICBkaXNwbGF5TmFtZTogJ0ZvbycsIC8vIG9wdGlvbmFsXHJcbiAgICAgICAgLy8gICAgcmVhZG9ubHk6IGZhbHNlLCAgICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyBmYWxzZVxyXG4gICAgICAgIC8vIH0sXHJcbiAgICAgICAgLy8gLi4uXHJcbiAgICB9LFxyXG5cclxuICAgIC8vIHVzZSB0aGlzIGZvciBpbml0aWFsaXphdGlvblxyXG4gICAgb25Mb2FkOiBmdW5jdGlvbiAoKSB7XHJcblxyXG4gICAgfSxcclxuICAgIFxyXG4gICAgLy9sb2dvdXRcclxuICAgIEV4aXRTY2VuZTogZnVuY3Rpb24oKXtcclxuICAgICAgICBjYy5kaXJlY3Rvci5lbmQoKTtcclxuICAgIH1cclxuXHJcbiAgICAvLyBjYWxsZWQgZXZlcnkgZnJhbWUsIHVuY29tbWVudCB0aGlzIGZ1bmN0aW9uIHRvIGFjdGl2YXRlIHVwZGF0ZSBjYWxsYmFja1xyXG4gICAgLy8gdXBkYXRlOiBmdW5jdGlvbiAoZHQpIHtcclxuXHJcbiAgICAvLyB9LFxyXG59KTtcclxuIiwiY2MuQ2xhc3Moe1xuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcblxuICAgIG9uTG9hZDogZnVuY3Rpb24gKCkge1xuICAgICAgICBcbiAgICAgICAgRy5nbG9iYWxTb2NrZXQgPSBpby5jb25uZWN0KCcxMjcuMC4wLjE6ODA4MScpO1xuICAgICAgICAvL+aWreW8gOi/nuaOpeWQjuWGjemHjeaWsOi/nuaOpemcgOimgeWKoOS4insnZm9yY2UgbmV3IGNvbm5lY3Rpb24nOiB0cnVlfVxuICAgICAgICBHLmhhbGxTb2NrZXQgPSBpby5jb25uZWN0KCcxMjcuMC4wLjE6ODA4MS9oYWxsJyx7J2ZvcmNlIG5ldyBjb25uZWN0aW9uJzogdHJ1ZX0pO1xuICAgIH0sXG5cbiAgXG59KTtcbiIsImNjLkNsYXNzKHtcclxuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcclxuXHJcbiAgICBwcm9wZXJ0aWVzOiB7XHJcbiAgICAgICAgLy8gZm9vOiB7XHJcbiAgICAgICAgLy8gICAgZGVmYXVsdDogbnVsbCwgICAgICAvLyBUaGUgZGVmYXVsdCB2YWx1ZSB3aWxsIGJlIHVzZWQgb25seSB3aGVuIHRoZSBjb21wb25lbnQgYXR0YWNoaW5nXHJcbiAgICAgICAgLy8gICAgICAgICAgICAgICAgICAgICAgICAgICB0byBhIG5vZGUgZm9yIHRoZSBmaXJzdCB0aW1lXHJcbiAgICAgICAgLy8gICAgdXJsOiBjYy5UZXh0dXJlMkQsICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0eXBlb2YgZGVmYXVsdFxyXG4gICAgICAgIC8vICAgIHNlcmlhbGl6YWJsZTogdHJ1ZSwgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgdHJ1ZVxyXG4gICAgICAgIC8vICAgIHZpc2libGU6IHRydWUsICAgICAgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgdHJ1ZVxyXG4gICAgICAgIC8vICAgIGRpc3BsYXlOYW1lOiAnRm9vJywgLy8gb3B0aW9uYWxcclxuICAgICAgICAvLyAgICByZWFkb25seTogZmFsc2UsICAgIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIGZhbHNlXHJcbiAgICAgICAgLy8gfSxcclxuICAgICAgICAvLyAuLi5cclxuICAgIH0sXHJcblxyXG4gICAgLy8gdXNlIHRoaXMgZm9yIGluaXRpYWxpemF0aW9uXHJcbiAgICBvbkxvYWQ6IGZ1bmN0aW9uICgpIHtcclxuICAgICAgICBcclxuICAgIH0sXHJcbiAgICBcclxuICAgIHN0YXJ0ZnVuOiBmdW5jdGlvbigpIHtcclxuICAgICAgICBHLmhhbGxTb2NrZXQuZGlzY29ubmVjdCgpO1xyXG4gICAgICAgIGNjLmRpcmVjdG9yLmxvYWRTY2VuZSgnZmluZGluZycpO1xyXG4gICAgfVxyXG5cclxuICAgIC8vIGNhbGxlZCBldmVyeSBmcmFtZSwgdW5jb21tZW50IHRoaXMgZnVuY3Rpb24gdG8gYWN0aXZhdGUgdXBkYXRlIGNhbGxiYWNrXHJcbiAgICAvLyB1cGRhdGU6IGZ1bmN0aW9uIChkdCkge1xyXG5cclxuICAgIC8vIH0sXHJcbn0pO1xyXG4iLCJjb25zdCBDb25zdGFudHMgPSByZXF1aXJlKCdDb25zdGFudHMnKTtcclxuXHJcbmNvbnN0IFNUQU5EID0gQ29uc3RhbnRzLlNUQU5EO1xyXG5jYy5DbGFzcyh7XHJcbiAgICBleHRlbmRzOiBjYy5Db21wb25lbnQsXHJcblxyXG4gICAgcHJvcGVydGllczoge1xyXG4gICAgICAgIFxyXG4gICAgICAgIGNoZXNzTm9kZTogMCxcclxuICAgICAgICBcclxuICAgICAgICBjaGVzc1R5cGU6MCxcclxuICAgICAgICBcclxuICAgICAgICBzcGVlZDogY2MudjIoMCwgMCksXHJcbiAgICAgICAgXHJcbiAgICAgICAgcXVhbGl0eTogMCxcclxuICAgICAgICBcclxuICAgICAgICBcclxuICAgICAgICBcclxuICAgICAgICByYWRpdXM6IDI1MCxcclxuICAgICAgICBcclxuICAgICAgICBmbGFnOiAwLCAvLzAgYW5kIDEgYXJlIGNoZXNzbWFuICwgMiBpcyBiYWZmbGUgLDMgaXMgYm9yZGVyXHJcbiAgICAgICAgXHJcbiAgICAgICAgY2lyY2xlOiB7XHJcbiAgICAgICAgICAgIGRlZmF1bHQgOiBudWxsLFxyXG4gICAgICAgICAgICB0eXBlIDogY2MuUHJlZmFiXHJcbiAgICAgICAgfSxcclxuICAgICAgICBcclxuICAgICAgICBwb2ludF9yZWQ6IHtcclxuICAgICAgICAgICAgZGVmYXVsdCA6IG51bGwsXHJcbiAgICAgICAgICAgIHR5cGUgOiBjYy5QcmVmYWJcclxuICAgICAgICB9LFxyXG4gICAgfSxcclxuXHJcbiAgICBcclxuICAgIG9uTG9hZDogZnVuY3Rpb24gKCkge1xyXG4gICAgICAgIFxyXG4gICAgICAgIFxyXG4gICAgICAgIFxyXG4gICAgICAgIHZhciBtYW5hZ2VyID0gY2MuZGlyZWN0b3IuZ2V0Q29sbGlzaW9uTWFuYWdlcigpO1xyXG4gICAgICAgIG1hbmFnZXIuZW5hYmxlZCA9IHRydWU7XHJcbiAgICAgICAgXHJcbiAgICAgICAgLy92YXIgdGVzdG51bSA9MDtcclxuICAgICAgICBcclxuICAgICAgICB2YXIgY2lyY2xlVGVtcCA9IGNjLmluc3RhbnRpYXRlKHRoaXMuY2lyY2xlKTtcclxuICAgICAgICB2YXIgcG9pbnRSZWQgPSBjYy5pbnN0YW50aWF0ZSh0aGlzLnBvaW50X3JlZCk7XHJcbiAgICAgICAgdmFyIGRpc1ggPSAwIDtcclxuICAgICAgICB2YXIgZGlzWSA9IDAgO1xyXG4gICAgICAgIHZhciBtYXhJbml0aWFsU3BlZWQgPSAxODAwMC9NYXRoLnNxcnQodGhpcy5xdWFsaXR5KTtcclxuICAgICAgICB2YXIgbW92ZWFibGUgPSAwO1xyXG4gICAgICAgIHZhciB1cGluZm8gPSBbMCwwLDBdO1xyXG4gICAgICAgIFxyXG4gICAgICAgIFxyXG4gICAgICAgXHJcbiAgICAgICAgdGhpcy5ub2RlLm9uKGNjLk5vZGUuRXZlbnRUeXBlLlRPVUNIX1NUQVJULCBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgIC8qRy5yb29tU29ja2V0LmVtaXQoJ0dzdGFuZCcsRy5zdGFuZCk7ICAgIFxyXG4gICAgICAgICAgICBHLnJvb21Tb2NrZXQuZW1pdCgnZ2FtZXR1cm4nLEcuZ2FtZU1hbmFnZXIudHVybik7ICovXHJcbiAgICAgICAgICAgIGlmKEcuc3RhbmQ9PT1HLmdhbWVNYW5hZ2VyLnR1cm4pe1xyXG4gICAgICAgICAgICAvKkcucm9vbVNvY2tldC5lbWl0KCdHc3RhbmQnLEcuc3RhbmQpOyAgICBcclxuICAgICAgICAgICAgRy5yb29tU29ja2V0LmVtaXQoJ2dhbWV0dXJuJyxHLmdhbWVNYW5hZ2VyLnR1cm4pOyovIFxyXG4gICAgICAgICAgICBpZih0aGlzLmNoZXNzVHlwZT09PTAmJkcuZ2FtZU1hbmFnZXIudHVybj09PVNUQU5ELkJMVUUpe1xyXG4gICAgICAgICAgICAgICAgRy5yb29tU29ja2V0LmVtaXQoJ2RpZXJibHVlJyk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLm5vZGUuYWRkQ2hpbGQoY2lyY2xlVGVtcCk7XHJcbiAgICAgICAgICAgICAgICBjaXJjbGVUZW1wLnNldFBvc2l0aW9uKDAsMCk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLm5vZGUuYWRkQ2hpbGQocG9pbnRSZWQpO1xyXG4gICAgICAgICAgICAgICAgcG9pbnRSZWQuc2V0UG9zaXRpb24oMCwwKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBpZih0aGlzLmNoZXNzVHlwZT09MSYmRy5nYW1lTWFuYWdlci50dXJuPT1TVEFORC5SRUQpe1xyXG4gICAgICAgICAgICAgICAgRy5yb29tU29ja2V0LmVtaXQoJ2RpZXJyZWQnKTtcclxuICAgICAgICAgICAgICAgIHRoaXMubm9kZS5hZGRDaGlsZChjaXJjbGVUZW1wKTtcclxuICAgICAgICAgICAgICAgIGNpcmNsZVRlbXAuc2V0UG9zaXRpb24oMCwwKTtcclxuICAgICAgICAgICAgICAgIHRoaXMubm9kZS5hZGRDaGlsZChwb2ludFJlZCk7XHJcbiAgICAgICAgICAgICAgICBwb2ludFJlZC5zZXRQb3NpdGlvbigwLDApO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9LCB0aGlzKTtcclxuICAgICAgICB0aGlzLm5vZGUub24oY2MuTm9kZS5FdmVudFR5cGUuVE9VQ0hfTU9WRSwgZnVuY3Rpb24gKGV2ZW50KSB7XHJcbiAgICAgICAgICAgIGlmKEcuc3RhbmQ9PT1HLmdhbWVNYW5hZ2VyLnR1cm4pe1xyXG4gICAgICAgICAgICB2YXIgdG91Y2hlcyA7XHJcbiAgICAgICAgICAgIHZhciB0b3VjaExvYztcclxuICAgICAgICAgICAgaWYodGhpcy5jaGVzc1R5cGU9PT0wJiZHLmdhbWVNYW5hZ2VyLnR1cm49PT1TVEFORC5CTFVFKXtcclxuICAgICAgICAgICAgICAgIG1vdmVhYmxlID0gMTtcclxuICAgICAgICAgICAgdG91Y2hlcyA9IGV2ZW50LmdldFRvdWNoZXMoKTtcclxuICAgICAgICAgICAgdG91Y2hMb2MgPSB0b3VjaGVzWzBdLmdldExvY2F0aW9uKCk7XHJcbiAgICAgICAgICAgIGRpc1ggPSB0b3VjaExvYy54LTU0MC10aGlzLm5vZGUueDtcclxuICAgICAgICAgICAgZGlzWSA9IHRvdWNoTG9jLnktOTYwLXRoaXMubm9kZS55O1xyXG4gICAgICAgICAgICBpZihkaXNYKmRpc1ggKyBkaXNZKmRpc1kgPCB0aGlzLnJhZGl1cyp0aGlzLnJhZGl1cyl7XHJcbiAgICAgICAgICAgICAgICBwb2ludFJlZC5zZXRQb3NpdGlvbihkaXNYLGRpc1kpO1xyXG4gICAgICAgICAgICB9ZWxzZSBpZihkaXNYKmRpc1ggKyBkaXNZKmRpc1kgPCB0aGlzLnJhZGl1cyp0aGlzLnJhZGl1cyozKXtcclxuICAgICAgICAgICAgICAgIGRpc1ggPSBkaXNYIC8gTWF0aC5zcXJ0KGRpc1gqZGlzWCtkaXNZKmRpc1kpICogdGhpcy5yYWRpdXM7XHJcbiAgICAgICAgICAgICAgICBkaXNZID0gZGlzWSAvIE1hdGguc3FydChkaXNYKmRpc1grZGlzWSpkaXNZKSAqIHRoaXMucmFkaXVzO1xyXG4gICAgICAgICAgICAgICAgcG9pbnRSZWQuc2V0UG9zaXRpb24oZGlzWCwgZGlzWSk7XHJcbiAgICAgICAgICAgIH1lbHNle1xyXG4gICAgICAgICAgICAgICAgbW92ZWFibGUgPSAwO1xyXG4gICAgICAgICAgICAgICAgY2lyY2xlVGVtcC5yZW1vdmVGcm9tUGFyZW50KCk7XHJcbiAgICAgICAgICAgICAgICBwb2ludFJlZC5yZW1vdmVGcm9tUGFyZW50KCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBcclxuICAgICAgICAgICAgaWYodGhpcy5jaGVzc1R5cGU9PTEmJkcuZ2FtZU1hbmFnZXIudHVybj09U1RBTkQuUkVEKXtcclxuICAgICAgICAgICAgICAgIG1vdmVhYmxlID0gMTtcclxuICAgICAgICAgICAgdG91Y2hlcyA9IGV2ZW50LmdldFRvdWNoZXMoKTtcclxuICAgICAgICAgICAgdG91Y2hMb2MgPSB0b3VjaGVzWzBdLmdldExvY2F0aW9uKCk7XHJcbiAgICAgICAgICAgIGRpc1ggPSB0b3VjaExvYy54LTU0MC10aGlzLm5vZGUueDtcclxuICAgICAgICAgICAgZGlzWSA9IHRvdWNoTG9jLnktOTYwLXRoaXMubm9kZS55O1xyXG4gICAgICAgICAgICBpZihkaXNYKmRpc1ggKyBkaXNZKmRpc1kgPCB0aGlzLnJhZGl1cyp0aGlzLnJhZGl1cyl7XHJcbiAgICAgICAgICAgICAgICBwb2ludFJlZC5zZXRQb3NpdGlvbihkaXNYLGRpc1kpO1xyXG4gICAgICAgICAgICB9ZWxzZSBpZihkaXNYKmRpc1ggKyBkaXNZKmRpc1kgPCB0aGlzLnJhZGl1cyp0aGlzLnJhZGl1cyozKXtcclxuICAgICAgICAgICAgICAgIGRpc1ggPSBkaXNYIC8gTWF0aC5zcXJ0KGRpc1gqZGlzWCtkaXNZKmRpc1kpICogdGhpcy5yYWRpdXM7XHJcbiAgICAgICAgICAgICAgICBkaXNZID0gZGlzWSAvIE1hdGguc3FydChkaXNYKmRpc1grZGlzWSpkaXNZKSAqIHRoaXMucmFkaXVzO1xyXG4gICAgICAgICAgICAgICAgcG9pbnRSZWQuc2V0UG9zaXRpb24oZGlzWCwgZGlzWSk7XHJcbiAgICAgICAgICAgIH1lbHNle1xyXG4gICAgICAgICAgICAgICAgbW92ZWFibGUgPSAwO1xyXG4gICAgICAgICAgICAgICAgY2lyY2xlVGVtcC5yZW1vdmVGcm9tUGFyZW50KCk7XHJcbiAgICAgICAgICAgICAgICBwb2ludFJlZC5yZW1vdmVGcm9tUGFyZW50KCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBcclxuICAgICAgICAgICAgLy9HLnJvb21Tb2NrZXQuZW1pdCgnY2hhbmdlIHR1cm4nKTtcclxuICAgICAgICAgICAgXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9LCB0aGlzKTsvL+iEmuacrOi/kOihjOiHs+atpO+8jOS8oOWHumRpc1gsZGlzWeS4pOS4quWPguaVsO+8jOS7o+ihqOinpuaRuOeCueebuOWvueS6juaji+WtkOeahOS9jee9ru+8jOeUqOS7peiuoeeul+W8ueWKm+eahOWkp+Wwj+S4juaWueWQkVxyXG4gICAgICAgIHRoaXMubm9kZS5vbihjYy5Ob2RlLkV2ZW50VHlwZS5UT1VDSF9FTkQsIGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgaWYoRy5zdGFuZD09PUcuZ2FtZU1hbmFnZXIudHVybil7XHJcbiAgICAgICAgICAgIGlmICh0aGlzLmNoZXNzVHlwZSA9PT0gMCAmJiBHLmdhbWVNYW5hZ2VyLnR1cm49PSBTVEFORC5CTFVFKSB7XHJcbiAgICAgICAgICAgICAgICBpZihtb3ZlYWJsZSA9PSAxKXtcclxuICAgICAgICAgICAgICAgIHRoaXMuc3BlZWQueCA9IE1hdGgucm91bmQoLWRpc1gvdGhpcy5yYWRpdXMqbWF4SW5pdGlhbFNwZWVkKTtcclxuICAgICAgICAgICAgICAgIHRoaXMuc3BlZWQueSA9IE1hdGgucm91bmQoLWRpc1kvdGhpcy5yYWRpdXMqbWF4SW5pdGlhbFNwZWVkKTtcclxuICAgICAgICAgICAgICAgIGNpcmNsZVRlbXAucmVtb3ZlRnJvbVBhcmVudCgpO1xyXG4gICAgICAgICAgICAgICAgcG9pbnRSZWQucmVtb3ZlRnJvbVBhcmVudCgpO1xyXG4gICAgICAgICAgICAgICAgbW92ZWFibGUgPSAwO1xyXG4gICAgICAgICAgICAgICAgdXBpbmZvWzBdPXRoaXMuY2hlc3NOb2RlO1xyXG4gICAgICAgICAgICAgICAgdXBpbmZvWzFdPXRoaXMuc3BlZWQueDtcclxuICAgICAgICAgICAgICAgIHVwaW5mb1syXT10aGlzLnNwZWVkLnk7XHJcbiAgICAgICAgICAgICAgICBHLnJvb21Tb2NrZXQuZW1pdCgndXBpbmZvJyx1cGluZm8pO1xyXG4gICAgICAgICAgICAgICAgRy5nYW1lTWFuYWdlci5jaGFuZ2VUdXJuKCk7XHJcbiAgICAgICAgICAgIH1lbHNle1xyXG4gICAgICAgICAgICAgICAgY2lyY2xlVGVtcC5yZW1vdmVGcm9tUGFyZW50KCk7XHJcbiAgICAgICAgICAgICAgICBwb2ludFJlZC5yZW1vdmVGcm9tUGFyZW50KCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBpZiAodGhpcy5jaGVzc1R5cGUgPT09IDEgJiYgRy5nYW1lTWFuYWdlci50dXJuPT0gU1RBTkQuUkVEKSB7XHJcbiAgICAgICAgICAgICAgICBpZihtb3ZlYWJsZSA9PSAxKXtcclxuICAgICAgICAgICAgICAgIHRoaXMuc3BlZWQueCA9IE1hdGgucm91bmQoLWRpc1gvdGhpcy5yYWRpdXMqbWF4SW5pdGlhbFNwZWVkKTtcclxuICAgICAgICAgICAgICAgIHRoaXMuc3BlZWQueSA9IE1hdGgucm91bmQoLWRpc1kvdGhpcy5yYWRpdXMqbWF4SW5pdGlhbFNwZWVkKTtcclxuICAgICAgICAgICAgICAgIGNpcmNsZVRlbXAucmVtb3ZlRnJvbVBhcmVudCgpO1xyXG4gICAgICAgICAgICAgICAgcG9pbnRSZWQucmVtb3ZlRnJvbVBhcmVudCgpO1xyXG4gICAgICAgICAgICAgICAgbW92ZWFibGUgPSAwO1xyXG4gICAgICAgICAgICAgICAgdXBpbmZvWzBdPXRoaXMuY2hlc3NOb2RlO1xyXG4gICAgICAgICAgICAgICAgdXBpbmZvWzFdPXRoaXMuc3BlZWQueDtcclxuICAgICAgICAgICAgICAgIHVwaW5mb1syXT10aGlzLnNwZWVkLnk7XHJcbiAgICAgICAgICAgICAgICBHLnJvb21Tb2NrZXQuZW1pdCgndXBpbmZvJyx1cGluZm8pO1xyXG4gICAgICAgICAgICAgICAgRy5nYW1lTWFuYWdlci5jaGFuZ2VUdXJuKCk7XHJcbiAgICAgICAgICAgIH1lbHNle1xyXG4gICAgICAgICAgICAgICAgY2lyY2xlVGVtcC5yZW1vdmVGcm9tUGFyZW50KCk7XHJcbiAgICAgICAgICAgICAgICBwb2ludFJlZC5yZW1vdmVGcm9tUGFyZW50KCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSwgdGhpcyk7XHJcbiAgICAgICAgdGhpcy5ub2RlLm9uKGNjLk5vZGUuRXZlbnRUeXBlLlRPVUNIX0NBTkNFTCwgZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICBpZihHLnN0YW5kPT09Ry5nYW1lTWFuYWdlci50dXJuKXtcclxuICAgICAgICAgICAgaWYgKHRoaXMuY2hlc3NUeXBlID09PSAwICYmIEcuZ2FtZU1hbmFnZXIudHVybj09IFNUQU5ELkJMVUUpIHtcclxuICAgICAgICAgICAgaWYobW92ZWFibGUgPT0gMSl7XHJcbiAgICAgICAgICAgICAgICB0aGlzLnNwZWVkLnggPSBNYXRoLnJvdW5kKC1kaXNYL3RoaXMucmFkaXVzKm1heEluaXRpYWxTcGVlZCk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLnNwZWVkLnkgPSBNYXRoLnJvdW5kKC1kaXNZL3RoaXMucmFkaXVzKm1heEluaXRpYWxTcGVlZCk7XHJcbiAgICAgICAgICAgICAgICBjaXJjbGVUZW1wLnJlbW92ZUZyb21QYXJlbnQoKTtcclxuICAgICAgICAgICAgICAgIHBvaW50UmVkLnJlbW92ZUZyb21QYXJlbnQoKTtcclxuICAgICAgICAgICAgICAgIG1vdmVhYmxlID0gMDtcclxuICAgICAgICAgICAgICAgIHVwaW5mb1swXT10aGlzLmNoZXNzTm9kZTtcclxuICAgICAgICAgICAgICAgIHVwaW5mb1sxXT10aGlzLnNwZWVkLng7XHJcbiAgICAgICAgICAgICAgICB1cGluZm9bMl09dGhpcy5zcGVlZC55O1xyXG4gICAgICAgICAgICAgICAgRy5yb29tU29ja2V0LmVtaXQoJ3VwaW5mbycsdXBpbmZvKTtcclxuICAgICAgICAgICAgICAgIEcuZ2FtZU1hbmFnZXIuY2hhbmdlVHVybigpO1xyXG4gICAgICAgICAgICB9ZWxzZXtcclxuICAgICAgICAgICAgICAgIGNpcmNsZVRlbXAucmVtb3ZlRnJvbVBhcmVudCgpO1xyXG4gICAgICAgICAgICAgICAgcG9pbnRSZWQucmVtb3ZlRnJvbVBhcmVudCgpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgaWYgKHRoaXMuY2hlc3NUeXBlID09PSAxICYmIEcuZ2FtZU1hbmFnZXIudHVybj09IFNUQU5ELlJFRCkge1xyXG4gICAgICAgICAgICBpZihtb3ZlYWJsZSA9PSAxKXtcclxuICAgICAgICAgICAgICAgIHRoaXMuc3BlZWQueCA9IE1hdGgucm91bmQoLWRpc1gvdGhpcy5yYWRpdXMqbWF4SW5pdGlhbFNwZWVkKTtcclxuICAgICAgICAgICAgICAgIHRoaXMuc3BlZWQueSA9IE1hdGgucm91bmQoLWRpc1kvdGhpcy5yYWRpdXMqbWF4SW5pdGlhbFNwZWVkKTtcclxuICAgICAgICAgICAgICAgIGNpcmNsZVRlbXAucmVtb3ZlRnJvbVBhcmVudCgpO1xyXG4gICAgICAgICAgICAgICAgcG9pbnRSZWQucmVtb3ZlRnJvbVBhcmVudCgpO1xyXG4gICAgICAgICAgICAgICAgbW92ZWFibGUgPSAwO1xyXG4gICAgICAgICAgICAgICAgdXBpbmZvWzBdPXRoaXMuY2hlc3NOb2RlO1xyXG4gICAgICAgICAgICAgICAgdXBpbmZvWzFdPXRoaXMuc3BlZWQueDtcclxuICAgICAgICAgICAgICAgIHVwaW5mb1syXT10aGlzLnNwZWVkLnk7XHJcbiAgICAgICAgICAgICAgICBHLnJvb21Tb2NrZXQuZW1pdCgndXBpbmZvJyx1cGluZm8pO1xyXG4gICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICBHLmdhbWVNYW5hZ2VyLmNoYW5nZVR1cm4oKTtcclxuICAgICAgICAgICAgfWVsc2V7XHJcbiAgICAgICAgICAgICAgICBjaXJjbGVUZW1wLnJlbW92ZUZyb21QYXJlbnQoKTtcclxuICAgICAgICAgICAgICAgIHBvaW50UmVkLnJlbW92ZUZyb21QYXJlbnQoKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9LCB0aGlzKTtcclxuICAgIFxyXG4gICAgICAgIFxyXG4gICAgICAgIFxyXG4gICAgXHJcbiAgICB9LFxyXG5cclxuXHJcbiAgICBcclxuICAgIG9uQ29sbGlzaW9uRW50ZXI6IGZ1bmN0aW9uIChvdGhlciwgc2VsZikge1xyXG4gICAgICAgIGlmKHRoaXMuZmxhZyA9PT0gMCl7XHJcbiAgICAgICAgICAgIGlmKG90aGVyLmdldENvbXBvbmVudChcInRlc3RcIikuZmxhZyA9PT0wKXsvL+aji+WtkOWvueaSnlxyXG4gICAgICAgICAgICAgICAgb3RoZXIuZ2V0Q29tcG9uZW50KFwidGVzdFwiKS5mbGFnID0gMTtcclxuICAgICAgICAgICAgICAgIHZhciBtQSA9IHRoaXMucXVhbGl0eTtcclxuICAgICAgICAgICAgICAgIHZhciBtQiA9IG90aGVyLmdldENvbXBvbmVudChcInRlc3RcIikucXVhbGl0eTtcclxuICAgICAgICAgICAgICAgIHZhciB4QSA9IHNlbGYud29ybGQucG9zaXRpb24ueDtcclxuICAgICAgICAgICAgICAgIHZhciB5QSA9IHNlbGYud29ybGQucG9zaXRpb24ueTtcclxuICAgICAgICAgICAgICAgIHZhciB4QiA9IG90aGVyLndvcmxkLnBvc2l0aW9uLng7XHJcbiAgICAgICAgICAgICAgICB2YXIgeUIgPSBvdGhlci53b3JsZC5wb3NpdGlvbi55O1xyXG4gICAgICAgICAgICAgICAgdmFyIHZ4QSA9IHRoaXMuc3BlZWQueDtcclxuICAgICAgICAgICAgICAgIHZhciB2eUEgPSB0aGlzLnNwZWVkLnk7XHJcbiAgICAgICAgICAgICAgICB2YXIgdnhCID0gb3RoZXIuZ2V0Q29tcG9uZW50KFwidGVzdFwiKS5zcGVlZC54O1xyXG4gICAgICAgICAgICAgICAgdmFyIHZ5QiA9IG90aGVyLmdldENvbXBvbmVudChcInRlc3RcIikuc3BlZWQueTtcclxuICAgICAgICAgICAgICAgIHZhciBhbHBoYSA9IE1hdGguYXRhbigoeUIteUEpLyh4Qi14QSkpO1xyXG4gICAgICAgICAgICAgICAgdmFyIHYxID0gTWF0aC5zaW4oYWxwaGEpKnZ5QSArIE1hdGguY29zKGFscGhhKSp2eEE7XHJcbiAgICAgICAgICAgICAgICB2YXIgdjIgPSBNYXRoLnNpbihhbHBoYSkqdnlCICsgTWF0aC5jb3MoYWxwaGEpKnZ4QjtcclxuICAgICAgICAgICAgICAgIHZhciB2MTEgPSAoMiptQip2MisobUEtbUIpKnYxKS8obUErbUIpKjAuODtcclxuICAgICAgICAgICAgICAgIHZhciB2MjIgPSAoMiptQSp2MSsobUItbUEpKnYyKS8obUErbUIpKjAuODtcclxuICAgICAgICBcclxuICAgICAgICAgICAgICAgIHRoaXMuc3BlZWQueCA9IE1hdGguY29zKGFscGhhKSp2MTEtTWF0aC5zaW4oYWxwaGEpKihNYXRoLmNvcyhhbHBoYSkqdnlBLU1hdGguc2luKGFscGhhKSp2eEEpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5zcGVlZC55ID0gTWF0aC5jb3MoYWxwaGEpKihNYXRoLmNvcyhhbHBoYSkqdnlBLU1hdGguc2luKGFscGhhKSp2eEEpK01hdGguc2luKGFscGhhKSp2MTE7XHJcbiAgICAgICAgICAgICAgICBvdGhlci5nZXRDb21wb25lbnQoXCJ0ZXN0XCIpLnNwZWVkLng9TWF0aC5jb3MoYWxwaGEpKnYyMi1NYXRoLnNpbihhbHBoYSkqKE1hdGguY29zKGFscGhhKSp2eUItTWF0aC5zaW4oYWxwaGEpKnZ4Qik7XHJcbiAgICAgICAgICAgICAgICBvdGhlci5nZXRDb21wb25lbnQoXCJ0ZXN0XCIpLnNwZWVkLnk9TWF0aC5jb3MoYWxwaGEpKihNYXRoLmNvcyhhbHBoYSkqdnlCLU1hdGguc2luKGFscGhhKSp2eEIpK01hdGguc2luKGFscGhhKSp2MjI7XHJcbiAgICAgICAgICAgIH1lbHNlIGlmKG90aGVyLmdldENvbXBvbmVudChcInRlc3RcIikuZmxhZyA9PT0gMil7Ly/mo4vlrZDmkp7mnb9cclxuICAgICAgICAgICAgICAgIHZhciByYWRpdXNPZlNlbGYgPSAwO1xyXG4gICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICBpZih0aGlzLnF1YWxpdHkgPT0gNTAwKSB7cmFkaXVzT2ZTZWxmID0gNTA7fVxyXG4gICAgICAgICAgICAgICAgZWxzZSBpZih0aGlzLnF1YWxpdHkgPT0gMzAwKSB7cmFkaXVzT2ZTZWxmID0gMzU7fVxyXG4gICAgICAgICAgICAgICAgZWxzZXtyYWRpdXNPZlNlbGYgPSAyNTt9XHJcbiAgICAgICAgICAgICAgICBpZihNYXRoLmFicyh0aGlzLm5vZGUueCkgPiAtcmFkaXVzT2ZTZWxmKzI1MCl7dGhpcy5zcGVlZC55ID0gLXRoaXMuc3BlZWQueSAqIDAuOH1cclxuICAgICAgICAgICAgICAgIGVsc2V7dGhpcy5zcGVlZC54ID0gLXRoaXMuc3BlZWQueCAqIDAuODt9XHJcbiAgICAgICAgICAgIH1lbHNlIGlmKG90aGVyLmdldENvbXBvbmVudChcInRlc3RcIikuZmxhZyA9PT0gMyl7Ly/mo4vlrZDmkp7ovrnnlYxcclxuICAgICAgICAgICAgICAgIGlmKHRoaXMuY2hlc3NUeXBlPT09MCl7XHJcbiAgICAgICAgICAgICAgICAgICAgRy5nYW1lTWFuYWdlci5ibHVlbnVtLS07XHJcbiAgICAgICAgICAgICAgICAgICAgRy5nYW1lTWFuYWdlci5qdWRnZSgpO1xyXG4gICAgICAgICAgICAgICAgfWVsc2V7XHJcbiAgICAgICAgICAgICAgICAgICAgRy5nYW1lTWFuYWdlci5yZWRudW0tLTtcclxuICAgICAgICAgICAgICAgICAgICBHLmdhbWVNYW5hZ2VyLmp1ZGdlKCk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBHLnJvb21Tb2NrZXQuZW1pdCgnZGlzJyx0aGlzLm5vZGUuY2hlc3NOb2RlKTtcclxuICAgICAgICAgICAgICAgIHRoaXMubm9kZS5kZXN0cm95KCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9ZWxzZSBpZih0aGlzLmZsYWcgPT09IDEpe1xyXG4gICAgICAgICAgICB0aGlzLmZsYWcgPSAwO1xyXG4gICAgICAgIH1cclxuICAgICAgICBcclxuICAgIH0sXHJcbiAgICBcclxuICAgIHVwZGF0ZTogZnVuY3Rpb24gKGR0KSB7XHJcbiAgICAgICAgdmFyIGFjY2UgPSA1MjA7XHJcbiAgICAgICAgaWYodGhpcy5zcGVlZC54ID4gMCApIHtcclxuICAgICAgICAgICAgdGhpcy5zcGVlZC54IC09IGFjY2UqTWF0aC5hYnModGhpcy5zcGVlZC54KS9NYXRoLnNxcnQodGhpcy5zcGVlZC54KnRoaXMuc3BlZWQueCt0aGlzLnNwZWVkLnkqdGhpcy5zcGVlZC55KSAqIGR0O1xyXG4gICAgICAgIH1lbHNlIGlmKHRoaXMuc3BlZWQueCA8IDApIHtcclxuICAgICAgICAgICAgdGhpcy5zcGVlZC54ICs9IGFjY2UqTWF0aC5hYnModGhpcy5zcGVlZC54KS9NYXRoLnNxcnQodGhpcy5zcGVlZC54KnRoaXMuc3BlZWQueCt0aGlzLnNwZWVkLnkqdGhpcy5zcGVlZC55KSAqIGR0O1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZih0aGlzLnNwZWVkLnkgPiAwICkge1xyXG4gICAgICAgICAgICB0aGlzLnNwZWVkLnkgLT0gYWNjZSpNYXRoLmFicyh0aGlzLnNwZWVkLnkpL01hdGguc3FydCh0aGlzLnNwZWVkLngqdGhpcy5zcGVlZC54K3RoaXMuc3BlZWQueSp0aGlzLnNwZWVkLnkpICogZHQ7XHJcbiAgICAgICAgfWVsc2UgaWYodGhpcy5zcGVlZC55IDwgMCkge1xyXG4gICAgICAgICAgICB0aGlzLnNwZWVkLnkgKz0gYWNjZSpNYXRoLmFicyh0aGlzLnNwZWVkLnkpL01hdGguc3FydCh0aGlzLnNwZWVkLngqdGhpcy5zcGVlZC54K3RoaXMuc3BlZWQueSp0aGlzLnNwZWVkLnkpICogZHQ7XHJcbiAgICAgICAgfS8v6ZqP5pe26Ze05pu05paw6YCf5bqm5bm256Gu5L+d5Y2V5ZCR6L+Q5YqoXHJcbiAgICAgICAgXHJcbiAgICAgICAgdGhpcy5ub2RlLnggKz0gdGhpcy5zcGVlZC54ICogZHQ7XHJcbiAgICAgICAgdGhpcy5ub2RlLnkgKz0gdGhpcy5zcGVlZC55ICogZHQ7XHJcbiAgICB9XHJcblxyXG4gICAgXHJcblxyXG5cclxufSk7XHJcbiIsImNvbnN0IENvbnN0YW50cyA9IHJlcXVpcmUoJ0NvbnN0YW50cycpO1xyXG5cclxuY2MuQ2xhc3Moe1xyXG4gICAgZXh0ZW5kczogY2MuQ29tcG9uZW50LFxyXG5cclxuICAgIHByb3BlcnRpZXM6IHtcclxuICAgICAgICBpbmZvTGFiZWw6IGNjLkxhYmVsLFxyXG4gICAgfSxcclxuXHJcbiAgICAvLyB1c2UgdGhpcyBmb3IgaW5pdGlhbGl6YXRpb25cclxuICAgIG9uTG9hZDogZnVuY3Rpb24gKCkge1xyXG4gICAgICAgIGNvbnNvbGUubG9nKEcud2ludHlwZSk7XHJcbiAgICAgICAgLy90aGlzLmluZm9MYWJlbC5zdHJpbmcgPSAnIOiTneiJsuaWuSDojrfog5zvvIEgJztcclxuICAgICAgICBpZiAoRy53aW50eXBlID09ICdyZWR3aW4nKSB7XHJcbiAgICAgICAgICAgIHRoaXMuaW5mb0xhYmVsLnN0cmluZyA9ICcg6buE6Imy5pa5IOiOt+iDnO+8gSAnO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAoRy53aW50eXBlID09ICdibHVld2luJykge1xyXG4gICAgICAgICAgICB0aGlzLmluZm9MYWJlbC5zdHJpbmcgPSAnIOe0q+iJsuaWuSDojrfog5zvvIEgJztcclxuICAgICAgICB9XHJcbiAgICAgICAgaWYgKEcud2ludHlwZSA9PSAnZGlzY29uJykge1xyXG4gICAgICAgICAgICB0aGlzLmluZm9MYWJlbC5zdHJpbmcgPSAnIOS9oOeahOWvueaJi+W3suemu+W8gCAnO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAoRy53aW50eXBlID09PSBudWxsKSB7XHJcbiAgICAgICAgICAgIHRoaXMuaW5mb0xhYmVsLnN0cmluZyA9ICcnO1xyXG4gICAgICAgIH1cclxuICAgIH0sXHJcbiAgICBcclxuICAgIFxyXG4gICAgLy8gY2FsbGVkIGV2ZXJ5IGZyYW1lLCB1bmNvbW1lbnQgdGhpcyBmdW5jdGlvbiB0byBhY3RpdmF0ZSB1cGRhdGUgY2FsbGJhY2tcclxuICAgIC8vIHVwZGF0ZTogZnVuY3Rpb24gKGR0KSB7XHJcblxyXG4gICAgLy8gfSxcclxufSk7XHJcbiJdfQ==