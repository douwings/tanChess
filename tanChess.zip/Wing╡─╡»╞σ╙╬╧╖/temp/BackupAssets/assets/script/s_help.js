cc.Class({
    extends: cc.Component,

    properties: {
        sprite: {
            default: null,
            type: cc.spriteFrame,
        }
    },

    // use this for initialization
    onLoad: function () {

    },

    helpScene: function() {
        var node = new cc.Node('sprite'+this.count);
        var sp = node.addComponent(cc.sprite);
        
        sp.spriteFrame = this.sprite;
        node.parent = this.node;
        node.setPosition(0,0);
    }

    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
});
