"use strict";
cc._RFpush(module, 'e2756duo7BNRY7f8kHKLZWl', 'Constants');
// script\util\Constants.js

var STAND = cc.Enum({
    RED: 1,
    BLUE: 2
});

var CHESS_TYPE = cc.Enum({
    NONE: -1,
    RED: 1,
    BLUE: -1
});

var GAME_STATE = cc.Enum({
    PREPARE: -1,
    PLAYING: -1,
    OVER: -1
});

module.exports = {
    STAND: STAND,
    CHESS_TYPE: CHESS_TYPE,
    GAME_STATE: GAME_STATE

};

cc._RFpop();