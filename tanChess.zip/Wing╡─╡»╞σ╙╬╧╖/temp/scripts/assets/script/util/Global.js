"use strict";
cc._RFpush(module, '04fd0MxwapHrYsfCAT2HRS8', 'Global');
// script\util\Global.js

window.G = {
    globalSocket: null, //全局
    hallSocket: null, //大厅
    queueSocket: null, //队列
    roomSocket: null, //房间
    wintype: null,
    gameManager: null,
    stand: null
};

cc._RFpop();