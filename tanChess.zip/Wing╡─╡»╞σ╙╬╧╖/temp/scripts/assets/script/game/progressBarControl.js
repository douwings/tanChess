"use strict";
cc._RFpush(module, 'be9eeP/McZOp7aNzN1Lb6Y2', 'progressBarControl');
// script\game\progressBarControl.js

var Constants = require('Constants');
//const GAME_STATE = Constants.GAME_STATE;
var STAND = Constants.STAND;

cc.Class({
    "extends": cc.Component,

    properties: {
        // foo: {
        //    default: null,      // The default value will be used only when the component attaching
        //                           to a node for the first time
        //    url: cc.Texture2D,  // optional, default is typeof default
        //    serializable: true, // optional, default is true
        //    visible: true,      // optional, default is true
        //    displayName: 'Foo', // optional
        //    readonly: false,    // optional, default is false
        // },
        // ...
        remainingTime: 45
    },

    // use this for initialization
    onLoad: function onLoad() {},

    // called every frame, uncomment this function to activate update callback
    update: function update(dt) {
        if (this.getComponent(cc.ProgressBar).progress >= 0) {
            this.remainingTime -= dt;
            this.getComponent(cc.ProgressBar).progress = this.remainingTime / 45;
        } else {
            if (cc.find("Canvas").getComponent("gameManager").turn === STAND.BLUE) {
                cc.find("Canvas").getComponent("gameManager").turn = STAND.RED;
            } else if (cc.find("Canvas").getComponent("gameManager").turn === STAND.RED) {
                cc.find("Canvas").getComponent("gameManager").turn = STAND.BLUE;
            }
            this.getComponent(cc.ProgressBar).progress = 1;
            this.remainingTime = 45;
        }
    }
});

cc._RFpop();