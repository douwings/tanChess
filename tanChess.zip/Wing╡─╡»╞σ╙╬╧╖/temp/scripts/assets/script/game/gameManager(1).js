"use strict";
cc._RFpush(module, '10ae3L6TM5N/pEf2hMu+Umf', 'gameManager');
// script\game\gameManager.js

var Constants = require('Constants');
//const GAME_STATE = Constants.GAME_STATE;
var STAND = Constants.STAND;

cc.Class({
    'extends': cc.Component,

    properties: {

        turn: {
            'default': STAND.BLUE,
            type: STAND
        },

        //type: null,

        bluenum: 8,
        rednum: 8

    },

    //turnNum:0,
    //infoPanel: cc.Node,

    // use this for initialization
    onLoad: function onLoad() {

        G.gameManager = this;
        if (G.stand === STAND.BLUE) {
            G.roomSocket.emit('haveblue', G.stand);
        } else {
            G.stand = STAND.RED;
            G.roomSocket.emit('havered', G.stand);
        }
        //cc.find("Canvas/chessboard/bigChess_blue").getComponent("test").speed.x = 500;
        G.roomSocket.on('upinfo', function (upinfo) {

            upinfo = upinfo;
            G.gameManager.gameupinfo(upinfo);

            G.gameManager.changeTurn();
        });

        G.roomSocket.on('discon', function () {
            ////console.log("dafdasfadfadsf");
            G.wintype = 'discon';
            console.log(G.wintype);
            ////console.log("dasf");
            cc.director.loadScene('win');
        });

        G.roomSocket.on('upboard', function (upinfo) {

            upinfo = upinfo;
            G.gameManager.gameupboard(upinfo);
        });

        G.roomSocket.on('dis', function (chenode) {

            G.gameManager.chedis(chenode);
        });

        this.schedule(function () {
            var upinfo = [0, 0, 0, 0, 0];
            var typeNode;
            if (cc.find("Canvas/chessboard/bigChess_blue")) {
                typeNode = cc.find("Canvas/chessboard/bigChess_blue");

                upinfo[0] = typeNode.getComponent("test").chessNode;
                upinfo[1] = typeNode.x;
                upinfo[2] = typeNode.y;
                upinfo[3] = typeNode.getComponent("test").speed.x;
                upinfo[4] = typeNode.getComponent("test").speed.y;
                G.roomSocket.emit('upboard', upinfo);
            }
            if (cc.find("Canvas/chessboard/bigChess_red")) {
                typeNode = cc.find("Canvas/chessboard/bigChess_red");

                upinfo[0] = typeNode.getComponent("test").chessNode;
                upinfo[1] = typeNode.x;
                upinfo[2] = typeNode.y;
                upinfo[3] = typeNode.getComponent("test").speed.x;
                upinfo[4] = typeNode.getComponent("test").speed.y;
                G.roomSocket.emit('upboard', upinfo);
            }
            if (cc.find("Canvas/chessboard/midChess_red_1")) {
                typeNode = cc.find("Canvas/chessboard/midChess_red_1");

                upinfo[0] = typeNode.getComponent("test").chessNode;
                upinfo[1] = typeNode.x;
                upinfo[2] = typeNode.y;
                upinfo[3] = typeNode.getComponent("test").speed.x;
                upinfo[4] = typeNode.getComponent("test").speed.y;
                G.roomSocket.emit('upboard', upinfo);
            }
            if (cc.find("Canvas/chessboard/midChess_red_2")) {
                typeNode = cc.find("Canvas/chessboard/midChess_red_2");

                upinfo[0] = typeNode.getComponent("test").chessNode;
                upinfo[1] = typeNode.x;
                upinfo[2] = typeNode.y;
                upinfo[3] = typeNode.getComponent("test").speed.x;
                upinfo[4] = typeNode.getComponent("test").speed.y;
                G.roomSocket.emit('upboard', upinfo);
            }
            if (cc.find("Canvas/chessboard/midChess_red_3")) {
                typeNode = cc.find("Canvas/chessboard/midChess_red_3");

                upinfo[0] = typeNode.getComponent("test").chessNode;
                upinfo[1] = typeNode.x;
                upinfo[2] = typeNode.y;
                upinfo[3] = typeNode.getComponent("test").speed.x;
                upinfo[4] = typeNode.getComponent("test").speed.y;
                G.roomSocket.emit('upboard', upinfo);
            }
            if (cc.find("Canvas/chessboard/midChess_red_4")) {
                typeNode = cc.find("Canvas/chessboard/midChess_red_4");

                upinfo[0] = typeNode.getComponent("test").chessNode;
                upinfo[1] = typeNode.x;
                upinfo[2] = typeNode.y;
                upinfo[3] = typeNode.getComponent("test").speed.x;
                upinfo[4] = typeNode.getComponent("test").speed.y;
                G.roomSocket.emit('upboard', upinfo);
            }
            if (cc.find("Canvas/chessboard/midChess_blue_1")) {
                typeNode = cc.find("Canvas/chessboard/midChess_blue_1");

                upinfo[0] = typeNode.getComponent("test").chessNode;
                upinfo[1] = typeNode.x;
                upinfo[2] = typeNode.y;
                upinfo[3] = typeNode.getComponent("test").speed.x;
                upinfo[4] = typeNode.getComponent("test").speed.y;
                G.roomSocket.emit('upboard', upinfo);
            }
            if (cc.find("Canvas/chessboard/midChess_blue_2")) {
                typeNode = cc.find("Canvas/chessboard/midChess_blue_2");

                upinfo[0] = typeNode.getComponent("test").chessNode;
                upinfo[1] = typeNode.x;
                upinfo[2] = typeNode.y;
                upinfo[3] = typeNode.getComponent("test").speed.x;
                upinfo[4] = typeNode.getComponent("test").speed.y;
                G.roomSocket.emit('upboard', upinfo);
            }
            if (cc.find("Canvas/chessboard/midChess_blue_3")) {
                typeNode = cc.find("Canvas/chessboard/midChess_blue_3");

                upinfo[0] = typeNode.getComponent("test").chessNode;
                upinfo[1] = typeNode.x;
                upinfo[2] = typeNode.y;
                upinfo[3] = typeNode.getComponent("test").speed.x;
                upinfo[4] = typeNode.getComponent("test").speed.y;
                G.roomSocket.emit('upboard', upinfo);
            }
            if (cc.find("Canvas/chessboard/midChess_blue_4")) {
                typeNode = cc.find("Canvas/chessboard/midChess_blue_4");

                upinfo[0] = typeNode.getComponent("test").chessNode;
                upinfo[1] = typeNode.x;
                upinfo[2] = typeNode.y;
                upinfo[3] = typeNode.getComponent("test").speed.x;
                upinfo[4] = typeNode.getComponent("test").speed.y;
                G.roomSocket.emit('upboard', upinfo);
            }
            if (cc.find("Canvas/chessboard/smallChess_red_1")) {
                typeNode = cc.find("Canvas/chessboard/smallChess_red_1");

                upinfo[0] = typeNode.getComponent("test").chessNode;
                upinfo[1] = typeNode.x;
                upinfo[2] = typeNode.y;
                upinfo[3] = typeNode.getComponent("test").speed.x;
                upinfo[4] = typeNode.getComponent("test").speed.y;
                G.roomSocket.emit('upboard', upinfo);
            }
            if (cc.find("Canvas/chessboard/smallChess_red_2")) {
                typeNode = cc.find("Canvas/chessboard/smallChess_red_2");

                upinfo[0] = typeNode.getComponent("test").chessNode;
                upinfo[1] = typeNode.x;
                upinfo[2] = typeNode.y;
                upinfo[3] = typeNode.getComponent("test").speed.x;
                upinfo[4] = typeNode.getComponent("test").speed.y;
                G.roomSocket.emit('upboard', upinfo);
            }
            if (cc.find("Canvas/chessboard/smallChess_red_3")) {
                typeNode = cc.find("Canvas/chessboard/smallChess_red_3");

                upinfo[0] = typeNode.getComponent("test").chessNode;
                upinfo[1] = typeNode.x;
                upinfo[2] = typeNode.y;
                upinfo[3] = typeNode.getComponent("test").speed.x;
                upinfo[4] = typeNode.getComponent("test").speed.y;
                G.roomSocket.emit('upboard', upinfo);
            }
            if (cc.find("Canvas/chessboard/smallChess_blue_1")) {
                typeNode = cc.find("Canvas/chessboard/smallChess_blue_1");

                upinfo[0] = typeNode.getComponent("test").chessNode;
                upinfo[1] = typeNode.x;
                upinfo[2] = typeNode.y;
                upinfo[3] = typeNode.getComponent("test").speed.x;
                upinfo[4] = typeNode.getComponent("test").speed.y;
                G.roomSocket.emit('upboard', upinfo);
            }
            if (cc.find("Canvas/chessboard/smallChess_blue_2")) {
                typeNode = cc.find("Canvas/chessboard/smallChess_blue_2");

                upinfo[0] = typeNode.getComponent("test").chessNode;
                upinfo[1] = typeNode.x;
                upinfo[2] = typeNode.y;
                upinfo[3] = typeNode.getComponent("test").speed.x;
                upinfo[4] = typeNode.getComponent("test").speed.y;
                G.roomSocket.emit('upboard', upinfo);
            }
            if (cc.find("Canvas/chessboard/smallChess_blue_3")) {
                typeNode = cc.find("Canvas/chessboard/smallChess_blue_3");

                upinfo[0] = typeNode.getComponent("test").chessNode;
                upinfo[1] = typeNode.x;
                upinfo[2] = typeNode.y;
                upinfo[3] = typeNode.getComponent("test").speed.x;
                upinfo[4] = typeNode.getComponent("test").speed.y;
                G.roomSocket.emit('upboard', upinfo);
            }
        }, 2);
    },

    chedis: function chedis(chenode) {

        var typeNode;

        if (chenode == 2) {

            typeNode = cc.find("Canvas/chessboard/bigChess_blue");
            //console.log("zhaodao");
            typeNode.destroy();
            //console.log("xiaochu");
        }

        if (chenode == 1) {

            //console.log("zhaodao");typeNode = cc.find("Canvas/chessboard/bigChess_red");
            typeNode.destroy();
            //console.log("xiaochu");
        }

        if (chenode == 3) {

            typeNode = cc.find("Canvas/chessboard/midChess_red_1");
            //console.log("zhaodao");
            typeNode.destroy();
            //console.log("xiaochu");
        }
        if (chenode == 4) {
            //console.log("zhaodao");typeNode = cc.find("Canvas/chessboard/midChess_red_2");
            typeNode.destroy();
            //console.log("xiaochu");
        }
        if (chenode == 5) {
            //console.log("zhaodao");typeNode = cc.find("Canvas/chessboard/midChess_red_3");
            typeNode.destroy();
            //console.log("xiaochu");
        }
        if (chenode == 6) {
            //console.log("zhaodao");typeNode = cc.find("Canvas/chessboard/midChess_red_4");
            typeNode.destroy();
            //console.log("xiaochu");
        }

        if (chenode == 7) {
            //console.log("zhaodao");typeNode = cc.find("Canvas/chessboard/midChess_blue_1");
            typeNode.destroy();
            //console.log("xiaochu");
        }
        if (chenode == 8) {
            //console.log("zhaodao");typeNode = cc.find("Canvas/chessboard/midChess_blue_2");
            typeNode.destroy();
            //console.log("xiaochu");
        }
        if (chenode == 9) {
            //console.log("zhaodao");typeNode = cc.find("Canvas/chessboard/midChess_blue_3");
            typeNode.destroy();
            //console.log("xiaochu");
        }
        if (chenode == 10) {
            //console.log("zhaodao");typeNode = cc.find("Canvas/chessboard/midChess_blue_4");
            typeNode.destroy();
            //console.log("xiaochu");
        }

        if (chenode == 11) {
            //console.log("zhaodao");typeNode = cc.find("Canvas/chessboard/smallChess_red_1");
            typeNode.destroy();
            //console.log("xiaochu");
        }
        if (chenode == 12) {
            //console.log("zhaodao");typeNode = cc.find("Canvas/chessboard/smallChess_red_2");
            typeNode.destroy();
            //console.log("xiaochu");
        }
        if (chenode == 13) {
            //console.log("zhaodao");typeNode = cc.find("Canvas/chessboard/smallChess_red_3");
            typeNode.destroy();
            //console.log("xiaochu");
        }

        if (chenode == 14) {
            //console.log("zhaodao");typeNode = cc.find("Canvas/chessboard/smallChess_blue_1");
            typeNode.destroy();
            //console.log("xiaochu");
        }
        if (chenode == 15) {
            //console.log("zhaodao");typeNode = cc.find("Canvas/chessboard/smallChess_blue_2");
            typeNode.destroy();
            //console.log("xiaochu");
        }
        if (chenode == 16) {
            //console.log("zhaodao");typeNode = cc.find("Canvas/chessboard/smallChess_blue_3");
            typeNode.destroy();
            //console.log("xiaochu");
        }
    },

    gameupboard: function gameupboard(upinfo) {

        var typeNode;

        if (upinfo[0] == 2) {

            typeNode = cc.find("Canvas/chessboard/bigChess_blue");

            typeNode.x = upinfo[1];
            typeNode.y = upinfo[2];
            typeNode.getComponent("test").speed.x = upinfo[3];
            typeNode.getComponent("test").speed.y = upinfo[4];
        }

        if (upinfo[0] == 1) {

            typeNode = cc.find("Canvas/chessboard/bigChess_red");
            typeNode.x = upinfo[1];
            typeNode.y = upinfo[2];
            typeNode.getComponent("test").speed.x = upinfo[3];
            typeNode.getComponent("test").speed.y = upinfo[4];
        }

        if (upinfo[0] == 3) {

            typeNode = cc.find("Canvas/chessboard/midChess_red_1");

            typeNode.x = upinfo[1];
            typeNode.y = upinfo[2];
            typeNode.getComponent("test").speed.x = upinfo[3];
            typeNode.getComponent("test").speed.y = upinfo[4];
        }
        if (upinfo[0] == 4) {
            typeNode = cc.find("Canvas/chessboard/midChess_red_2");
            typeNode.x = upinfo[1];
            typeNode.y = upinfo[2];
            typeNode.getComponent("test").speed.x = upinfo[3];
            typeNode.getComponent("test").speed.y = upinfo[4];
        }
        if (upinfo[0] == 5) {
            typeNode = cc.find("Canvas/chessboard/midChess_red_3");
            typeNode.x = upinfo[1];
            typeNode.y = upinfo[2];
            typeNode.getComponent("test").speed.x = upinfo[3];
            typeNode.getComponent("test").speed.y = upinfo[4];
        }
        if (upinfo[0] == 6) {
            typeNode = cc.find("Canvas/chessboard/midChess_red_4");
            typeNode.x = upinfo[1];
            typeNode.y = upinfo[2];
            typeNode.getComponent("test").speed.x = upinfo[3];
            typeNode.getComponent("test").speed.y = upinfo[4];
        }

        if (upinfo[0] == 7) {
            typeNode = cc.find("Canvas/chessboard/midChess_blue_1");
            typeNode.x = upinfo[1];
            typeNode.y = upinfo[2];
            typeNode.getComponent("test").speed.x = upinfo[3];
            typeNode.getComponent("test").speed.y = upinfo[4];
        }
        if (upinfo[0] == 8) {
            typeNode = cc.find("Canvas/chessboard/midChess_blue_2");
            typeNode.x = upinfo[1];
            typeNode.y = upinfo[2];
            typeNode.getComponent("test").speed.x = upinfo[3];
            typeNode.getComponent("test").speed.y = upinfo[4];
        }
        if (upinfo[0] == 9) {
            typeNode = cc.find("Canvas/chessboard/midChess_blue_3");
            typeNode.x = upinfo[1];
            typeNode.y = upinfo[2];
            typeNode.getComponent("test").speed.x = upinfo[3];
            typeNode.getComponent("test").speed.y = upinfo[4];
        }
        if (upinfo[0] == 10) {
            typeNode = cc.find("Canvas/chessboard/midChess_blue_4");
            typeNode.x = upinfo[1];
            typeNode.y = upinfo[2];
            typeNode.getComponent("test").speed.x = upinfo[3];
            typeNode.getComponent("test").speed.y = upinfo[4];
        }

        if (upinfo[0] == 11) {
            typeNode = cc.find("Canvas/chessboard/smallChess_red_1");
            typeNode.x = upinfo[1];
            typeNode.y = upinfo[2];
            typeNode.getComponent("test").speed.x = upinfo[3];
            typeNode.getComponent("test").speed.y = upinfo[4];
        }
        if (upinfo[0] == 12) {
            typeNode = cc.find("Canvas/chessboard/smallChess_red_2");
            typeNode.x = upinfo[1];
            typeNode.y = upinfo[2];
            typeNode.getComponent("test").speed.x = upinfo[3];
            typeNode.getComponent("test").speed.y = upinfo[4];
        }
        if (upinfo[0] == 13) {
            typeNode = cc.find("Canvas/chessboard/smallChess_red_3");
            typeNode.x = upinfo[1];
            typeNode.y = upinfo[2];
            typeNode.getComponent("test").speed.x = upinfo[3];
            typeNode.getComponent("test").speed.y = upinfo[4];
        }

        if (upinfo[0] == 14) {
            typeNode = cc.find("Canvas/chessboard/smallChess_blue_1");
            typeNode.x = upinfo[1];
            typeNode.y = upinfo[2];
            typeNode.getComponent("test").speed.x = upinfo[3];
            typeNode.getComponent("test").speed.y = upinfo[4];
        }
        if (upinfo[0] == 15) {
            typeNode = cc.find("Canvas/chessboard/smallChess_blue_2");
            typeNode.x = upinfo[1];
            typeNode.y = upinfo[2];
            typeNode.getComponent("test").speed.x = upinfo[3];
            typeNode.getComponent("test").speed.y = upinfo[4];
        }
        if (upinfo[0] == 16) {
            typeNode = cc.find("Canvas/chessboard/smallChess_blue_3");
            typeNode.x = upinfo[1];
            typeNode.y = upinfo[2];
            typeNode.getComponent("test").speed.x = upinfo[3];
            typeNode.getComponent("test").speed.y = upinfo[4];
        }
    },

    gameupinfo: function gameupinfo(upinfo) {

        var typeNode;
        var num;
        if (upinfo[0] == 2) {

            typeNode = cc.find("Canvas/chessboard/bigChess_blue");

            typeNode.getComponent("test").speed.x = upinfo[1];
            typeNode.getComponent("test").speed.y = upinfo[2];
        }

        if (upinfo[0] == 1) {

            typeNode = cc.find("Canvas/chessboard/bigChess_red");
            typeNode.getComponent("test").speed.x = upinfo[1];
            typeNode.getComponent("test").speed.y = upinfo[2];
        }

        if (upinfo[0] == 3) {

            typeNode = cc.find("Canvas/chessboard/midChess_red_1");

            typeNode.getComponent("test").speed.x = upinfo[1];
            typeNode.getComponent("test").speed.y = upinfo[2];
        }
        if (upinfo[0] == 4) {
            typeNode = cc.find("Canvas/chessboard/midChess_red_2");
            typeNode.getComponent("test").speed.x = upinfo[1];
            typeNode.getComponent("test").speed.y = upinfo[2];
        }
        if (upinfo[0] == 5) {
            typeNode = cc.find("Canvas/chessboard/midChess_red_3");
            typeNode.getComponent("test").speed.x = upinfo[1];
            typeNode.getComponent("test").speed.y = upinfo[2];
        }
        if (upinfo[0] == 6) {
            typeNode = cc.find("Canvas/chessboard/midChess_red_4");
            typeNode.getComponent("test").speed.x = upinfo[1];
            typeNode.getComponent("test").speed.y = upinfo[2];
        }

        if (upinfo[0] == 7) {
            typeNode = cc.find("Canvas/chessboard/midChess_blue_1");
            typeNode.getComponent("test").speed.x = upinfo[1];
            typeNode.getComponent("test").speed.y = upinfo[2];
        }
        if (upinfo[0] == 8) {
            typeNode = cc.find("Canvas/chessboard/midChess_blue_2");
            typeNode.getComponent("test").speed.x = upinfo[1];
            typeNode.getComponent("test").speed.y = upinfo[2];
        }
        if (upinfo[0] == 9) {
            typeNode = cc.find("Canvas/chessboard/midChess_blue_3");
            typeNode.getComponent("test").speed.x = upinfo[1];
            typeNode.getComponent("test").speed.y = upinfo[2];
        }
        if (upinfo[0] == 10) {
            typeNode = cc.find("Canvas/chessboard/midChess_blue_4");
            typeNode.getComponent("test").speed.x = upinfo[1];
            typeNode.getComponent("test").speed.y = upinfo[2];
        }

        if (upinfo[0] == 11) {
            typeNode = cc.find("Canvas/chessboard/smallChess_red_1");
            typeNode.getComponent("test").speed.x = upinfo[1];
            typeNode.getComponent("test").speed.y = upinfo[2];
        }
        if (upinfo[0] == 12) {
            typeNode = cc.find("Canvas/chessboard/smallChess_red_2");
            typeNode.getComponent("test").speed.x = upinfo[1];
            typeNode.getComponent("test").speed.y = upinfo[2];
        }
        if (upinfo[0] == 13) {
            typeNode = cc.find("Canvas/chessboard/smallChess_red_3");
            typeNode.getComponent("test").speed.x = upinfo[1];
            typeNode.getComponent("test").speed.y = upinfo[2];
        }

        if (upinfo[0] == 14) {
            typeNode = cc.find("Canvas/chessboard/smallChess_blue_1");
            typeNode.getComponent("test").speed.x = upinfo[1];
            typeNode.getComponent("test").speed.y = upinfo[2];
        }
        if (upinfo[0] == 15) {
            typeNode = cc.find("Canvas/chessboard/smallChess_blue_2");
            typeNode.getComponent("test").speed.x = upinfo[1];
            typeNode.getComponent("test").speed.y = upinfo[2];
        }
        if (upinfo[0] == 16) {
            typeNode = cc.find("Canvas/chessboard/smallChess_blue_3");
            typeNode.getComponent("test").speed.x = upinfo[1];
            typeNode.getComponent("test").speed.y = upinfo[2];
        }
    },

    changeTurn: function changeTurn() {
        if (this.turn === STAND.BLUE) {
            this.turn = STAND.RED;
            cc.find("Canvas/progressBar").getComponent(cc.ProgressBar).progress = 1;
            cc.find("Canvas/progressBar").getComponent("progressBarControl").remainingTime = 45;
        } else if (this.turn === STAND.RED) {
            this.turn = STAND.BLUE;
            cc.find("Canvas/progressBar").getComponent(cc.ProgressBar).progress = 1;
            cc.find("Canvas/progressBar").getComponent("progressBarControl").remainingTime = 45;
        }
    },

    judge: function judge() {
        if (this.bluenum === 0) {
            G.wintype = 'redwin';
            cc.director.loadScene('win');
        }
        if (this.rednum === 0) {
            G.wintype = 'bluewin';
            cc.director.loadScene('win');
        }
    }

});

cc._RFpop();