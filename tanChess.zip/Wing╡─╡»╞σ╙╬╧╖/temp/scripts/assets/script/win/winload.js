"use strict";
cc._RFpush(module, 'f63fdYIPrZDlrFtuMWp3rNq', 'winload');
// script\win\winload.js

var Constants = require('Constants');

cc.Class({
    'extends': cc.Component,

    properties: {
        infoLabel: cc.Label
    },

    // use this for initialization
    onLoad: function onLoad() {
        console.log(G.wintype);
        //this.infoLabel.string = ' 蓝色方 获胜！ ';
        if (G.wintype == 'redwin') {
            this.infoLabel.string = ' 黄色方 获胜！ ';
        }
        if (G.wintype == 'bluewin') {
            this.infoLabel.string = ' 紫色方 获胜！ ';
        }
        if (G.wintype == 'discon') {
            this.infoLabel.string = ' 你的对手已离开 ';
        }
        if (G.wintype === null) {
            this.infoLabel.string = '';
        }
    }

});
// called every frame, uncomment this function to activate update callback
// update: function (dt) {

// },

cc._RFpop();